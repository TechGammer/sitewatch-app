# Site Watch

An Android app that watches your per-site WhatsApp groups, and on a schedule,
sends you a structured report (TPH, issues, pending items) to Telegram — a
separate personal project, not part of WhatsClaw.

## How it works

```
WhatsApp posts a notification
        │
        ▼
NotificationCaptureService (NotificationListenerService)
  - filters to your configured site group names
  - pulls sender + text + time out of the notification's
    MessagingStyle data (no need to open WhatsApp)
        │
        ▼
Room database (sitewatch.db) — messages stored, marked "unreported"
        │
        ▼   (every N hours, via WorkManager)
ReportWorker
  - groups unreported messages by site
  - sends the batch to Claude (your Anthropic API key) with a prompt
    asking for {tph, issues, pending, summary} per site
  - formats the JSON into a readable message
  - sends it to your Telegram bot
  - marks those messages as reported
```

Nothing is opened or automated on WhatsApp's UI — this only reads
notification content, which is why it's much lower-risk than a
WhatsApp-Web-automation approach (Baileys, whatsapp-web.js, etc.) for
your own personal number.

## Building it — no Android Studio needed

This project is already a complete, self-contained Gradle project (real
`gradlew`/wrapper included, generated and smoke-tested against Gradle 8.7 —
`./gradlew assembleDebug` gets all the way to needing an actual Android SDK,
which only exists in the cloud runner). You don't need Android Studio or any
local Android tooling at all. The build itself runs on GitHub's free cloud
runners via GitHub Actions.

1. **Create a free GitHub account** at github.com if you don't have one.
2. **Create a new repository** (Add → New repository). Public is fine and
   gives unlimited free Actions minutes; private also gets a generous free
   tier.
3. **Upload the project**: unzip `sitewatch-app.zip` on your laptop, then on
   your repo's page use "Add file → Upload files" and drag the *contents* of
   the unzipped `sitewatch-app` folder in (including the hidden `.github`
   folder — if your OS hides it, use your file manager's "show hidden files"
   option). Commit.
4. **Check the Actions tab.** Pushing the files should auto-trigger the
   "Build APK" workflow (`.github/workflows/build.yml`). Open the Actions
   tab → click the running/completed workflow → wait for the green check
   (first run: a few minutes, mostly SDK download).
5. **Download the APK**: on that same workflow run page, scroll to
   "Artifacts" → download `sitewatch-debug-apk` → unzip it to get
   `app-debug.apk`.
6. **Get it onto your phone**: email it to yourself, or upload to Google
   Drive and download on-phone, or plug in via USB. Then tap the file to
   install — you'll need to allow "install unknown apps" for whichever app
   you opened it with (Files, Chrome, Gmail, etc.), Android will prompt you
   for this the first time.
7. **Create a Telegram bot**: message `@BotFather` on Telegram → `/newbot` →
   copy the token. Then message your new bot once (anything), and hit
   `https://api.telegram.org/bot<TOKEN>/getUpdates` in a browser to read
   back your `chat.id`. (Same pattern as your trading bot's `telegram_agent.py`.)
8. **Get an Anthropic API key** from console.anthropic.com if you don't
   already have one you want to use for this.
9. **Open the app**, tap "Grant Notification Access" (opens a system
   settings screen — Android doesn't allow a permission popup for this),
   enable Site Watch there.
10. Fill in the API key, bot token, chat ID, your exact site group names
    (comma-separated — must match the WhatsApp group title character for
    character), and your interval in hours. Tap Save.

### If the Actions build fails

I ran the Gradle configuration locally to catch script errors, but I
couldn't run the actual Android SDK compile step in this sandbox (no SDK
here) — so treat the very first CI run as the real first compile. If it
fails, open the failed step's log and paste me the error; it's almost
always one of: an SDK/build-tools version mismatch (easy one-line fix in
the workflow file) or a dependency version bump needed. Nothing structural
should be wrong.

### Making a code change later

Any time you edit a `.kt` file (through GitHub's web editor — click a file,
pencil icon, edit, commit directly to `main`), the workflow re-runs
automatically and a fresh APK artifact appears. No local machine needed for
the whole lifecycle.

## Things to know before you rely on this

- **Notification suppression**: some OEMs (Xiaomi/MIUI, Oppo, Vivo, some
  Samsung One UI versions) kill background notification listeners
  aggressively. You'll likely need to disable battery optimization for
  this app specifically, and possibly enable "autostart"/"lock the app"
  in your phone's recent-apps view. Test for a day before trusting it.
- **Coverage isn't guaranteed 100%**: if a chat is open on-screen when a
  message arrives, some devices don't post a notification for it at all.
  This is a monitoring aid, not an audit-grade log — for anything
  compliance-critical, keep your existing DPR/Excel workflow as the source
  of truth.
- **Group name matching is exact-string**: if a site group gets renamed,
  update the settings field or messages from it will silently stop being
  captured (no error, they'll just not match the filter).
- **API costs**: every report cycle makes one Claude API call per run (not
  per message), batching all sites together — cheap at typical WhatsApp
  message volumes, but keep an eye on token usage if some sites are very
  chatty.
- **Data handling**: this sends your site group chat content to Anthropic's
  API (for extraction) and to Telegram (for delivery) — both under your own
  accounts/keys, nothing to a third party. Still, if any group members would
  object to their messages being run through an AI summarizer, worth a
  heads-up to the team.
- **Telegram message formatting** uses Markdown; if a message contains
  characters like `_` or `*` from the raw chat text, Telegram may reject or
  mis-render that particular send — a robustness item to harden later if it
  comes up.

## Natural next steps (not built yet)

- A "test extraction now" button in the app so you're not waiting for the
  first scheduled interval to see it work.
- Per-site custom fields (right now it's generic TPH/issues/pending/summary
  for every site — you may want fuel-factor or DPR-specific fields per your
  existing dashboard).
- Boot receiver to re-schedule the WorkManager job after a phone restart
  (currently relies on WorkManager's own persistence, which usually
  survives reboots, but a `BOOT_COMPLETED` receiver that re-enqueues is a
  useful belt-and-suspenders addition).
