// This is a REFERENCE app/build.gradle.kts.
// When you create the new project in Android Studio ("Empty Views Activity",
// Kotlin, package com.abhi.sitewatch), merge these plugins/dependencies into
// the generated file rather than replacing it wholesale (min/target/compile
// SDK versions etc. are already set up correctly by the wizard).

plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
    id("org.jetbrains.kotlin.kapt") // required for Room's annotation processor
}

android {
    namespace = "com.abhi.sitewatch"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.abhi.sitewatch"
        minSdk = 26
        targetSdk = 34
        versionCode = 1
        versionName = "1.0"
    }

    buildTypes {
        release {
            isMinifyEnabled = false
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_1_8
        targetCompatibility = JavaVersion.VERSION_1_8
    }

    kotlinOptions {
        jvmTarget = "1.8"
    }
}

dependencies {
    implementation("androidx.core:core-ktx:1.13.1")
    implementation("androidx.appcompat:appcompat:1.7.0")
    implementation("com.google.android.material:material:1.12.0")

    // Background scheduling for the periodic report
    implementation("androidx.work:work-runtime-ktx:2.9.1")

    // Local message storage
    implementation("androidx.room:room-runtime:2.6.1")
    implementation("androidx.room:room-ktx:2.6.1")
    kapt("androidx.room:room-compiler:2.6.1")

    // HTTP calls to Anthropic + Telegram
    implementation("com.squareup.okhttp3:okhttp:4.12.0")

    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-android:1.8.1")
}
