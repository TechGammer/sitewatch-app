package com.abhi.sitewatch

import android.app.Notification
import android.app.Person
import android.os.Bundle
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification
import com.abhi.sitewatch.data.AppDatabase
import com.abhi.sitewatch.data.SiteMessage
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

/**
 * Passively listens for WhatsApp notifications and pulls out individual
 * messages using Android's MessagingStyle notification extras (the same
 * mechanism WhatsApp uses to show "sender: message" lines in a group
 * notification). This does NOT open WhatsApp or read the chat screen.
 *
 * Known limitations (be aware of these, don't expect 100% capture):
 *  - If a chat is open on screen, some OEMs suppress its notification.
 *  - Very old / heavily-customized ROMs may not populate EXTRA_MESSAGES.
 *  - If the user clears notifications before this fires, that's fine —
 *    onNotificationPosted already ran and the DB copy is independent —
 *    but if the service was disabled/killed during that window, it's lost.
 *  - This must be re-enabled manually after "Notification access" is
 *    revoked by battery optimizers on some Chinese OEMs (Xiaomi/Oppo/Vivo).
 */
class NotificationCaptureService : NotificationListenerService() {

    private val scope = CoroutineScope(Dispatchers.IO)

    companion object {
        private const val WHATSAPP_PACKAGE = "com.whatsapp"
        private const val WHATSAPP_BUSINESS_PACKAGE = "com.whatsapp.w4b"
    }

    override fun onNotificationPosted(sbn: StatusBarNotification) {
        if (sbn.packageName != WHATSAPP_PACKAGE && sbn.packageName != WHATSAPP_BUSINESS_PACKAGE) {
            return
        }

        val settings = SettingsStore(applicationContext)
        val watchedGroups = settings.siteGroupNameList()

        val extras = sbn.notification.extras
        val conversationTitle = extras.getCharSequence(Notification.EXTRA_CONVERSATION_TITLE)?.toString()
            ?: extras.getCharSequence(Notification.EXTRA_TITLE)?.toString()
            ?: return

        // Only store messages from groups you've configured. Empty list = watch everything.
        if (watchedGroups.isNotEmpty() && conversationTitle !in watchedGroups) return

        val messages = extractMessagingStyleMessages(extras)
        if (messages.isEmpty()) return

        val dao = AppDatabase.getInstance(applicationContext).messageDao()
        scope.launch {
            for (msg in messages) {
                val dup = dao.countDuplicate(conversationTitle, msg.text, msg.timestamp)
                if (dup == 0) {
                    dao.insert(
                        SiteMessage(
                            groupName = conversationTitle,
                            sender = msg.sender,
                            text = msg.text,
                            timestamp = msg.timestamp
                        )
                    )
                }
            }
        }
    }

    private data class ExtractedMsg(val sender: String, val text: String, val timestamp: Long)

    /**
     * WhatsApp posts group messages using NotificationCompat.MessagingStyle,
     * which Android flattens into a Bundle array under EXTRA_MESSAGES with
     * keys "text", "time", and "sender_person" (or "sender" on older
     * versions). Reading it this way avoids needing an AndroidX dependency
     * just to parse extras.
     */
    private fun extractMessagingStyleMessages(extras: Bundle): List<ExtractedMsg> {
        val result = mutableListOf<ExtractedMsg>()
        val messagesArray = extras.getParcelableArray(Notification.EXTRA_MESSAGES) ?: return result

        for (item in messagesArray) {
            val bundle = item as? Bundle ?: continue
            val text = bundle.getCharSequence("text")?.toString() ?: continue
            val timestamp = bundle.getLong("time")
            val senderPerson = bundle.getParcelable<Person>("sender_person")
            val sender = senderPerson?.name?.toString()
                ?: bundle.getCharSequence("sender")?.toString()
                ?: "Unknown"
            result.add(ExtractedMsg(sender, text, timestamp))
        }
        return result
    }
}
