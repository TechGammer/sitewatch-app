package com.abhi.sitewatch

import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.work.Constraints
import androidx.work.ExistingPeriodicWorkPolicy
import androidx.work.NetworkType
import androidx.work.PeriodicWorkRequestBuilder
import androidx.work.WorkManager
import com.abhi.sitewatch.worker.ReportWorker
import java.util.concurrent.TimeUnit

class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val settings = SettingsStore(this)

        val apiKeyField = findViewById<EditText>(R.id.apiKeyField)
        val botTokenField = findViewById<EditText>(R.id.botTokenField)
        val chatIdField = findViewById<EditText>(R.id.chatIdField)
        val groupNamesField = findViewById<EditText>(R.id.groupNamesField)
        val intervalField = findViewById<EditText>(R.id.intervalField)

        apiKeyField.setText(settings.anthropicApiKey)
        botTokenField.setText(settings.telegramBotToken)
        chatIdField.setText(settings.telegramChatId)
        groupNamesField.setText(settings.siteGroupNames)
        intervalField.setText(settings.reportIntervalHours.toString())

        findViewById<Button>(R.id.notifAccessButton).setOnClickListener {
            startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS))
        }

        findViewById<Button>(R.id.saveButton).setOnClickListener {
            settings.anthropicApiKey = apiKeyField.text.toString().trim()
            settings.telegramBotToken = botTokenField.text.toString().trim()
            settings.telegramChatId = chatIdField.text.toString().trim()
            settings.siteGroupNames = groupNamesField.text.toString().trim()
            val interval = intervalField.text.toString().toIntOrNull() ?: 6
            settings.reportIntervalHours = interval

            scheduleReportWorker(interval)
            Toast.makeText(this, "Saved. Reports scheduled every ${interval}h.", Toast.LENGTH_LONG).show()
        }
    }

    private fun scheduleReportWorker(intervalHours: Int) {
        val safeInterval = intervalHours.coerceAtLeast(1) // WorkManager minimum is 15 min anyway
        val request = PeriodicWorkRequestBuilder<ReportWorker>(safeInterval.toLong(), TimeUnit.HOURS)
            .setConstraints(
                Constraints.Builder()
                    .setRequiredNetworkType(NetworkType.CONNECTED)
                    .build()
            )
            .build()

        WorkManager.getInstance(this).enqueueUniquePeriodicWork(
            "sitewatch_report",
            ExistingPeriodicWorkPolicy.UPDATE,
            request
        )
    }
}
