package com.abhi.sitewatch.worker

import android.content.Context
import androidx.work.CoroutineWorker
import androidx.work.WorkerParameters
import com.abhi.sitewatch.SettingsStore
import com.abhi.sitewatch.data.AppDatabase
import com.abhi.sitewatch.network.ClaudeExtractor
import com.abhi.sitewatch.network.TelegramSender
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class ReportWorker(context: Context, params: WorkerParameters) : CoroutineWorker(context, params) {

    override suspend fun doWork(): Result {
        val settings = SettingsStore(applicationContext)

        if (settings.anthropicApiKey.isBlank() || settings.telegramBotToken.isBlank() || settings.telegramChatId.isBlank()) {
            // Not configured yet — don't burn retries on a config problem.
            return Result.success()
        }

        val dao = AppDatabase.getInstance(applicationContext).messageDao()
        val unreported = dao.getUnreported()
        if (unreported.isEmpty()) return Result.success()

        val grouped: Map<String, List<String>> = unreported
            .groupBy { it.groupName }
            .mapValues { (_, msgs) -> msgs.map { "${it.sender}: ${it.text}" } }

        return try {
            val rawJson = ClaudeExtractor.extractStructuredReport(
                apiKey = settings.anthropicApiKey,
                groupedMessages = grouped
            )
            val formatted = formatForTelegram(rawJson)
            TelegramSender.send(settings.telegramBotToken, settings.telegramChatId, formatted)
            dao.markReported(unreported.map { it.id })
            Result.success()
        } catch (e: Exception) {
            Result.retry()
        }
    }

    private fun formatForTelegram(rawJson: String): String {
        val timestamp = SimpleDateFormat("dd MMM, HH:mm", Locale.getDefault()).format(Date())
        return try {
            val json = JSONObject(rawJson)
            val sites = json.getJSONArray("sites")
            val sb = StringBuilder("*Site Watch Report — $timestamp*\n\n")
            for (i in 0 until sites.length()) {
                val s = sites.getJSONObject(i)
                sb.append("*${s.getString("site")}*\n")
                sb.append("TPH: ${s.optString("tph", "not mentioned")}\n")
                sb.append("Summary: ${s.optString("summary", "-")}\n")

                val issues = s.optJSONArray("issues")
                if (issues != null && issues.length() > 0) {
                    sb.append("Issues:\n")
                    for (j in 0 until issues.length()) sb.append("  • ${issues.getString(j)}\n")
                }
                val pending = s.optJSONArray("pending")
                if (pending != null && pending.length() > 0) {
                    sb.append("Pending:\n")
                    for (j in 0 until pending.length()) sb.append("  • ${pending.getString(j)}\n")
                }
                sb.append("\n")
            }
            sb.toString()
        } catch (e: Exception) {
            "*Site Watch Report — $timestamp* (raw, structured parse failed)\n\n$rawJson"
        }
    }
}
