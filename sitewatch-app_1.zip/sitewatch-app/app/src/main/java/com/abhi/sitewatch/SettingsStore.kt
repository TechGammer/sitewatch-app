package com.abhi.sitewatch

import android.content.Context
import android.content.SharedPreferences

/**
 * Plain SharedPreferences for now. If you want this hardened later, switch to
 * EncryptedSharedPreferences (androidx.security:security-crypto) since this
 * file holds your Anthropic API key and Telegram bot token in cleartext.
 */
class SettingsStore(context: Context) {

    private val prefs: SharedPreferences =
        context.getSharedPreferences("sitewatch_settings", Context.MODE_PRIVATE)

    var anthropicApiKey: String
        get() = prefs.getString("anthropic_api_key", "") ?: ""
        set(value) = prefs.edit().putString("anthropic_api_key", value).apply()

    var telegramBotToken: String
        get() = prefs.getString("telegram_bot_token", "") ?: ""
        set(value) = prefs.edit().putString("telegram_bot_token", value).apply()

    var telegramChatId: String
        get() = prefs.getString("telegram_chat_id", "") ?: ""
        set(value) = prefs.edit().putString("telegram_chat_id", value).apply()

    // Comma-separated, must match WhatsApp group titles EXACTLY, e.g:
    // "Site A Crusher,Site B Crusher,Site C Crusher"
    // Leave blank to watch every WhatsApp group (not recommended).
    var siteGroupNames: String
        get() = prefs.getString("site_group_names", "") ?: ""
        set(value) = prefs.edit().putString("site_group_names", value).apply()

    var reportIntervalHours: Int
        get() = prefs.getInt("report_interval_hours", 6)
        set(value) = prefs.edit().putInt("report_interval_hours", value).apply()

    fun siteGroupNameList(): List<String> =
        siteGroupNames.split(",").map { it.trim() }.filter { it.isNotEmpty() }
}
