package com.abhi.sitewatch.network

import okhttp3.Call
import okhttp3.Callback
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import okhttp3.Response
import org.json.JSONArray
import org.json.JSONObject
import java.io.IOException
import kotlin.coroutines.resume
import kotlin.coroutines.resumeWithException
import kotlin.coroutines.suspendCoroutine

/**
 * Sends the batch of unreported messages, grouped by site/group name, to
 * Claude and asks for structured JSON back. Uses your own Anthropic API key
 * (entered in the app's settings screen) — nothing is proxied anywhere else.
 */
object ClaudeExtractor {

    private val client = OkHttpClient()
    private const val ENDPOINT = "https://api.anthropic.com/v1/messages"
    private const val MODEL = "claude-sonnet-5"

    private val SYSTEM_PROMPT = """
        You are extracting a structured operations report from raw WhatsApp
        group chat text for a crusher operations business with multiple sites.
        Each SITE section below contains raw messages from that site's group
        since the last report. For each site, extract:
        - tph: any tonnage/TPH figures mentioned (or "not mentioned")
        - issues: breakdowns, delays, or problems raised (short phrases)
        - pending: action items or requests still open/unresolved
        - summary: one line on overall status for that site
        If a site section has no substantive operational content, still
        include it with summary "no notable updates".
        Respond ONLY with valid JSON, no markdown fences, no preamble, in
        exactly this shape:
        {"sites": [{"site": "...", "tph": "...", "issues": ["..."], "pending": ["..."], "summary": "..."}]}
    """.trimIndent()

    // groupedMessages: site/group name -> list of "sender: text" lines
    suspend fun extractStructuredReport(
        apiKey: String,
        groupedMessages: Map<String, List<String>>
    ): String {
        val sitesBlock = groupedMessages.entries.joinToString("\n\n") { (site, lines) ->
            "SITE: $site\n" + lines.joinToString("\n")
        }

        val payload = JSONObject().apply {
            put("model", MODEL)
            put("max_tokens", 1500)
            put("system", SYSTEM_PROMPT)
            put(
                "messages",
                JSONArray().put(
                    JSONObject().apply {
                        put("role", "user")
                        put("content", sitesBlock)
                    }
                )
            )
        }

        val request = Request.Builder()
            .url(ENDPOINT)
            .addHeader("x-api-key", apiKey)
            .addHeader("anthropic-version", "2023-06-01")
            .addHeader("content-type", "application/json")
            .post(payload.toString().toRequestBody("application/json".toMediaType()))
            .build()

        return suspendCoroutine { cont ->
            client.newCall(request).enqueue(object : Callback {
                override fun onFailure(call: Call, e: IOException) {
                    cont.resumeWithException(e)
                }

                override fun onResponse(call: Call, response: Response) {
                    response.use {
                        val raw = it.body?.string() ?: "{}"
                        try {
                            if (!it.isSuccessful) {
                                cont.resumeWithException(IOException("Anthropic API error ${it.code}: $raw"))
                                return
                            }
                            val json = JSONObject(raw)
                            val content = json.getJSONArray("content")
                            val text = content.getJSONObject(0).getString("text")
                            cont.resume(text)
                        } catch (e: Exception) {
                            cont.resumeWithException(e)
                        }
                    }
                }
            })
        }
    }
}
