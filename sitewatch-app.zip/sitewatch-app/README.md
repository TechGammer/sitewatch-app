# Site Watch

An Android app that watches your per-site WhatsApp groups, and on a schedule,
sends you a structured report (TPH, issues, pending items) to Telegram — a
separate personal project, not part of WhatsClaw.

## How it works

```
WhatsApp posts a notification
        │
        ▼
NotificationCaptureService (NotificationListenerService)
  - detects the group automatically (SiteNameExtractor cleans a
    default display name), stored in the `sites` table
  - untracked by default — nothing is stored until you opt a group in
  - once tracked: pulls sender + text + time out of the notification's
    MessagingStyle data (no need to open WhatsApp) into `site_messages`
        │
        ▼
ChatActivity — the whole control surface
  - you type things like "what groups have you seen", "track Site A",
    "rename Site B to Crusher North", "generate a report", "send
    reports every 4 hours except 10pm-7am"
  - Claude (Anthropic Messages API, tool use) calls real tools that
    read/write the Room DB, WorkManager schedule, and Telegram config —
    see ChatTools.kt for the full list: list_sites, upsert_site,
    delete_site, get_recent_messages, generate_report, get_schedule,
    set_schedule, get_telegram_config, set_telegram_config
  - chat history (including tool calls) persists across app restarts
        │
        ▼   (on your configured interval, via WorkManager)
ReportWorker → ReportGenerator (same code path chat's generate_report uses)
  - groups unreported messages by tracked site
  - sends the batch to Claude with a prompt asking for
    {tph, issues, pending, summary} per site
  - formats the JSON into a readable message, sends to Telegram
  - skips the cycle if it falls inside your configured quiet hours
```

Nothing is opened or automated on WhatsApp's UI — this only reads
notification content, which is why it's much lower-risk than a
WhatsApp-Web-automation approach (Baileys, whatsapp-web.js, etc.) for
your own personal number.

The only screen outside chat is a one-time Setup screen (`MainActivity`)
for the Anthropic API key and notification-access permission — both
things chat can't bootstrap itself. Telegram bot token/chat ID can be
set there too, or from chat via `set_telegram_config`.

## Smarter, calculative, history-aware

Every generated report is persisted per site (`ReportEntity`/`ReportDao`),
not just formatted and thrown away. That history is what powers:

- **Trend-aware reports**: each new extraction is given the previous
  report as context, so summaries note real changes ("TPH down from 180
  to 140") instead of being disconnected snapshots.
- **Numeric TPH tracking**: `TphParser` best-effort parses a number out of
  the TPH text so trends can actually be computed, not just eyeballed.
- **Automatic alerts**: a report drop of 20%+ since the last reading, or a
  tracked site going quiet for 48h+, gets flagged with a ⚠️ *Alerts*
  section — on both scheduled and on-demand reports.
- **`get_site_history` / `get_alerts` chat tools** let you ask about
  trends over a longer window, or "anything I should worry about?"
  without generating a fresh report.
- **Dashboard screen** (`DashboardActivity`): a read-only overview of
  tracked sites — last TPH + trend arrow, time since last report, open
  pending count, a quiet-site warning — derived from the same tables chat
  reads/writes, so it can't drift out of sync. Tapping a site jumps into
  chat with "What's the latest at [site]?" pre-filled and sent.
- **Chat history is capped** at the last 40 API turns sent to Claude (full
  history still shown in the UI) so cost/context don't grow unbounded
  over months of use — cut safely at message boundaries, never mid tool-call.

Worth being precise about what this is *not*: there's no machine-learning
model being trained on your data. "Learning from history" here means
structured past reports get fed back into Claude's context so it can
reason over them — which is honest and works well, but it's not a system
that adapts its own thresholds or behavior over time without you changing
them (schedule, alert sensitivity, etc. are still fixed in code/settings).

## Everything configurable from chat — and the honest limit of that

Every tunable in the app is now chat-controllable, not just operational
data:
- Alert thresholds (`set_alert_settings`): TPH drop %, quiet-site hours,
  idle-alert window
- Fast-alert keyword list and debounce (`set_fast_alert_settings`)
- Which Claude model runs chat/extraction (`set_model`: sonnet/haiku/opus)
- Which extra fields get extracted per report beyond TPH/issues/pending/
  status (`add_report_field`/`remove_report_field`, e.g. "fuel_factor" —
  stored in a generic `extraFieldsJson` column, no schema migration needed
  per field)

Two things are **not** chat-controllable, and can't be — this is a real
constraint, not a gap I just haven't gotten to: the Anthropic API key
(chat needs it to exist before it can do anything) and notification-access
permission (Android only exposes that via a system settings screen, no
in-app permission API for it).

## "Creating screens" — what's actually true here

A compiled Android app can't have an LLM generate new native screens at
runtime; that needs a rebuild + reinstall, which isn't an in-chat action.
What's real: `DynamicViewActivity` is one generic screen that renders
whatever self-contained HTML Claude generates via the `show_custom_view`
tool — tables, comparison cards, simple bar-style visuals — immediately,
no rebuild needed. It's a web view being handed content, not a new native
screen, but it delivers the actual outcome (a custom visual for whatever
was asked) rather than just text. Network loads are blocked in that
WebView, so generated content can't fetch anything external. A small JS
bridge lets a generated button hand text back to chat as the next message
(`Android.sendToChat('...')`) — the same mechanism the dashboard uses when
you tap a site.

## Plant status, running hours, and breakdown alerts

Each report extraction now also pulls out **status events** — RUNNING /
IDLE / BREAKDOWN / STOPPED, with a reason if one was given — from the raw
messages (English, Hindi, Marathi, or a mix; "chalu" = running, "band" =
stopped, "kharaab" = broken down, etc.). These are persisted per site
(`StatusEventEntity`) and power:

- **`get_current_status`** — what's the plant doing right now, and how
  long has it held that status.
- **`get_running_hours`** — hours by status (running/idle/breakdown/
  stopped) for today, 7 days, 30 days, or all time, computed by treating
  each event as "this status held until the next one."
- **Dashboard status badges** — 🟢 running / 🟡 idle / 🔴 breakdown / ⚪
  stopped / ❔ unknown per site, plus today's running hours, right on the
  site list.
- **Breakdown/idle alerts** — an active BREAKDOWN, or IDLE held for 4-12h,
  gets flagged in the alerts section of every report (scheduled or
  on-demand), same as the TPH-drop and quiet-site alerts.

**A fast, separate path for breakdowns specifically**: because waiting for
the next scheduled report to hear about a breakdown could mean hours of
delay, `NotificationCaptureService` also does a cheap keyword scan on every
new tracked message (English + a handful of common Hindi/Marathi terms —
"breakdown", "kharaab", "band ho", etc.). A match fires an immediate
Telegram ping labeled *"Quick alert (unverified)"*, debounced to once per
30 minutes per site, with no LLM call involved — then the accurate,
AI-extracted version follows in the next report. This keyword list is
short and will miss phrasing it doesn't recognize; it's meant as a fast
heads-up, not the source of truth.

**Be clear-eyed about accuracy here**: running hours and current status
are only as good as what people actually type in the group. There's no
telemetry, no sensor feed — if a shift runs the crusher for six hours and
nobody posts anything, that time gets attributed to whatever the last
reported status was (usually a reasonable assumption — "still running,
nobody said otherwise" — but not guaranteed correct). Treat these numbers
as a useful estimate from chat activity, not an auditable log.

## Building it — no Android Studio needed

This project is already a complete, self-contained Gradle project (real
`gradlew`/wrapper included, generated and smoke-tested against Gradle 8.7 —
`./gradlew assembleDebug` gets all the way to needing an actual Android SDK,
which only exists in the cloud runner). You don't need Android Studio or any
local Android tooling at all. The build itself runs on GitHub's free cloud
runners via GitHub Actions.

1. **Create a free GitHub account** at github.com if you don't have one.
2. **Create a new repository** (Add → New repository). Public is fine and
   gives unlimited free Actions minutes; private also gets a generous free
   tier.
3. **Upload the project**: unzip `sitewatch-app.zip` on your laptop, then on
   your repo's page use "Add file → Upload files" and drag the *contents* of
   the unzipped `sitewatch-app` folder in (including the hidden `.github`
   folder — if your OS hides it, use your file manager's "show hidden files"
   option). Commit.
4. **Check the Actions tab.** Pushing the files should auto-trigger the
   "Build APK" workflow (`.github/workflows/build.yml`). Open the Actions
   tab → click the running/completed workflow → wait for the green check
   (first run: a few minutes, mostly SDK download).
5. **Download the APK**: on that same workflow run page, scroll to
   "Artifacts" → download `sitewatch-debug-apk` → unzip it to get
   `app-debug.apk`.
6. **Get it onto your phone**: email it to yourself, or upload to Google
   Drive and download on-phone, or plug in via USB. Then tap the file to
   install — you'll need to allow "install unknown apps" for whichever app
   you opened it with (Files, Chrome, Gmail, etc.), Android will prompt you
   for this the first time.
7. **Create a Telegram bot**: message `@BotFather` on Telegram → `/newbot` →
   copy the token. Then message your new bot once (anything), and hit
   `https://api.telegram.org/bot<TOKEN>/getUpdates` in a browser to read
   back your `chat.id`. (Same pattern as your trading bot's `telegram_agent.py`.)
8. **Get an Anthropic API key** from console.anthropic.com if you don't
   already have one you want to use for this.
9. **Open the app**, tap "Grant Notification Access" (opens a system
   settings screen — Android doesn't allow a permission popup for this),
   enable Site Watch there.
10. Fill in the API key (and Telegram bot token/chat ID if you want them
    set here rather than via chat later). Tap **Save & Open Chat**.
11. In chat, once WhatsApp has posted a few notifications, ask "what
    groups have you seen so far?" — then tell it which ones to track,
    e.g. "track the Site A Crusher group as Site A" and "send reports
    every 6 hours, quiet between 10pm and 7am".

### If the Actions build fails

I ran the Gradle configuration locally to catch script errors, but I
couldn't run the actual Android SDK compile step in this sandbox (no SDK
here) — so treat the very first CI run as the real first compile. If it
fails, open the failed step's log and paste me the error; it's almost
always one of: an SDK/build-tools version mismatch (easy one-line fix in
the workflow file) or a dependency version bump needed. Nothing structural
should be wrong.

### Making a code change later

Any time you edit a `.kt` file (through GitHub's web editor — click a file,
pencil icon, edit, commit directly to `main`), the workflow re-runs
automatically and a fresh APK artifact appears. No local machine needed for
the whole lifecycle.

## Things to know before you rely on this

- **Notification suppression**: some OEMs (Xiaomi/MIUI, Oppo, Vivo, some
  Samsung One UI versions) kill background notification listeners
  aggressively. You'll likely need to disable battery optimization for
  this app specifically, and possibly enable "autostart"/"lock the app"
  in your phone's recent-apps view. Test for a day before trusting it.
- **Coverage isn't guaranteed 100%**: if a chat is open on-screen when a
  message arrives, some devices don't post a notification for it at all.
  This is a monitoring aid, not an audit-grade log — for anything
  compliance-critical, keep your existing DPR/Excel workflow as the source
  of truth.
- **Group name matching is exact-string**: if a site group gets renamed,
  update the settings field or messages from it will silently stop being
  captured (no error, they'll just not match the filter).
- **API costs**: every report cycle makes one Claude API call per run (not
  per message), batching all sites together — cheap at typical WhatsApp
  message volumes, but keep an eye on token usage if some sites are very
  chatty.
- **Data handling**: this sends your site group chat content to Anthropic's
  API (for extraction) and to Telegram (for delivery) — both under your own
  accounts/keys, nothing to a third party. Still, if any group members would
  object to their messages being run through an AI summarizer, worth a
  heads-up to the team.
- **Telegram message formatting** uses Markdown; if a message contains
  characters like `_` or `*` from the raw chat text, Telegram may reject or
  mis-render that particular send — a robustness item to harden later if it
  comes up.

## Natural next steps (not built yet)

- A "test extraction now" button in the app so you're not waiting for the
  first scheduled interval to see it work.
- Per-site custom fields (right now it's generic TPH/issues/pending/summary
  for every site — you may want fuel-factor or DPR-specific fields per your
  existing dashboard).
- Boot receiver to re-schedule the WorkManager job after a phone restart
  (currently relies on WorkManager's own persistence, which usually
  survives reboots, but a `BOOT_COMPLETED` receiver that re-enqueues is a
  useful belt-and-suspenders addition).
