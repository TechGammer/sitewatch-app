package com.abhi.sitewatch.worker

import com.abhi.sitewatch.data.SiteMessage
import com.abhi.sitewatch.data.StatusKeywordEntity

/**
 * Deterministic plant-status detection straight from raw WhatsApp messages,
 * so a site can report a real status even when no report has been generated
 * yet (status_events is only written during report extraction, so a site
 * with plenty of messages but no report used to read as UNKNOWN).
 *
 * Handles English, Hindi, Hinglish and Marathi phrasing. Matching is
 * word-boundary based, never raw substring: "jam" must not match inside
 * "Jamnagar" (a real site name here), and "run" must not match inside
 * "running hours" headers in a different sense. Deliberately conservative —
 * a miss returns null, which the caller reports honestly, rather than
 * producing a confident wrong status.
 */
object PlantStatusDetector {

    data class Hit(
        val status: String,
        val timestamp: Long,
        val sender: String,
        val text: String
    )

    private fun words(vararg terms: String): Regex =
        Regex("\\b(" + terms.joinToString("|") { Regex.escape(it) } + ")\\b", RegexOption.IGNORE_CASE)

    // Within a single message these are checked in this order: an explicit
    // breakdown mention outranks a generic "band" (stopped), which outranks
    // idle, which outranks running — because a message like "belt jam, plant
    // band" is really a breakdown, not a clean shutdown.
    private val BREAKDOWN = words(
        "breakdown", "break down", "kharab", "kharaab", "kharb", "fault", "faulty",
        "jam", "jaam", "choke", "chokeup", "choke up", "repair", "repairing",
        "not working", "band ho gaya", "band pad gaya", "breakdown hai"
    )
    private val STOPPED = words(
        "stopped", "stop", "shutdown", "shut down", "band", "bandh", "closed",
        "band hai", "band pada", "bandh ahe", "off hai", "plant off", "shutoff"
    )
    private val IDLE = words(
        "idle", "khali", "no feed", "without feed", "waiting", "standby",
        "halt", "halted", "feed nahi", "material nahi"
    )
    private val RUNNING = words(
        "running", "chalu", "chaalu", "chal raha", "chalu hai", "chalu ahe",
        "started", "start", "shuru", "plant on", "normal running", "running hai"
    )

    /**
     * The newest message that clearly indicates a status, or null if none do.
     * Scans newest-first so the most recent signal wins — that's what
     * "current status" means here. [groupName] + [customKeywords] let a
     * business's own taught phrasing (chat's add_status_keyword) override
     * the generic built-in list for this specific site.
     */
    fun detectLatest(
        messages: List<SiteMessage>,
        groupName: String? = null,
        customKeywords: List<StatusKeywordEntity> = emptyList()
    ): Hit? {
        val applicable = customKeywords.filter { it.groupName == null || it.groupName == groupName }
        for (m in messages.sortedByDescending { it.timestamp }) {
            val status = classify(m.text, applicable) ?: continue
            return Hit(status, m.timestamp, m.sender, m.text)
        }
        return null
    }

    fun classify(text: String, customKeywords: List<StatusKeywordEntity> = emptyList()): String? {
        // Taught phrases win first — checked longest-first so a more specific
        // taught phrase isn't shadowed by a shorter one also present.
        for (kw in customKeywords.sortedByDescending { it.phrase.length }) {
            if (Regex("\\b" + Regex.escape(kw.phrase) + "\\b", RegexOption.IGNORE_CASE).containsMatchIn(text)) {
                return kw.status
            }
        }
        return when {
            BREAKDOWN.containsMatchIn(text) -> "BREAKDOWN"
            STOPPED.containsMatchIn(text) -> "STOPPED"
            IDLE.containsMatchIn(text) -> "IDLE"
            RUNNING.containsMatchIn(text) -> "RUNNING"
            else -> null
        }
    }
}
