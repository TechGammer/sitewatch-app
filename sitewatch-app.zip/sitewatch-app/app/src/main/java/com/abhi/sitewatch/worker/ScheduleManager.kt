package com.abhi.sitewatch.worker

import android.content.Context
import androidx.work.Constraints
import androidx.work.ExistingPeriodicWorkPolicy
import androidx.work.NetworkType
import androidx.work.PeriodicWorkRequestBuilder
import androidx.work.WorkManager
import com.abhi.sitewatch.SettingsStore
import java.util.concurrent.TimeUnit

/**
 * Single place that knows how to (re)schedule the periodic report worker.
 * Called from initial app setup and from the `set_schedule` chat tool so
 * there's exactly one code path for this.
 */
object ScheduleManager {

    private const val WORK_NAME = "sitewatch_report"

    fun applyCurrentSchedule(context: Context) {
        val settings = SettingsStore(context)
        schedule(context, settings.reportIntervalHours)
    }

    fun schedule(context: Context, intervalHours: Int) {
        val safeInterval = intervalHours.coerceIn(1, 24 * 7)
        SettingsStore(context).reportIntervalHours = safeInterval

        val request = PeriodicWorkRequestBuilder<ReportWorker>(safeInterval.toLong(), TimeUnit.HOURS)
            .setConstraints(
                Constraints.Builder()
                    .setRequiredNetworkType(NetworkType.CONNECTED)
                    .build()
            )
            .build()

        WorkManager.getInstance(context).enqueueUniquePeriodicWork(
            WORK_NAME,
            ExistingPeriodicWorkPolicy.UPDATE,
            request
        )
    }

    fun cancel(context: Context) {
        WorkManager.getInstance(context).cancelUniqueWork(WORK_NAME)
    }
}
