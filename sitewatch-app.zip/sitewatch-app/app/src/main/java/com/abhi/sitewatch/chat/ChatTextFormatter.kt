package com.abhi.sitewatch.chat

import android.graphics.Typeface
import android.text.Spannable
import android.text.SpannableStringBuilder
import android.text.style.RelativeSizeSpan
import android.text.style.StyleSpan
import android.text.style.TypefaceSpan

/**
 * Lightweight Markdown → styled text for chat bubbles. The chat models
 * (especially the free-tier ones routed via openrouter/free) reliably emit
 * Markdown — bold, headings, bullet lists — no matter what the system
 * prompt says, so rather than fight it we render a practical subset here so
 * replies look clean instead of showing literal ** and # characters (which
 * is what users were seeing). Deliberately dependency-free (no Markwon) to
 * keep the CI build simple.
 *
 * Handles: # headings, - / * / + bullets (→ •), --- horizontal rules,
 * **bold** / __bold__, *italic*, and `code`. Emoji pass through untouched
 * and render natively.
 */
object ChatTextFormatter {

    private val HEADING = Regex("^\\s{0,3}(#{1,6})\\s+(.*)$")
    private val BULLET = Regex("^(\\s{0,6})[-*+]\\s+(.*)$")
    private val HRULE = Regex("^\\s{0,3}([-*_])\\1{2,}\\s*$")

    fun format(raw: String): CharSequence {
        val out = SpannableStringBuilder()
        val lines = raw.replace("\r\n", "\n").replace("\r", "\n").split("\n")
        for ((index, original) in lines.withIndex()) {
            if (index > 0) out.append("\n")
            var line = original

            if (HRULE.matches(line)) {
                out.append("──────────")
                continue
            }

            var header = false
            HEADING.find(line)?.let {
                header = true
                line = it.groupValues[2]
            }

            if (!header) {
                BULLET.find(line)?.let {
                    // Preserve a little indentation for nested bullets.
                    val indent = if (it.groupValues[1].length >= 4) "    " else ""
                    out.append("$indent•  ")
                    line = it.groupValues[2]
                }
            }

            val start = out.length
            appendInline(out, line)
            if (header) {
                out.setSpan(StyleSpan(Typeface.BOLD), start, out.length, Spannable.SPAN_EXCLUSIVE_EXCLUSIVE)
                out.setSpan(RelativeSizeSpan(1.12f), start, out.length, Spannable.SPAN_EXCLUSIVE_EXCLUSIVE)
            }
        }
        return out
    }

    /**
     * Converts our internal Markdown into WhatsApp's own formatting syntax
     * (single *bold*, not double **bold**) so a copied report or reply
     * renders bold/italic correctly once pasted and sent in WhatsApp,
     * instead of showing literal double asterisks there. Headings become
     * bold lines (WhatsApp has no heading concept); bullets become a plain
     * "• " prefix, which WhatsApp displays as-is.
     */
    fun toWhatsAppText(raw: String): String {
        val lines = raw.replace("\r\n", "\n").replace("\r", "\n").split("\n")
        val out = StringBuilder()
        for ((index, original) in lines.withIndex()) {
            if (index > 0) out.append("\n")
            var line = original

            if (HRULE.matches(line)) {
                out.append("──────────")
                continue
            }

            var boldWhole = false
            HEADING.find(line)?.let {
                boldWhole = true
                line = it.groupValues[2]
            }
            if (!boldWhole) {
                BULLET.find(line)?.let {
                    val indent = if (it.groupValues[1].length >= 4) "    " else ""
                    out.append("$indent• ")
                    line = it.groupValues[2]
                }
            }

            // **bold**/__bold__ -> WhatsApp's single *bold*; leave single
            // *italic*/`code` markers as-is, since WhatsApp uses the same
            // single-asterisk and backtick syntax itself.
            val converted = line.replace(Regex("\\*\\*(.+?)\\*\\*"), "*$1*")
                .replace(Regex("__(.+?)__"), "*$1*")

            out.append(if (boldWhole) "*$converted*" else converted)
        }
        return out.toString()
    }

    private fun appendInline(out: SpannableStringBuilder, text: String) {
        var i = 0
        val n = text.length
        while (i < n) {
            val c = text[i]

            // **bold**
            if (c == '*' && i + 1 < n && text[i + 1] == '*') {
                val close = text.indexOf("**", i + 2)
                if (close > i + 1) {
                    val s = out.length
                    appendInline(out, text.substring(i + 2, close))
                    out.setSpan(StyleSpan(Typeface.BOLD), s, out.length, Spannable.SPAN_EXCLUSIVE_EXCLUSIVE)
                    i = close + 2
                    continue
                }
            }
            // __bold__
            if (c == '_' && i + 1 < n && text[i + 1] == '_') {
                val close = text.indexOf("__", i + 2)
                if (close > i + 1) {
                    val s = out.length
                    appendInline(out, text.substring(i + 2, close))
                    out.setSpan(StyleSpan(Typeface.BOLD), s, out.length, Spannable.SPAN_EXCLUSIVE_EXCLUSIVE)
                    i = close + 2
                    continue
                }
            }
            // *italic* (single asterisk pair on the same line, no leading space)
            if (c == '*') {
                val close = text.indexOf('*', i + 1)
                if (close > i + 1 && text[i + 1] != ' ') {
                    val s = out.length
                    out.append(text.substring(i + 1, close))
                    out.setSpan(StyleSpan(Typeface.ITALIC), s, out.length, Spannable.SPAN_EXCLUSIVE_EXCLUSIVE)
                    i = close + 1
                    continue
                }
            }
            // `code`
            if (c == '`') {
                val close = text.indexOf('`', i + 1)
                if (close > i) {
                    val s = out.length
                    out.append(text.substring(i + 1, close))
                    out.setSpan(TypefaceSpan("monospace"), s, out.length, Spannable.SPAN_EXCLUSIVE_EXCLUSIVE)
                    i = close + 1
                    continue
                }
            }

            out.append(c)
            i++
        }
    }
}
