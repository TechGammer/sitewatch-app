package com.abhi.sitewatch.network

import okhttp3.Call
import okhttp3.Callback
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import okhttp3.Response
import org.json.JSONArray
import org.json.JSONObject
import java.io.IOException
import kotlin.coroutines.resume
import kotlin.coroutines.resumeWithException
import kotlin.coroutines.suspendCoroutine

/**
 * Sends the batch of unreported messages, grouped by site/group name, to
 * Claude and asks for structured JSON back. Uses your own Anthropic API key
 * (entered in the app's settings screen) — nothing is proxied anywhere else.
 */
object ClaudeExtractor {

    private val client = OkHttpClient()
    private const val ENDPOINT = "https://api.anthropic.com/v1/messages"

    private val BASE_SYSTEM_PROMPT = """
        You are extracting a structured operations report from raw WhatsApp
        group chat text for a crusher operations business with multiple sites.
        Each SITE section below contains raw messages from that site's group
        since the last report, and may also include a PREVIOUS REPORT block
        with what was reported last time.
        For each site, extract:
        - tph: any tonnage/TPH figures mentioned (or "not mentioned")
        - issues: breakdowns, delays, or problems raised (short phrases)
        - pending: action items or requests still open/unresolved — carry
          forward any PREVIOUS REPORT pending items that don't look resolved
          by the new messages, and drop ones that do
        - summary: one line on overall status for that site. If a PREVIOUS
          REPORT block is present, note meaningful changes (TPH trending up
          or down, an issue that recurred, a pending item resolved) rather
          than just restating the current state in isolation.
        - status_events: any plant status changes mentioned, each as
          {"status": one of "RUNNING"/"IDLE"/"BREAKDOWN"/"STOPPED",
           "reason": short phrase or null if not stated,
           "time_hint": whatever time reference was given, e.g. "10:30am",
             "after lunch", or null if not stated}.
          Messages may be in English, Hindi, Marathi, or a mix (e.g. "chalu"
          means running/started, "band"/"bandh" means stopped, "kharaab"
          means broken down) — infer status from meaning, not just English
          keywords. Only include an event if the message actually indicates
          a status change or explicit status statement; don't invent one
          just because TPH or issues were mentioned.
    """.trimIndent()

    // groupedMessages: site/group name -> list of "sender: text" lines
    // previousContext: site/group name -> short text describing the last report for that site (optional)
    // extraFields: additional field names the user has asked to track (e.g. "fuel_factor") —
    //              extracted into a generic "extra" object per site, string values, "not mentioned" if absent
    suspend fun extractStructuredReport(
        apiKey: String,
        model: String,
        groupedMessages: Map<String, List<String>>,
        previousContext: Map<String, String> = emptyMap(),
        extraFields: List<String> = emptyList()
    ): String {
        val sitesBlock = groupedMessages.entries.joinToString("\n\n") { (site, lines) ->
            val previous = previousContext[site]
            buildString {
                append("SITE: $site\n")
                if (previous != null) {
                    append("PREVIOUS REPORT: $previous\n")
                }
                append(lines.joinToString("\n"))
            }
        }

        val extraFieldsInstruction = if (extraFields.isEmpty()) "" else {
            "\nAlso extract these additional fields per site into an \"extra\" object, " +
                "each as a short string value or \"not mentioned\" if absent: ${extraFields.joinToString(", ")}."
        }
        val shapeExtra = if (extraFields.isEmpty()) "" else {
            ", \"extra\": {" + extraFields.joinToString(", ") { "\"$it\": \"...\"" } + "}"
        }
        val systemPrompt = BASE_SYSTEM_PROMPT + extraFieldsInstruction + """

        If a site section has no substantive new operational content, still
        include it with summary "no notable updates" and an empty
        status_events array.
        Respond ONLY with valid JSON, no markdown fences, no preamble, in
        exactly this shape:
        {"sites": [{"site": "...", "tph": "...", "issues": ["..."], "pending": ["..."], "summary": "...", "status_events": [{"status": "...", "reason": null, "time_hint": null}]$shapeExtra}]}
        """.trimIndent()

        val payload = JSONObject().apply {
            put("model", model)
            put("max_tokens", 1500)
            put("system", systemPrompt)
            put(
                "messages",
                JSONArray().put(
                    JSONObject().apply {
                        put("role", "user")
                        put("content", sitesBlock)
                    }
                )
            )
        }

        val request = Request.Builder()
            .url(ENDPOINT)
            .addHeader("x-api-key", apiKey)
            .addHeader("anthropic-version", "2023-06-01")
            .addHeader("content-type", "application/json")
            .post(payload.toString().toRequestBody("application/json".toMediaType()))
            .build()

        return suspendCoroutine { cont ->
            client.newCall(request).enqueue(object : Callback {
                override fun onFailure(call: Call, e: IOException) {
                    cont.resumeWithException(e)
                }

                override fun onResponse(call: Call, response: Response) {
                    response.use {
                        val raw = it.body?.string() ?: "{}"
                        try {
                            if (!it.isSuccessful) {
                                cont.resumeWithException(IOException("Anthropic API error ${it.code}: $raw"))
                                return
                            }
                            val json = JSONObject(raw)
                            val content = json.getJSONArray("content")
                            val text = content.getJSONObject(0).getString("text")
                            cont.resume(text)
                        } catch (e: Exception) {
                            cont.resumeWithException(e)
                        }
                    }
                }
            })
        }
    }
}
