package com.abhi.sitewatch.data

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.Query

@Dao
interface StatusEventDao {

    @Insert
    suspend fun insert(event: StatusEventEntity): Long

    @Query("SELECT * FROM status_events WHERE groupName = :groupName ORDER BY timestamp DESC LIMIT 1")
    suspend fun latestForSite(groupName: String): StatusEventEntity?

    @Query(
        "SELECT * FROM status_events WHERE groupName = :groupName " +
        "AND timestamp >= :sinceMs ORDER BY timestamp ASC"
    )
    suspend fun eventsSince(groupName: String, sinceMs: Long): List<StatusEventEntity>

    @Query(
        "SELECT * FROM status_events WHERE groupName = :groupName " +
        "ORDER BY timestamp DESC LIMIT :limit"
    )
    suspend fun recentForSite(groupName: String, limit: Int): List<StatusEventEntity>

    @Query("DELETE FROM status_events WHERE groupName = :groupName")
    suspend fun deleteAllForGroup(groupName: String)
}
