package com.abhi.sitewatch.dashboard

import android.graphics.Color
import android.view.View
import android.view.ViewGroup
import android.widget.LinearLayout
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView

class DashboardAdapter(private val onClick: (SiteSummary) -> Unit) :
    RecyclerView.Adapter<DashboardAdapter.RowViewHolder>() {

    private val items = mutableListOf<SiteSummary>()

    fun submitList(list: List<SiteSummary>) {
        items.clear()
        items.addAll(list)
        notifyDataSetChanged()
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RowViewHolder {
        val context = parent.context
        val density = context.resources.displayMetrics.density
        fun dp(v: Int) = (v * density).toInt()

        val container = LinearLayout(context).apply {
            orientation = LinearLayout.VERTICAL
            layoutParams = RecyclerView.LayoutParams(
                RecyclerView.LayoutParams.MATCH_PARENT,
                RecyclerView.LayoutParams.WRAP_CONTENT
            )
            setPadding(dp(16), dp(12), dp(16), dp(12))
            isClickable = true
            isFocusable = true
        }

        val titleRow = LinearLayout(context).apply {
            orientation = LinearLayout.HORIZONTAL
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT
            )
        }

        val nameView = TextView(context).apply {
            textSize = 16f
            setTextColor(Color.parseColor("#1A1A1A"))
            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
        }
        val tphView = TextView(context).apply {
            textSize = 16f
            setTextColor(Color.parseColor("#2F6FED"))
        }
        titleRow.addView(nameView)
        titleRow.addView(tphView)

        val subtitleView = TextView(context).apply {
            textSize = 13f
            setTextColor(Color.parseColor("#888888"))
            setPadding(0, dp(2), 0, 0)
        }

        container.addView(titleRow)
        container.addView(subtitleView)

        val holder = RowViewHolder(container, nameView, tphView, subtitleView)
        container.setOnClickListener {
            val position = holder.bindingAdapterPosition
            if (position != RecyclerView.NO_POSITION) onClick(items[position])
        }

        return holder
    }

    override fun onBindViewHolder(holder: RowViewHolder, position: Int) {
        val item = items[position]

        holder.name.text = "${statusEmoji(item.currentStatus)} ${item.displayName}"
        holder.tph.text = if (item.lastTphRaw != null) "${item.lastTphRaw} ${item.trendArrow}".trim() else ""

        val subtitleParts = mutableListOf<String>()
        subtitleParts.add("Ran ${"%.1f".format(item.runningHoursToday)}h today")
        subtitleParts.add(item.lastReportAgo?.let { "report $it" } ?: "no reports yet")
        if (item.pendingCount > 0) subtitleParts.add("${item.pendingCount} pending")
        if (item.isQuiet) subtitleParts.add("⚠ quiet")
        holder.subtitle.text = subtitleParts.joinToString(" · ")
        holder.subtitle.setTextColor(
            if (item.isQuiet || item.currentStatus == "BREAKDOWN") Color.parseColor("#C0392B") else Color.parseColor("#888888")
        )
    }

    private fun statusEmoji(status: String?): String = when (status) {
        "RUNNING" -> "🟢"
        "IDLE" -> "🟡"
        "BREAKDOWN" -> "🔴"
        "STOPPED" -> "⚪"
        else -> "❔"
    }

    override fun getItemCount(): Int = items.size

    class RowViewHolder(
        view: View,
        val name: TextView,
        val tph: TextView,
        val subtitle: TextView
    ) : RecyclerView.ViewHolder(view)
}
