package com.abhi.sitewatch.sitemanager

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.EditText
import android.widget.Switch
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.abhi.sitewatch.R
import com.abhi.sitewatch.data.SiteEntity
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * One row per detected WhatsApp group, tracked or not. Display-name edits
 * commit on focus-lost (not per-keystroke); the tracked switch commits
 * immediately. Both call straight through to the DAO via the constructor
 * callbacks — no separate "Save" step to forget.
 */
class SiteManagerAdapter(
    private val onTrackedChanged: (SiteEntity, Boolean) -> Unit,
    private val onDisplayNameChanged: (SiteEntity, String) -> Unit,
    private val onDelete: (SiteEntity) -> Unit
) : RecyclerView.Adapter<SiteManagerAdapter.SiteViewHolder>() {

    private val sites = mutableListOf<SiteEntity>()
    private val dateFormat = SimpleDateFormat("dd MMM, HH:mm", Locale.getDefault())

    fun submitList(list: List<SiteEntity>) {
        sites.clear()
        sites.addAll(list)
        notifyDataSetChanged()
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): SiteViewHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.item_site_manager, parent, false)
        return SiteViewHolder(view)
    }

    override fun onBindViewHolder(holder: SiteViewHolder, position: Int) {
        holder.bind(sites[position])
    }

    override fun getItemCount(): Int = sites.size

    inner class SiteViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        private val groupNameText = itemView.findViewById<TextView>(R.id.groupNameText)
        private val displayNameField = itemView.findViewById<EditText>(R.id.displayNameField)
        private val trackedSwitch = itemView.findViewById<Switch>(R.id.trackedSwitch)
        private val metaText = itemView.findViewById<TextView>(R.id.metaText)
        private val deleteButton = itemView.findViewById<TextView>(R.id.deleteButton)

        private var currentSite: SiteEntity? = null
        // Guards against firing callbacks while bind() is programmatically
        // setting field values (which would otherwise fire the same focus/
        // checked-changed listeners meant only for genuine user edits).
        private var suppressCallbacks = false

        init {
            displayNameField.setOnFocusChangeListener { _, hasFocus ->
                if (!hasFocus && !suppressCallbacks) {
                    val site = currentSite ?: return@setOnFocusChangeListener
                    val newName = displayNameField.text.toString().trim()
                    if (newName.isNotEmpty() && newName != site.displayName) {
                        onDisplayNameChanged(site, newName)
                    }
                }
            }
            trackedSwitch.setOnCheckedChangeListener { _, isChecked ->
                if (!suppressCallbacks) {
                    val site = currentSite ?: return@setOnCheckedChangeListener
                    if (isChecked != site.tracked) {
                        onTrackedChanged(site, isChecked)
                    }
                }
            }
            deleteButton.setOnClickListener {
                currentSite?.let { onDelete(it) }
            }
        }

        fun bind(site: SiteEntity) {
            suppressCallbacks = true
            currentSite = site
            groupNameText.text = site.groupName
            displayNameField.setText(site.displayName)
            trackedSwitch.isChecked = site.tracked
            metaText.text = "${site.messageCount} messages · last seen ${dateFormat.format(Date(site.lastSeen))}"
            suppressCallbacks = false
        }
    }
}
