package com.abhi.sitewatch.network

import okhttp3.Call
import okhttp3.Callback
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import okhttp3.Response
import org.json.JSONArray
import org.json.JSONObject
import java.io.IOException
import kotlin.coroutines.resume
import kotlin.coroutines.resumeWithException
import kotlin.coroutines.suspendCoroutine

/**
 * Setup-screen diagnostics: listing free-tier models and verifying a key
 * actually works, independent of the full tool-calling chat pipeline in
 * OpenRouterChatClient — so problems surface immediately in Setup instead
 * of being discovered deep inside a chat session.
 */
object OpenRouterModels {

    data class ModelInfo(val id: String, val name: String)

    private val client = OkHttpClient()
    private const val MODELS_ENDPOINT = "https://openrouter.ai/api/v1/models"
    private const val CHAT_ENDPOINT = "https://openrouter.ai/api/v1/chat/completions"

    /**
     * Live fetch rather than a hardcoded list on purpose — which models are
     * free on OpenRouter rotates over time, which is exactly what
     * openrouter/free (offered alongside these) is meant to insulate
     * against. This just gives the option of pinning a specific one.
     */
    suspend fun listFreeModels(): List<ModelInfo> {
        val request = Request.Builder().url(MODELS_ENDPOINT).get().build()

        val raw = suspendCoroutine<String> { cont ->
            client.newCall(request).enqueue(object : Callback {
                override fun onFailure(call: Call, e: IOException) {
                    cont.resumeWithException(e)
                }

                override fun onResponse(call: Call, response: Response) {
                    response.use {
                        if (!it.isSuccessful) {
                            cont.resumeWithException(IOException("OpenRouter API error ${it.code}"))
                            return
                        }
                        cont.resume(it.body?.string() ?: "{}")
                    }
                }
            })
        }

        val data = JSONObject(raw).optJSONArray("data") ?: return emptyList()
        val result = mutableListOf<ModelInfo>()
        for (i in 0 until data.length()) {
            val model = data.getJSONObject(i)
            val pricing = model.optJSONObject("pricing") ?: continue
            if (pricing.optString("prompt") == "0" && pricing.optString("completion") == "0") {
                result.add(
                    ModelInfo(
                        id = model.optString("id"),
                        name = model.optString("name", model.optString("id"))
                    )
                )
            }
        }
        return result.sortedBy { it.name }
    }

    /** A minimal, cheap round-trip — not the real chat/extraction path — just enough to confirm the key and model actually work. */
    suspend fun testApiKey(apiKey: String, model: String): Result<String> {
        val payload = JSONObject().apply {
            put("model", model)
            put("max_tokens", 5)
            put(
                "messages",
                JSONArray().put(JSONObject().apply {
                    put("role", "user")
                    put("content", "ping")
                })
            )
        }

        val request = Request.Builder()
            .url(CHAT_ENDPOINT)
            .addHeader("Authorization", "Bearer $apiKey")
            .addHeader("Content-Type", "application/json")
            .post(payload.toString().toRequestBody("application/json".toMediaType()))
            .build()

        return try {
            val raw = suspendCoroutine<String> { cont ->
                client.newCall(request).enqueue(object : Callback {
                    override fun onFailure(call: Call, e: IOException) {
                        cont.resumeWithException(e)
                    }

                    override fun onResponse(call: Call, response: Response) {
                        response.use {
                            val body = it.body?.string() ?: ""
                            if (!it.isSuccessful) {
                                cont.resumeWithException(IOException(extractErrorMessage(body) ?: "HTTP ${it.code}"))
                                return
                            }
                            cont.resume(body)
                        }
                    }
                })
            }
            val json = JSONObject(raw)
            if (json.has("error")) {
                Result.failure(IOException(extractErrorMessage(raw) ?: raw))
            } else {
                val actualModel = json.optString("model", model)
                Result.success("Connected — responded via $actualModel")
            }
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    private fun extractErrorMessage(body: String): String? = try {
        JSONObject(body).optJSONObject("error")?.optString("message")
    } catch (e: Exception) {
        null
    }
}
