package com.abhi.sitewatch.worker

import com.abhi.sitewatch.data.ReportEntity
import org.json.JSONArray

/**
 * Deterministic pattern-mining over a site's own accumulated report
 * history — real computed statistics (TPH range, most frequent recurring
 * issues), not an LLM's impression of "patterns" from skimming raw
 * scrollback. This is what "the assistant learns from your data" means in
 * this app: genuine math over your history, re-derived fresh on every
 * call rather than trained into anything.
 *
 * Issue matching is exact-phrase (after lowercase/trim) — near-duplicate
 * wordings ("belt jam" vs "conveyor belt jammed") won't merge. That's a
 * real limitation of doing this without embeddings/NLP, but recurring
 * issues often do get logged with consistent short phrasing since they
 * come from the same extraction prompt each time.
 */
object SitePatternAnalyzer {

    data class Insights(
        val reportCount: Int,
        val tphMin: Double?,
        val tphMedian: Double?,
        val tphMax: Double?,
        val topIssues: List<Pair<String, Int>>
    )

    fun analyze(reports: List<ReportEntity>): Insights {
        val tphValues = reports.mapNotNull { it.tphNumeric }.sorted()
        val median = if (tphValues.isEmpty()) null else {
            val mid = tphValues.size / 2
            if (tphValues.size % 2 == 0) (tphValues[mid - 1] + tphValues[mid]) / 2.0 else tphValues[mid]
        }

        val issueCounts = mutableMapOf<String, Int>()
        for (report in reports) {
            try {
                val arr = JSONArray(report.issuesJson)
                for (i in 0 until arr.length()) {
                    val issue = arr.getString(i).trim().lowercase()
                    if (issue.isNotEmpty()) issueCounts[issue] = (issueCounts[issue] ?: 0) + 1
                }
            } catch (e: Exception) {
                // Malformed issuesJson on some old/edge-case report — skip it, don't fail the whole analysis.
            }
        }
        val topIssues = issueCounts.entries.sortedByDescending { it.value }.take(5).map { it.key to it.value }

        return Insights(
            reportCount = reports.size,
            tphMin = tphValues.firstOrNull(),
            tphMedian = median,
            tphMax = tphValues.lastOrNull(),
            topIssues = topIssues
        )
    }
}
