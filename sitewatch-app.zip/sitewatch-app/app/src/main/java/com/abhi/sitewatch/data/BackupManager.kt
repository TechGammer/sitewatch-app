package com.abhi.sitewatch.data

import android.content.Context
import android.net.Uri
import java.io.File

/**
 * Manual, deterministic backup/restore of the entire local database (sites,
 * messages, reports, status history, memories, machine profiles, taught
 * status keywords) to a file the user picks via the system file picker.
 *
 * This exists alongside Android's own Auto Backup (enabled in the manifest)
 * rather than instead of it: Auto Backup only runs periodically — it needs
 * the device idle, charging, and on wifi — so a reinstall shortly after a
 * change could miss it. A manual export is an immediate, guaranteed
 * snapshot. Both deliberately exclude the OpenRouter API key and Telegram
 * token (SharedPreferences) — those are re-entered by design, not restored
 * silently.
 */
object BackupManager {

    private const val DB_NAME = "sitewatch.db"

    suspend fun export(context: Context, destUri: Uri): Boolean {
        val db = AppDatabase.getInstance(context)
        try {
            // Merges the write-ahead log into the main file so a plain
            // single-file copy is a complete, consistent snapshot rather than
            // missing whatever's still sitting in the -wal file.
            db.openHelper.writableDatabase.execSQL("PRAGMA wal_checkpoint(FULL)")
        } catch (e: Exception) {
            // Best-effort — proceed with the copy even if the checkpoint step
            // itself failed for some platform-specific reason.
        }

        val dbFile = context.getDatabasePath(DB_NAME)
        if (!dbFile.exists()) return false

        val out = context.contentResolver.openOutputStream(destUri) ?: return false
        out.use { stream -> dbFile.inputStream().use { it.copyTo(stream) } }
        return true
    }

    suspend fun restore(context: Context, srcUri: Uri): Boolean {
        val input = context.contentResolver.openInputStream(srcUri) ?: return false
        val tempFile = File(context.cacheDir, "restore_incoming.db")
        input.use { stream -> tempFile.outputStream().use { stream.copyTo(it) } }

        // Close the live connection before overwriting the file underneath it
        // — otherwise the running connection and the new file on disk
        // disagree, and the next read can corrupt or crash.
        AppDatabase.closeAndReset()

        val dbFile = context.getDatabasePath(DB_NAME)
        // Drop any leftover WAL/SHM journal files from the previous database
        // so the restored file isn't merged with stale journal data.
        File(dbFile.path + "-wal").delete()
        File(dbFile.path + "-shm").delete()

        tempFile.copyTo(dbFile, overwrite = true)
        tempFile.delete()
        return true
    }
}
