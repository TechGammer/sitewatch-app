package com.abhi.sitewatch.worker

/**
 * Reliability/performance metrics computed directly from status history and
 * (if set) a machine's rated capacity — deliberately NOT left to the chat
 * model to estimate, since free-tier LLMs are unreliable at precise
 * arithmetic. Every field is null when there isn't enough data to compute
 * it honestly (e.g. no breakdown events yet, or no rated capacity set),
 * rather than guessing.
 *
 * `oeeLitePercent` is Availability × Performance only — real OEE also
 * factors in a Quality component (good units vs total), which this app has
 * no way to measure (no defect/reject tracking from chat text), so this is
 * explicitly labeled "lite" rather than overclaiming a full OEE figure.
 */
data class MachineMetrics(
    val availabilityPercent: Double?,
    val mtbfHours: Double?,
    val mttrHours: Double?,
    val breakdownCount: Int,
    val performancePercent: Double?,
    val oeeLitePercent: Double?
)

object MachineMetrics {
    fun compute(
        hoursByStatus: Map<String, Double>,
        periodHours: Double,
        breakdownEventCount: Int,
        avgTph: Double?,
        ratedCapacityTph: Double?
    ): MachineMetrics {
        val breakdownHours = hoursByStatus["BREAKDOWN"] ?: 0.0

        val availability = if (periodHours > 0) {
            ((periodHours - breakdownHours) / periodHours * 100).coerceIn(0.0, 100.0)
        } else null

        val mttr = if (breakdownEventCount > 0) breakdownHours / breakdownEventCount else null
        val mtbf = if (breakdownEventCount > 0) (periodHours - breakdownHours) / breakdownEventCount else null

        val performance = if (avgTph != null && ratedCapacityTph != null && ratedCapacityTph > 0) {
            (avgTph / ratedCapacityTph * 100).coerceIn(0.0, 200.0)
        } else null

        val oeeLite = if (availability != null && performance != null) {
            availability * performance / 100.0
        } else null

        return MachineMetrics(availability, mtbf, mttr, breakdownEventCount, performance, oeeLite)
    }
}
