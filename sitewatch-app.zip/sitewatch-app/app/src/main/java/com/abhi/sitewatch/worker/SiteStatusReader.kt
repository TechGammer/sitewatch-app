package com.abhi.sitewatch.worker

import android.content.Context
import com.abhi.sitewatch.data.AppDatabase
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * One site's live status, computed fresh from its own recent messages
 * (PlantStatusDetector) — shared by chat's get_all_sites_status tool and
 * the native Live Status screen, so both read the exact same logic and
 * can never drift apart from each other.
 */
data class SiteStatusSummary(
    val displayName: String,
    val groupName: String,
    val status: String?,
    val statusAtMs: Long?,
    val remark: String?,
    val lastMessageAtMs: Long?,
    val lastMessage: String?
)

object SiteStatusReader {

    suspend fun getAll(context: Context): List<SiteStatusSummary> {
        val db = AppDatabase.getInstance(context)
        val tracked = db.siteDao().getTracked()
        val customKeywords = db.statusKeywordDao().getAll()

        return tracked.map { site ->
            val recent = db.messageDao().recentForGroup(site.groupName, 40)
            val hit = PlantStatusDetector.detectLatest(recent, site.groupName, customKeywords)
            val lastMsg = recent.firstOrNull()
            SiteStatusSummary(
                displayName = site.displayName,
                groupName = site.groupName,
                status = hit?.status,
                statusAtMs = hit?.timestamp,
                remark = hit?.let { "${it.sender}: ${it.text}" },
                lastMessageAtMs = lastMsg?.timestamp,
                lastMessage = lastMsg?.let { "${it.sender}: ${it.text}" }
            )
        }
    }

    /**
     * Numbered, emoji-labelled plain text for sharing — uses WhatsApp's own
     * single *bold* syntax so site names render bold once sent there,
     * rather than showing literal asterisks.
     */
    fun toShareText(summaries: List<SiteStatusSummary>): String {
        val headerFmt = SimpleDateFormat("dd MMM, HH:mm", Locale.getDefault())
        val timeFmt = SimpleDateFormat("HH:mm", Locale.getDefault())
        val sb = StringBuilder("📡 Live Plant Status — ${headerFmt.format(Date())}\n\n")

        summaries.forEachIndexed { index, s ->
            val emoji = when (s.status) {
                "RUNNING" -> "🟢"
                "IDLE" -> "🟡"
                "BREAKDOWN" -> "🔴"
                "STOPPED" -> "⚪"
                else -> "❔"
            }
            sb.append("${index + 1}. $emoji *${s.displayName}*")
            if (s.status != null && s.statusAtMs != null) {
                sb.append(" — ${s.status} as per last update ${timeFmt.format(Date(s.statusAtMs))}")
            } else {
                sb.append(" — no status stated in recent messages")
            }
            sb.append("\n")

            val remark = (s.remark ?: s.lastMessage)?.take(150)
            if (!remark.isNullOrBlank()) sb.append("   $remark\n")
            sb.append("\n")
        }
        return sb.toString()
    }
}
