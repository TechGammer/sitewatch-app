package com.abhi.sitewatch.data

import android.content.Context
import androidx.room.withTransaction
import com.abhi.sitewatch.SiteNameExtractor

/**
 * One-time (and on-demand) cleanup for sites that got split into duplicates
 * by WhatsApp's "(N messages)" unread-count suffix leaking into the group
 * key. Groups all sites by their count-suffix-stripped name, and for any
 * name that has more than one row (or a row still carrying the suffix),
 * merges them into a single canonical row and repoints all child data
 * (messages, reports, status events, machine profile) onto it.
 *
 * Deliberately conservative: it only collapses rows that differ purely by
 * the unread-count suffix. Rows whose raw titles differ in any other way
 * (spacing, punctuation, actual renames) are left distinct, because merging
 * genuinely-different groups would corrupt data worse than a leftover
 * duplicate the user can remove by hand in Manage Sites.
 *
 * Runs inside a single transaction so a failure rolls back cleanly rather
 * than leaving half-merged data.
 */
object SiteMaintenance {

    /** @return how many duplicate rows were merged away (0 if nothing to do). */
    suspend fun dedupeAndNormalize(context: Context): Int {
        val db = AppDatabase.getInstance(context)
        val siteDao = db.siteDao()
        val sites = siteDao.getAll()
        if (sites.isEmpty()) return 0

        val groups = sites.groupBy { SiteNameExtractor.normalizeGroupName(it.groupName) }
        var mergedCount = 0

        db.withTransaction {
            for ((canonicalName, dupSites) in groups) {
                if (canonicalName.isBlank()) continue
                val alreadyClean = dupSites.size == 1 && dupSites[0].groupName == canonicalName
                if (alreadyClean) continue

                for (s in dupSites) {
                    if (s.groupName != canonicalName) {
                        db.messageDao().reassignGroup(s.groupName, canonicalName)
                        db.reportDao().reassignGroup(s.groupName, canonicalName)
                        db.statusEventDao().reassignGroup(s.groupName, canonicalName)
                        db.machineProfileDao().reassignGroup(s.groupName, canonicalName)
                        db.machineProfileDao().deleteForSite(s.groupName)
                    }
                }

                val tracked = dupSites.any { it.tracked }
                val totalMessages = dupSites.sumOf { it.messageCount }
                val firstSeen = dupSites.minOf { it.firstSeen }
                val lastSeen = dupSites.maxOf { it.lastSeen }
                val lastFastAlert = dupSites.maxOf { it.lastFastAlertAt }
                val bestRaw = dupSites.maxByOrNull { it.messageCount }?.displayName ?: canonicalName
                val displayName = SiteNameExtractor.stripCountSuffix(bestRaw)
                    .ifBlank { SiteNameExtractor.extractDisplayName(canonicalName) }

                for (s in dupSites) siteDao.delete(s.groupName)
                siteDao.upsert(
                    SiteEntity(
                        groupName = canonicalName,
                        displayName = displayName,
                        tracked = tracked,
                        firstSeen = firstSeen,
                        lastSeen = lastSeen,
                        messageCount = totalMessages,
                        lastFastAlertAt = lastFastAlert
                    )
                )
                mergedCount += dupSites.size - 1
            }
        }
        return mergedCount
    }
}
