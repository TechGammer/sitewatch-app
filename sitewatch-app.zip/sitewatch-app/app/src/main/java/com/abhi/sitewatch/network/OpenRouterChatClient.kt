package com.abhi.sitewatch.network

import okhttp3.Call
import okhttp3.Callback
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import okhttp3.Response
import org.json.JSONArray
import org.json.JSONObject
import java.io.IOException
import java.util.concurrent.TimeUnit
import kotlin.coroutines.resume
import kotlin.coroutines.resumeWithException
import kotlin.coroutines.suspendCoroutine

/**
 * Drives the OpenRouter chat-completions tool-calling loop: send the
 * conversation, and if the model responds with tool_calls, execute them via
 * the supplied [ToolExecutor] and feed the results back as role:"tool"
 * messages — repeating until the model produces a final text answer (no
 * tool_calls) or the round-trip cap is hit.
 *
 * Uses OpenRouter's OpenAI-compatible endpoint, so history entries are
 * complete chat-completions message objects: {role:"user", content:"..."},
 * {role:"assistant", content, tool_calls?}, {role:"tool", tool_call_id,
 * content}. The full history is passed in and mutated in place via
 * [onTurnAppended], so the caller can persist every message as it happens
 * rather than only at the end.
 */
object OpenRouterChatClient {

    private val client = OkHttpClient.Builder()
        .connectTimeout(30, TimeUnit.SECONDS)
        .readTimeout(60, TimeUnit.SECONDS)
        .build()
    private const val ENDPOINT = "https://openrouter.ai/api/v1/chat/completions"
    private const val MAX_TOOL_ROUNDTRIPS = 6

    fun interface ToolExecutor {
        suspend fun execute(name: String, input: JSONObject): String
    }

    fun interface TurnListener {
        /** Called each time a message (user, assistant, or tool result) is appended to history. */
        suspend fun onTurnAppended(message: JSONObject)
    }

    /**
     * @param history mutable, ordered list of chat-completions message objects already in the conversation
     * @param userText the new user message to send
     * @param tools tool schemas in the OpenAI `tools` parameter format ({"type":"function","function":{...}})
     * @param systemPrompt the system prompt, sent as a leading role:"system" message
     * @param toolExecutor runs a named tool call and returns its result as a string
     * @param onAssistantText called with each piece of assistant-visible text as it's produced,
     *        including "thinking out loud" text that precedes a tool call — lets the UI show
     *        progress rather than waiting silently through the whole tool loop
     */
    suspend fun sendMessage(
        apiKey: String,
        model: String,
        history: MutableList<JSONObject>,
        userText: String,
        tools: JSONArray,
        systemPrompt: String,
        toolExecutor: ToolExecutor,
        turnListener: TurnListener,
        onAssistantText: suspend (String) -> Unit
    ) {
        val userMessage = JSONObject().apply {
            put("role", "user")
            put("content", userText)
        }
        history.add(userMessage)
        turnListener.onTurnAppended(userMessage)

        var roundTrips = 0
        while (true) {
            val response = callApi(apiKey, model, history, tools, systemPrompt)
            val choice = response.getJSONArray("choices").getJSONObject(0)
            val rawMessage = choice.getJSONObject("message")

            // Rebuild the assistant message from scratch rather than echoing
            // the response object back: openrouter/free routes to different
            // providers, some of which attach extra fields (reasoning, etc.)
            // that other providers reject when replayed as history.
            val text = if (rawMessage.isNull("content")) "" else rawMessage.optString("content", "")
            val toolCalls = rawMessage.optJSONArray("tool_calls")
            val assistantMessage = JSONObject().apply {
                put("role", "assistant")
                put("content", if (text.isEmpty() && toolCalls != null) JSONObject.NULL else text)
                if (toolCalls != null && toolCalls.length() > 0) put("tool_calls", toolCalls)
            }
            history.add(assistantMessage)
            turnListener.onTurnAppended(assistantMessage)

            // Surface any text the model produced this turn immediately, even
            // if it also called a tool in the same turn.
            if (text.isNotBlank()) onAssistantText(text)

            if (toolCalls == null || toolCalls.length() == 0) {
                return
            }
            roundTrips++
            if (roundTrips > MAX_TOOL_ROUNDTRIPS) {
                onAssistantText("(Stopped after too many tool calls in a row — try rephrasing or breaking that into a smaller request.)")
                return
            }

            for (i in 0 until toolCalls.length()) {
                val call = toolCalls.getJSONObject(i)
                val callId = call.getString("id")
                val function = call.getJSONObject("function")
                val name = function.getString("name")
                // Arguments arrive as a JSON *string*; a model occasionally
                // emits malformed JSON here, which we treat as empty input
                // rather than crashing the whole exchange.
                val input = try {
                    val args = function.optString("arguments", "")
                    if (args.isBlank()) JSONObject() else JSONObject(args)
                } catch (e: Exception) {
                    JSONObject()
                }
                val resultText = try {
                    toolExecutor.execute(name, input)
                } catch (e: Exception) {
                    "Error running tool: ${e.message}"
                }
                val toolMessage = JSONObject().apply {
                    put("role", "tool")
                    put("tool_call_id", callId)
                    put("content", resultText)
                }
                history.add(toolMessage)
                turnListener.onTurnAppended(toolMessage)
            }
        }
    }

    private suspend fun callApi(
        apiKey: String,
        model: String,
        history: List<JSONObject>,
        tools: JSONArray,
        systemPrompt: String
    ): JSONObject {
        val messages = JSONArray().put(JSONObject().apply {
            put("role", "system")
            put("content", systemPrompt)
        })
        history.forEach { messages.put(it) }

        val payload = JSONObject().apply {
            put("model", model)
            put("max_tokens", 2000)
            put("messages", messages)
            put("tools", tools)
        }

        val request = Request.Builder()
            .url(ENDPOINT)
            .addHeader("Authorization", "Bearer $apiKey")
            .addHeader("Content-Type", "application/json")
            .addHeader("X-Title", "Site Watch")
            .post(payload.toString().toRequestBody("application/json".toMediaType()))
            .build()

        return suspendCoroutine { cont ->
            client.newCall(request).enqueue(object : Callback {
                override fun onFailure(call: Call, e: IOException) {
                    cont.resumeWithException(e)
                }

                override fun onResponse(call: Call, response: Response) {
                    response.use {
                        val raw = it.body?.string() ?: "{}"
                        try {
                            if (!it.isSuccessful) {
                                cont.resumeWithException(IOException("OpenRouter API error ${it.code}: $raw"))
                                return
                            }
                            val json = JSONObject(raw)
                            // OpenRouter can return 200 with an error object
                            // (e.g. a provider failure mid-route).
                            if (json.has("error")) {
                                cont.resumeWithException(IOException("OpenRouter error: ${json.getJSONObject("error").optString("message", raw)}"))
                                return
                            }
                            cont.resume(json)
                        } catch (e: Exception) {
                            cont.resumeWithException(e)
                        }
                    }
                }
            })
        }
    }
}
