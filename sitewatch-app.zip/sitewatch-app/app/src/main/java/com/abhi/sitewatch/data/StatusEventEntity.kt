package com.abhi.sitewatch.data

import androidx.room.Entity
import androidx.room.Index
import androidx.room.PrimaryKey

/**
 * A single status change extracted from WhatsApp messages: the plant went
 * RUNNING, IDLE, BREAKDOWN, or STOPPED, optionally with a reason ("no
 * diesel", "conveyor belt jam"). `timestamp` is the message time it was
 * reported at — not necessarily the exact moment the change happened,
 * since that's the best we can infer from chat text rather than telemetry.
 *
 * Running-hours math (RunningHoursCalculator) works by treating each
 * event as "status held from this event until the next one" — so this is
 * only as accurate and complete as what people actually post in the group.
 */
@Entity(
    tableName = "status_events",
    indices = [Index(value = ["groupName", "timestamp"])]
)
data class StatusEventEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val groupName: String,
    val timestamp: Long,
    val status: String,      // "RUNNING" | "IDLE" | "BREAKDOWN" | "STOPPED"
    val reason: String?,     // null if not mentioned
    val rawText: String      // the model's time_hint text, e.g. "10:30am" or "after lunch" — for context, not exact
)
