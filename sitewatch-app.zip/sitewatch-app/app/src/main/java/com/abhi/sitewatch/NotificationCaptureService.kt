package com.abhi.sitewatch

import android.app.Notification
import android.app.Person
import android.content.Context
import android.os.Bundle
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification
import com.abhi.sitewatch.data.AppDatabase
import com.abhi.sitewatch.data.SiteEntity
import com.abhi.sitewatch.data.SiteMessage
import com.abhi.sitewatch.network.TelegramSender
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch
import java.util.Locale

/**
 * Passively listens for WhatsApp notifications and pulls out individual
 * messages using Android's MessagingStyle notification extras (the same
 * mechanism WhatsApp uses to show "sender: message" lines in a group
 * notification). This does NOT open WhatsApp or read the chat screen.
 *
 * Every distinct WhatsApp group/conversation title is auto-registered in
 * the `sites` table (via SiteDao) the first time it's seen, with a cleaned
 * display name from SiteNameExtractor — but new sites default to
 * untracked. Only tracked sites get their message text persisted; the
 * rest just update lastSeen/messageCount so they show up for the user (or
 * the assistant, via chat) to opt in later.
 *
 * Tracked sites also get a cheap keyword-based scan for possible
 * breakdown/stoppage language (English + a few common Hindi/Marathi
 * terms) — if matched, an immediate "unverified" Telegram alert fires
 * without waiting for an LLM call or the next scheduled report. This is
 * deliberately crude (simple substring matching, debounced per site) and
 * is meant as a fast heads-up, not a replacement for the accurate
 * LLM-extracted status_events that land in the next report. The keyword
 * list is short and will miss phrasing it doesn't recognize — worth
 * tuning for how your specific groups actually talk.
 *
 * Known limitations (be aware of these, don't expect 100% capture):
 *  - If a chat is open on screen, some OEMs suppress its notification.
 *  - Very old / heavily-customized ROMs may not populate EXTRA_MESSAGES.
 *  - If the user clears notifications before this fires, that's fine —
 *    onNotificationPosted already ran and the DB copy is independent —
 *    but if the service was disabled/killed during that window, it's lost.
 *  - This must be re-enabled manually after "Notification access" is
 *    revoked by battery optimizers on some Chinese OEMs (Xiaomi/Oppo/Vivo).
 */
class NotificationCaptureService : NotificationListenerService() {

    private val scope = CoroutineScope(Dispatchers.IO)

    companion object {
        private const val WHATSAPP_PACKAGE = "com.whatsapp"
        private const val WHATSAPP_BUSINESS_PACKAGE = "com.whatsapp.w4b"
    }

    override fun onDestroy() {
        super.onDestroy()
        scope.cancel()
    }

    override fun onNotificationPosted(sbn: StatusBarNotification) {
        if (sbn.packageName != WHATSAPP_PACKAGE && sbn.packageName != WHATSAPP_BUSINESS_PACKAGE) {
            return
        }

        val extras = sbn.notification.extras
        val rawTitle = extras.getCharSequence(Notification.EXTRA_CONVERSATION_TITLE)?.toString()
            ?: extras.getCharSequence(Notification.EXTRA_TITLE)?.toString()
            ?: return
        // Strip WhatsApp's "(N messages)" unread-count suffix so the same
        // group keeps one stable identity instead of spawning a new row
        // every time its unread count changes — see SiteNameExtractor.
        val conversationTitle = SiteNameExtractor.normalizeGroupName(rawTitle)
        if (conversationTitle.isBlank()) return

        val messages = extractMessagingStyleMessages(extras, sbn.postTime)
        if (messages.isEmpty()) return

        val appContext = applicationContext
        val db = AppDatabase.getInstance(appContext)
        val siteDao = db.siteDao()
        val messageDao = db.messageDao()

        scope.launch {
            val now = System.currentTimeMillis()
            var site = siteDao.getByGroupName(conversationTitle)
            if (site == null) {
                siteDao.insertIfNew(
                    SiteEntity(
                        groupName = conversationTitle,
                        displayName = SiteNameExtractor.extractDisplayName(conversationTitle),
                        tracked = false,
                        firstSeen = now,
                        lastSeen = now,
                        messageCount = 0
                    )
                )
                site = siteDao.getByGroupName(conversationTitle)
            }
            siteDao.recordMessageSeen(conversationTitle, now)

            // Copy to a val so the non-null check below reliably smart-casts
            // (a mutable var reassigned above isn't guaranteed to smart-cast
            // the same way across the rest of this coroutine body).
            val trackedSite = site
            if (trackedSite == null || !trackedSite.tracked) return@launch

            for (msg in messages) {
                val dup = messageDao.countDuplicate(conversationTitle, msg.text, msg.timestamp)
                if (dup == 0) {
                    messageDao.insert(
                        SiteMessage(
                            groupName = conversationTitle,
                            sender = msg.sender,
                            text = msg.text,
                            timestamp = msg.timestamp
                        )
                    )
                    maybeSendFastAlert(appContext, trackedSite, msg.text)
                }
            }
        }
    }

    private suspend fun maybeSendFastAlert(context: Context, site: SiteEntity, messageText: String) {
        val settings = SettingsStore(context)
        if (!settings.isTelegramConfigured()) return

        val textLower = messageText.lowercase(Locale.ROOT)
        val matched = settings.fastAlertKeywordList().any { textLower.contains(it) }
        if (!matched) return

        val now = System.currentTimeMillis()
        val debounceMs = settings.fastAlertDebounceMinutes * 60_000L
        if (now - site.lastFastAlertAt < debounceMs) return

        AppDatabase.getInstance(context).siteDao().updateLastFastAlertAt(site.groupName, now)

        val alertText = "⚡ *Quick alert (unverified)* — ${site.displayName}\n" +
            "Possible breakdown/stoppage mentioned:\n\"$messageText\"\n\n" +
            "Fast keyword match, not AI-confirmed — will be verified in the next report."

        try {
            TelegramSender.send(settings.telegramBotToken, settings.telegramChatId, alertText)
        } catch (e: Exception) {
            // Best-effort — don't let a network hiccup affect message capture.
        }
    }

    private data class ExtractedMsg(val sender: String, val text: String, val timestamp: Long)

    /**
     * WhatsApp posts group messages using NotificationCompat.MessagingStyle,
     * which Android flattens into a Bundle array under EXTRA_MESSAGES with
     * keys "text", "time", and "sender_person" (or "sender" on older
     * versions). Reading it this way avoids needing an AndroidX dependency
     * just to parse extras.
     *
     * [fallbackTime] is the notification's own post time, used when a ROM
     * doesn't populate the per-message "time" key — without it those rows
     * would land at epoch 0 (1970) and wreck every recency calculation and
     * running-hours total downstream.
     */
    private fun extractMessagingStyleMessages(extras: Bundle, fallbackTime: Long): List<ExtractedMsg> {
        val result = mutableListOf<ExtractedMsg>()
        val messagesArray = extras.getParcelableArray(Notification.EXTRA_MESSAGES) ?: return result

        for (item in messagesArray) {
            val bundle = item as? Bundle ?: continue
            val text = bundle.getCharSequence("text")?.toString() ?: continue
            val rawTime = bundle.getLong("time")
            val timestamp = if (rawTime > 0) rawTime else fallbackTime
            val senderPerson = bundle.getParcelable<Person>("sender_person")
            val sender = senderPerson?.name?.toString()
                ?: bundle.getCharSequence("sender")?.toString()
                ?: "Unknown"
            result.add(ExtractedMsg(sender, text, timestamp))
        }
        return result
    }
}
