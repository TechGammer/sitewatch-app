package com.abhi.sitewatch

/**
 * Turns a raw WhatsApp group title into a reasonable default display name.
 * This is just a seed — the user (or the assistant, via chat) can rename it
 * anytime through the `upsert_site` tool or the Manage Sites screen.
 * Heuristics only, deliberately simple: strip WhatsApp's unread-count
 * suffix, strip emoji/symbols, collapse whitespace, title-case.
 */
object SiteNameExtractor {

    // Covers common emoji blocks plus misc symbols/dingbats often used to
    // decorate WhatsApp group names (🚛, 🏗️, ⚙️, ✅, etc.).
    private val EMOJI_AND_SYMBOLS = Regex(
        "[\\u2190-\\u21FF\\u2300-\\u27BF\\u2B00-\\u2BFF\\uD83C-\\uDBFF\\uDC00-\\uDFFF\\uFE0F]"
    )
    private val NON_WORD_EDGES = Regex("^[\\s\\-_.,:;|/\\\\*]+|[\\s\\-_.,:;|/\\\\*]+$")
    private val MULTI_SPACE = Regex("\\s{2,}")

    // WhatsApp bundles multiple unread messages into a single notification
    // whose TITLE becomes "GroupName (4 messages)" — that "(N messages)" is
    // an unread COUNT, not part of the group name. Left in, it (a) makes the
    // same group create a brand-new row every time the count changes
    // (duplicate sites), and (b) leaves junk in display names. Stripped here
    // so the group's identity is stable and clean.
    private val COUNT_SUFFIX = Regex("\\s*\\(\\d+\\s+(?:new\\s+)?messages?\\)\\s*$", RegexOption.IGNORE_CASE)

    /** Removes a trailing WhatsApp "(N messages)" unread-count suffix, if present. */
    fun stripCountSuffix(name: String): String = COUNT_SUFFIX.replace(name, "").trim()

    /**
     * The stable identity to key a site on: the raw title with the volatile
     * unread-count suffix removed. Everything else about the raw title is
     * preserved so genuinely-different groups stay distinct.
     */
    fun normalizeGroupName(rawGroupName: String): String = stripCountSuffix(rawGroupName)

    fun extractDisplayName(rawGroupName: String): String {
        val base = stripCountSuffix(rawGroupName)
        var cleaned = EMOJI_AND_SYMBOLS.replace(base, " ")
        cleaned = NON_WORD_EDGES.replace(cleaned, "")
        cleaned = MULTI_SPACE.replace(cleaned, " ").trim()

        if (cleaned.isEmpty()) return base.trim().ifEmpty { rawGroupName.trim() }

        return cleaned.split(" ").joinToString(" ") { word ->
            if (word.isEmpty()) word
            else if (word.any { it.isDigit() } || word.all { it.isUpperCase() }) word
            else word.replaceFirstChar { it.uppercase() }
        }
    }
}
