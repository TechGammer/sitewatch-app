package com.abhi.sitewatch

/**
 * Turns a raw WhatsApp group title into a reasonable default display name.
 * This is just a seed — the user (or the assistant, via chat) can rename it
 * anytime through the `upsert_site` tool. Heuristics only, deliberately
 * simple: strip emoji/symbols, collapse whitespace, title-case.
 */
object SiteNameExtractor {

    // Covers common emoji blocks plus misc symbols/dingbats often used to
    // decorate WhatsApp group names (🚛, 🏗️, ⚙️, ✅, etc.).
    private val EMOJI_AND_SYMBOLS = Regex(
        "[\\u2190-\\u21FF\\u2300-\\u27BF\\u2B00-\\u2BFF\\uD83C-\\uDBFF\\uDC00-\\uDFFF\\uFE0F]"
    )
    private val NON_WORD_EDGES = Regex("^[\\s\\-_.,:;|/\\\\*]+|[\\s\\-_.,:;|/\\\\*]+$")
    private val MULTI_SPACE = Regex("\\s{2,}")

    fun extractDisplayName(rawGroupName: String): String {
        var cleaned = EMOJI_AND_SYMBOLS.replace(rawGroupName, " ")
        cleaned = NON_WORD_EDGES.replace(cleaned, "")
        cleaned = MULTI_SPACE.replace(cleaned, " ").trim()

        if (cleaned.isEmpty()) return rawGroupName.trim()

        return cleaned.split(" ").joinToString(" ") { word ->
            if (word.isEmpty()) word
            else if (word.any { it.isDigit() } || word.all { it.isUpperCase() }) word
            else word.replaceFirstChar { it.uppercase() }
        }
    }
}
