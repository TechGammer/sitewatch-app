package com.abhi.sitewatch.worker

import android.content.Context
import androidx.work.CoroutineWorker
import androidx.work.WorkerParameters
import com.abhi.sitewatch.SettingsStore
import java.util.Calendar

class ReportWorker(context: Context, params: WorkerParameters) : CoroutineWorker(context, params) {

    override suspend fun doWork(): Result {
        val settings = SettingsStore(applicationContext)

        if (!settings.isConfigured() || !settings.isTelegramConfigured()) {
            // Not configured yet — don't burn retries on a config problem.
            return Result.success()
        }

        if (settings.quietHoursEnabled && isWithinQuietHours(settings)) {
            // Skip this cycle silently; unreported messages just roll into
            // the next run once quiet hours end. No need to reschedule
            // anything special since the next periodic tick will re-check.
            return Result.success()
        }

        return try {
            ReportGenerator.generate(
                context = applicationContext,
                groupNames = null,
                sendToTelegram = true,
                markReported = true
            )
            Result.success()
        } catch (e: Exception) {
            Result.retry()
        }
    }

    private fun isWithinQuietHours(settings: SettingsStore): Boolean {
        val hour = Calendar.getInstance().get(Calendar.HOUR_OF_DAY)
        val start = settings.quietHoursStart
        val end = settings.quietHoursEnd
        return if (start < end) {
            hour in start until end
        } else {
            // Wraps past midnight, e.g. 22 -> 7
            hour >= start || hour < end
        }
    }
}
