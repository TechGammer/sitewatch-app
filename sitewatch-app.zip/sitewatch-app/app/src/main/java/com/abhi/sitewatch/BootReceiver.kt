package com.abhi.sitewatch

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import com.abhi.sitewatch.worker.ScheduleManager

/**
 * WorkManager persists periodic jobs across reboots on its own in the
 * common case, but that persistence isn't guaranteed forever — OEM
 * battery-management sweeps, cleared app-adjacent storage, or a WorkManager
 * DB hiccup can drop it silently, and there was previously no path back to
 * a healthy schedule short of the user reopening Setup and hitting Save.
 * Re-applying the schedule on every boot is a cheap, idempotent safety net:
 * enqueueUniquePeriodicWork with UPDATE policy is a no-op if the job is
 * already scheduled correctly.
 */
class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action != Intent.ACTION_BOOT_COMPLETED) return
        val settings = SettingsStore(context)
        if (settings.isConfigured()) {
            ScheduleManager.applyCurrentSchedule(context)
        }
    }
}
