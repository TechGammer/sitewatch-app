package com.abhi.sitewatch.livestatus

import android.content.ActivityNotFoundException
import android.content.Intent
import android.os.Bundle
import android.view.Menu
import android.view.MenuItem
import android.view.View
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.Toolbar
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.abhi.sitewatch.R
import com.abhi.sitewatch.worker.SiteStatusReader
import com.abhi.sitewatch.worker.SiteStatusSummary
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * Numbered, live-refreshing view of every site enabled in Manage Sites:
 * status (RUNNING/IDLE/BREAKDOWN/STOPPED), the message that determined it,
 * and when. Reads the exact same SiteStatusReader chat's get_all_sites_status
 * tool uses, so this screen and a chat answer can never disagree. Refreshes
 * on a timer while visible — cheap since it's all local DB reads, no network
 * call — so it behaves like a genuine live dashboard rather than a static
 * snapshot you have to manually reload.
 */
class LiveStatusActivity : AppCompatActivity() {

    private lateinit var adapter: LiveStatusAdapter
    private var refreshJob: Job? = null
    private var latestSummaries: List<SiteStatusSummary> = emptyList()

    companion object {
        private const val REFRESH_INTERVAL_MS = 20_000L
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_live_status)
        setSupportActionBar(findViewById<Toolbar>(R.id.toolbar))

        adapter = LiveStatusAdapter()
        findViewById<RecyclerView>(R.id.statusRecyclerView).apply {
            layoutManager = LinearLayoutManager(this@LiveStatusActivity)
            adapter = this@LiveStatusActivity.adapter
        }
    }

    override fun onCreateOptionsMenu(menu: Menu): Boolean {
        menuInflater.inflate(R.menu.menu_live_status, menu)
        return true
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        return when (item.itemId) {
            R.id.action_share -> {
                shareStatus()
                true
            }
            else -> super.onOptionsItemSelected(item)
        }
    }

    private fun shareStatus() {
        if (latestSummaries.isEmpty()) {
            Toast.makeText(this, "No sites to share yet", Toast.LENGTH_SHORT).show()
            return
        }
        val text = SiteStatusReader.toShareText(latestSummaries)
        val sendIntent = Intent(Intent.ACTION_SEND).apply {
            type = "text/plain"
            putExtra(Intent.EXTRA_TEXT, text)
        }
        // Try WhatsApp directly first — one tap instead of picking it from a
        // chooser every time, since that's what this button is for.
        try {
            startActivity(Intent(sendIntent).setPackage("com.whatsapp"))
        } catch (e: ActivityNotFoundException) {
            try {
                startActivity(Intent(sendIntent).setPackage("com.whatsapp.w4b"))
            } catch (e2: ActivityNotFoundException) {
                startActivity(Intent.createChooser(sendIntent, "Share plant status"))
            }
        }
    }

    override fun onResume() {
        super.onResume()
        refreshJob = lifecycleScope.launch {
            while (isActive) {
                refresh()
                delay(REFRESH_INTERVAL_MS)
            }
        }
    }

    override fun onPause() {
        super.onPause()
        refreshJob?.cancel()
    }

    private suspend fun refresh() {
        val summaries = SiteStatusReader.getAll(applicationContext)
        latestSummaries = summaries
        adapter.submitList(summaries)
        findViewById<TextView>(R.id.emptyText).visibility = if (summaries.isEmpty()) View.VISIBLE else View.GONE
        findViewById<TextView>(R.id.lastRefreshText).text =
            "Updated ${SimpleDateFormat("HH:mm:ss", Locale.getDefault()).format(Date())} — refreshes automatically"
    }
}
