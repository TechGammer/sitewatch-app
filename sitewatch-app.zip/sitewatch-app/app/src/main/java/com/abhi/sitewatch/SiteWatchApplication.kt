package com.abhi.sitewatch

import android.app.Application
import java.io.File

/**
 * Persists any uncaught crash to a local file before the process dies, then
 * hands off to the platform's default handler so normal system crash
 * behavior still happens. MainActivity checks for this file on its next
 * launch and surfaces it directly on-screen (and via Telegram if
 * configured) — there's no attached debugger or device log access in most
 * support scenarios for this app, so this is the only reliable way to see
 * what actually went wrong after a crash.
 */
class SiteWatchApplication : Application() {
    companion object {
        const val CRASH_LOG_FILENAME = "last_crash.txt"
    }

    override fun onCreate() {
        super.onCreate()
        val defaultHandler = Thread.getDefaultUncaughtExceptionHandler()
        Thread.setDefaultUncaughtExceptionHandler { thread, throwable ->
            try {
                File(filesDir, CRASH_LOG_FILENAME).writeText(
                    "Crashed at ${System.currentTimeMillis()}\n${throwable.stackTraceToString()}"
                )
            } catch (e: Exception) {
                // Best-effort — logging must never be what causes the crash handler itself to fail.
            }
            defaultHandler?.uncaughtException(thread, throwable)
        }
    }
}
