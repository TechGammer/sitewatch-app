package com.abhi.sitewatch.data

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.Query

@Dao
interface StatusKeywordDao {

    @Insert
    suspend fun insert(keyword: StatusKeywordEntity): Long

    @Query("SELECT * FROM status_keywords ORDER BY id ASC")
    suspend fun getAll(): List<StatusKeywordEntity>

    @Query("DELETE FROM status_keywords WHERE phrase = :phrase")
    suspend fun deleteByPhrase(phrase: String)
}
