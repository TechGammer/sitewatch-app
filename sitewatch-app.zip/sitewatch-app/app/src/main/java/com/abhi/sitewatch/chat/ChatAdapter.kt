package com.abhi.sitewatch.chat

import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.LinearLayout
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView

private const val VIEW_TYPE_USER = 0
private const val VIEW_TYPE_ASSISTANT = 1

class ChatAdapter : RecyclerView.Adapter<ChatAdapter.BubbleViewHolder>() {

    private val messages = mutableListOf<DisplayMessage>()

    fun submitList(list: List<DisplayMessage>) {
        messages.clear()
        messages.addAll(list)
        notifyDataSetChanged()
    }

    fun appendMessage(message: DisplayMessage) {
        messages.add(message)
        notifyItemInserted(messages.size - 1)
    }

    override fun getItemViewType(position: Int): Int =
        if (messages[position].role == "user") VIEW_TYPE_USER else VIEW_TYPE_ASSISTANT

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): BubbleViewHolder {
        val context = parent.context
        val density = context.resources.displayMetrics.density
        fun dp(v: Int) = (v * density).toInt()

        val row = LinearLayout(context).apply {
            layoutParams = RecyclerView.LayoutParams(
                RecyclerView.LayoutParams.MATCH_PARENT,
                RecyclerView.LayoutParams.WRAP_CONTENT
            )
            orientation = LinearLayout.HORIZONTAL
            setPadding(dp(12), dp(4), dp(12), dp(4))
        }

        val bubble = TextView(context).apply {
            setPadding(dp(14), dp(10), dp(14), dp(10))
            setTextColor(if (viewType == VIEW_TYPE_USER) Color.WHITE else Color.parseColor("#1A1A1A"))
            textSize = 15f
            background = roundedBackground(
                if (viewType == VIEW_TYPE_USER) Color.parseColor("#2F6FED") else Color.parseColor("#E9E9EE"),
                dp(16)
            )
        }

        val bubbleParams = LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.WRAP_CONTENT,
            LinearLayout.LayoutParams.WRAP_CONTENT
        ).apply {
            val maxWidth = (context.resources.displayMetrics.widthPixels * 0.8).toInt()
            width = LinearLayout.LayoutParams.WRAP_CONTENT
            // Constrain long messages by wrapping via a fixed max width on the TextView itself.
            bubble.maxWidth = maxWidth
        }
        row.gravity = if (viewType == VIEW_TYPE_USER) Gravity.END else Gravity.START
        row.addView(bubble, bubbleParams)

        return BubbleViewHolder(row, bubble)
    }

    override fun onBindViewHolder(holder: BubbleViewHolder, position: Int) {
        holder.bubble.text = messages[position].text
    }

    override fun getItemCount(): Int = messages.size

    class BubbleViewHolder(view: View, val bubble: TextView) : RecyclerView.ViewHolder(view)

    companion object {
        private fun roundedBackground(color: Int, radiusPx: Int): GradientDrawable {
            return GradientDrawable().apply {
                setColor(color)
                cornerRadius = radiusPx.toFloat()
            }
        }
    }
}
