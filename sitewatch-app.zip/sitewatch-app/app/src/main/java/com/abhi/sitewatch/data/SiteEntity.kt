package com.abhi.sitewatch.data

import androidx.room.Entity
import androidx.room.PrimaryKey

/**
 * One row per distinct WhatsApp group the notification listener has ever
 * seen. `groupName` is the raw WhatsApp conversation title (the join key
 * used everywhere else). `displayName` is the clean, human-facing name —
 * seeded automatically by SiteNameExtractor, editable via chat or the assistant's
 * own judgement. `tracked` controls whether messages from this group are
 * actually stored/reported; new groups default to untracked so a random
 * personal chat doesn't silently start getting logged.
 */
@Entity(tableName = "sites")
data class SiteEntity(
    @PrimaryKey val groupName: String,
    val displayName: String,
    val tracked: Boolean = false,
    val firstSeen: Long = System.currentTimeMillis(),
    val lastSeen: Long = System.currentTimeMillis(),
    val messageCount: Int = 0,
    val lastFastAlertAt: Long = 0 // debounce for the keyword-based instant breakdown ping
)
