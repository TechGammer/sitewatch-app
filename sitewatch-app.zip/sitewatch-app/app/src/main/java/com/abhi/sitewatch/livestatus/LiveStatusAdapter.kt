package com.abhi.sitewatch.livestatus

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.abhi.sitewatch.R
import com.abhi.sitewatch.worker.SiteStatusSummary
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.TimeUnit

/** Numbered list of every enabled site's live status, remark, and recency. */
class LiveStatusAdapter : RecyclerView.Adapter<LiveStatusAdapter.StatusViewHolder>() {

    private val items = mutableListOf<SiteStatusSummary>()
    private val timeFmt = SimpleDateFormat("HH:mm", Locale.getDefault())

    fun submitList(list: List<SiteStatusSummary>) {
        items.clear()
        items.addAll(list)
        notifyDataSetChanged()
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): StatusViewHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.item_live_status, parent, false)
        return StatusViewHolder(view)
    }

    override fun onBindViewHolder(holder: StatusViewHolder, position: Int) {
        holder.bind(position + 1, items[position])
    }

    override fun getItemCount(): Int = items.size

    private fun statusEmoji(status: String?): String = when (status) {
        "RUNNING" -> "🟢"
        "IDLE" -> "🟡"
        "BREAKDOWN" -> "🔴"
        "STOPPED" -> "⚪"
        else -> "❔"
    }

    private fun agoText(ms: Long): String {
        val diff = System.currentTimeMillis() - ms
        val hours = TimeUnit.MILLISECONDS.toHours(diff)
        val mins = TimeUnit.MILLISECONDS.toMinutes(diff)
        return when {
            mins < 1 -> "just now"
            hours < 1 -> "${mins}m ago"
            hours < 24 -> "${hours}h ago"
            else -> "${hours / 24}d ago"
        }
    }

    inner class StatusViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        private val numberText = itemView.findViewById<TextView>(R.id.numberText)
        private val statusEmojiText = itemView.findViewById<TextView>(R.id.statusEmoji)
        private val siteNameText = itemView.findViewById<TextView>(R.id.siteNameText)
        private val statusLabelText = itemView.findViewById<TextView>(R.id.statusLabelText)
        private val remarkText = itemView.findViewById<TextView>(R.id.remarkText)

        fun bind(number: Int, item: SiteStatusSummary) {
            numberText.text = "$number."
            siteNameText.text = item.displayName
            statusEmojiText.text = statusEmoji(item.status)

            statusLabelText.text = when {
                item.status != null && item.statusAtMs != null ->
                    "${item.status} as per last update ${timeFmt.format(Date(item.statusAtMs))} (${agoText(item.statusAtMs)})"
                item.lastMessageAtMs != null ->
                    "No status stated — last message ${timeFmt.format(Date(item.lastMessageAtMs))} (${agoText(item.lastMessageAtMs)})"
                else -> "No messages captured yet"
            }

            remarkText.text = item.remark ?: item.lastMessage ?: ""
            remarkText.visibility = if (remarkText.text.isNullOrBlank()) View.GONE else View.VISIBLE
        }
    }
}
