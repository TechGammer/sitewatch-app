package com.abhi.sitewatch.network

import okhttp3.Call
import okhttp3.Callback
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import okhttp3.Response
import org.json.JSONArray
import org.json.JSONObject
import java.io.IOException
import java.util.concurrent.TimeUnit
import kotlin.coroutines.resume
import kotlin.coroutines.resumeWithException
import kotlin.coroutines.suspendCoroutine

/**
 * Drives the Anthropic Messages API tool-use loop: send the conversation,
 * and if Claude responds with tool_use blocks, execute them via the
 * supplied [ToolExecutor] and feed the results back — repeating until
 * Claude produces a final text answer (stop_reason != "tool_use") or the
 * round-trip cap is hit.
 *
 * The full API-format history (including tool_use/tool_result blocks) is
 * passed in and mutated in place via [onTurnAppended], so the caller can
 * persist every turn as it happens rather than only at the end.
 */
object ClaudeChatClient {

    private val client = OkHttpClient.Builder()
        .connectTimeout(30, TimeUnit.SECONDS)
        .readTimeout(60, TimeUnit.SECONDS)
        .build()
    private const val ENDPOINT = "https://api.anthropic.com/v1/messages"
    private const val MAX_TOOL_ROUNDTRIPS = 6

    fun interface ToolExecutor {
        suspend fun execute(name: String, input: JSONObject): String
    }

    fun interface TurnListener {
        /** Called each time a turn (assistant or user/tool_result) is appended to history. */
        suspend fun onTurnAppended(role: String, content: JSONArray)
    }

    /**
     * @param history mutable, ordered list of {role, content} turns already in the conversation
     * @param userText the new user message to send
     * @param tools tool schemas in Anthropic's `tools` parameter format
     * @param systemPrompt the system prompt for this conversation
     * @param toolExecutor runs a named tool call and returns its result as a string
     * @param onAssistantText called with each piece of assistant-visible text as it's produced,
     *        including "thinking out loud" text that precedes a tool call — lets the UI show
     *        progress rather than waiting silently through the whole tool loop
     */
    suspend fun sendMessage(
        apiKey: String,
        model: String,
        history: MutableList<JSONObject>,
        userText: String,
        tools: JSONArray,
        systemPrompt: String,
        toolExecutor: ToolExecutor,
        turnListener: TurnListener,
        onAssistantText: suspend (String) -> Unit
    ) {
        val userContent = JSONArray().put(JSONObject().apply {
            put("type", "text")
            put("text", userText)
        })
        history.add(JSONObject().apply { put("role", "user"); put("content", userContent) })
        turnListener.onTurnAppended("user", userContent)

        var roundTrips = 0
        while (true) {
            val response = callApi(apiKey, model, history, tools, systemPrompt)
            val contentArr = response.getJSONArray("content")
            history.add(JSONObject().apply { put("role", "assistant"); put("content", contentArr) })
            turnListener.onTurnAppended("assistant", contentArr)

            // Surface any text Claude produced this turn immediately, even if
            // it also called a tool in the same turn.
            for (i in 0 until contentArr.length()) {
                val block = contentArr.getJSONObject(i)
                if (block.getString("type") == "text") {
                    val text = block.optString("text", "")
                    if (text.isNotBlank()) onAssistantText(text)
                }
            }

            val stopReason = response.optString("stop_reason", "")
            if (stopReason != "tool_use") {
                return
            }
            roundTrips++
            if (roundTrips > MAX_TOOL_ROUNDTRIPS) {
                onAssistantText("(Stopped after too many tool calls in a row — try rephrasing or breaking that into a smaller request.)")
                return
            }

            val resultBlocks = JSONArray()
            for (i in 0 until contentArr.length()) {
                val block = contentArr.getJSONObject(i)
                if (block.getString("type") == "tool_use") {
                    val toolUseId = block.getString("id")
                    val name = block.getString("name")
                    val input = block.optJSONObject("input") ?: JSONObject()
                    val resultText = try {
                        toolExecutor.execute(name, input)
                    } catch (e: Exception) {
                        "Error running tool: ${e.message}"
                    }
                    resultBlocks.put(JSONObject().apply {
                        put("type", "tool_result")
                        put("tool_use_id", toolUseId)
                        put("content", resultText)
                    })
                }
            }
            history.add(JSONObject().apply { put("role", "user"); put("content", resultBlocks) })
            turnListener.onTurnAppended("user", resultBlocks)
        }
    }

    private suspend fun callApi(
        apiKey: String,
        model: String,
        history: List<JSONObject>,
        tools: JSONArray,
        systemPrompt: String
    ): JSONObject {
        val payload = JSONObject().apply {
            put("model", model)
            put("max_tokens", 2000)
            put("system", systemPrompt)
            put("tools", tools)
            put("messages", JSONArray(history))
        }

        val request = Request.Builder()
            .url(ENDPOINT)
            .addHeader("x-api-key", apiKey)
            .addHeader("anthropic-version", "2023-06-01")
            .addHeader("content-type", "application/json")
            .post(payload.toString().toRequestBody("application/json".toMediaType()))
            .build()

        return suspendCoroutine { cont ->
            client.newCall(request).enqueue(object : Callback {
                override fun onFailure(call: Call, e: IOException) {
                    cont.resumeWithException(e)
                }

                override fun onResponse(call: Call, response: Response) {
                    response.use {
                        val raw = it.body?.string() ?: "{}"
                        try {
                            if (!it.isSuccessful) {
                                cont.resumeWithException(IOException("Anthropic API error ${it.code}: $raw"))
                                return
                            }
                            cont.resume(JSONObject(raw))
                        } catch (e: Exception) {
                            cont.resumeWithException(e)
                        }
                    }
                }
            })
        }
    }
}
