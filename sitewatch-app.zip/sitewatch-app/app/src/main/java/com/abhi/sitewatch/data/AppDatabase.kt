package com.abhi.sitewatch.data

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.room.migration.Migration
import androidx.sqlite.db.SupportSQLiteDatabase

@Database(
    entities = [SiteMessage::class, SiteEntity::class, ChatTurnEntity::class, ReportEntity::class, StatusEventEntity::class],
    version = 6,
    exportSchema = false
)
abstract class AppDatabase : RoomDatabase() {

    abstract fun messageDao(): MessageDao
    abstract fun siteDao(): SiteDao
    abstract fun chatDao(): ChatDao
    abstract fun reportDao(): ReportDao
    abstract fun statusEventDao(): StatusEventDao

    companion object {
        @Volatile private var INSTANCE: AppDatabase? = null

        // Adds indices for the app's hot query paths (per-site message/report/status
        // lookups, and the reported-flag filter checked on every incoming WhatsApp
        // message) so query latency doesn't creep up as these tables grow over months
        // of use. Real Migration, not fallbackToDestructiveMigration — this app's whole
        // value is accumulated history, so a schema bump must never silently wipe it.
        // Index names must match Room's own "index_<table>_<col1>_<col2>" convention
        // exactly, or Room's startup schema check throws.
        private val MIGRATION_5_6 = object : Migration(5, 6) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL("CREATE INDEX IF NOT EXISTS index_site_messages_groupName_reported ON site_messages(groupName, reported)")
                db.execSQL("CREATE INDEX IF NOT EXISTS index_reports_groupName ON reports(groupName)")
                db.execSQL("CREATE INDEX IF NOT EXISTS index_status_events_groupName_timestamp ON status_events(groupName, timestamp)")
            }
        }

        fun getInstance(context: Context): AppDatabase {
            return INSTANCE ?: synchronized(this) {
                INSTANCE ?: Room.databaseBuilder(
                    context.applicationContext,
                    AppDatabase::class.java,
                    "sitewatch.db"
                )
                    .addMigrations(MIGRATION_5_6)
                    // Only wipes on a genuine downgrade (e.g. an older APK reinstalled
                    // over a newer DB) — upgrades always go through a real migration above.
                    .fallbackToDestructiveMigrationOnDowngrade()
                    .build().also { INSTANCE = it }
            }
        }
    }
}
