package com.abhi.sitewatch.data

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.room.migration.Migration
import androidx.sqlite.db.SupportSQLiteDatabase

@Database(
    entities = [SiteMessage::class, SiteEntity::class, ChatTurnEntity::class, ReportEntity::class, StatusEventEntity::class, MemoryEntity::class, MachineProfileEntity::class, StatusKeywordEntity::class],
    version = 9,
    exportSchema = false
)
abstract class AppDatabase : RoomDatabase() {

    abstract fun messageDao(): MessageDao
    abstract fun siteDao(): SiteDao
    abstract fun chatDao(): ChatDao
    abstract fun reportDao(): ReportDao
    abstract fun statusEventDao(): StatusEventDao
    abstract fun memoryDao(): MemoryDao
    abstract fun machineProfileDao(): MachineProfileDao
    abstract fun statusKeywordDao(): StatusKeywordDao

    companion object {
        @Volatile private var INSTANCE: AppDatabase? = null

        // Adds indices for the app's hot query paths (per-site message/report/status
        // lookups, and the reported-flag filter checked on every incoming WhatsApp
        // message) so query latency doesn't creep up as these tables grow over months
        // of use. Real Migration, not fallbackToDestructiveMigration — this app's whole
        // value is accumulated history, so a schema bump must never silently wipe it.
        // Index names must match Room's own "index_<table>_<col1>_<col2>" convention
        // exactly, or Room's startup schema check throws.
        private val MIGRATION_5_6 = object : Migration(5, 6) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL("CREATE INDEX IF NOT EXISTS index_site_messages_groupName_reported ON site_messages(groupName, reported)")
                db.execSQL("CREATE INDEX IF NOT EXISTS index_reports_groupName ON reports(groupName)")
                db.execSQL("CREATE INDEX IF NOT EXISTS index_status_events_groupName_timestamp ON status_events(groupName, timestamp)")
            }
        }

        // Adds the `memories` table backing the assistant's persistent
        // memory (remember_fact/forget_fact/list_memories chat tools) — a
        // new table, so this is just its CREATE TABLE, matching exactly
        // what Room's own codegen would produce for MemoryEntity.
        private val MIGRATION_6_7 = object : Migration(6, 7) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL(
                    "CREATE TABLE IF NOT EXISTS `memories` (`id` INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, `content` TEXT NOT NULL, `createdAt` INTEGER NOT NULL)"
                )
            }
        }

        // Adds the `machine_profiles` table (set_machine_profile/
        // get_machine_profile/get_machine_metrics chat tools) — a single-
        // column TEXT primary key (groupName, non-autogenerate) follows the
        // same PRIMARY KEY(`col`) table-constraint form Room already uses
        // for SiteEntity's own groupName primary key in this codebase.
        private val MIGRATION_7_8 = object : Migration(7, 8) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL(
                    "CREATE TABLE IF NOT EXISTS `machine_profiles` (`groupName` TEXT NOT NULL, `machineType` TEXT, `makeModel` TEXT, `ratedCapacityTph` REAL, `installDateText` TEXT, `lastServiceDateText` TEXT, `notes` TEXT, PRIMARY KEY(`groupName`))"
                )
            }
        }

        // Adds the `status_keywords` table backing chat's add_status_keyword/
        // remove_status_keyword/list_status_keywords tools — user-taught
        // phrase-to-status mappings that customize PlantStatusDetector's
        // built-in reading for this specific business/site.
        private val MIGRATION_8_9 = object : Migration(8, 9) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL(
                    "CREATE TABLE IF NOT EXISTS `status_keywords` (`id` INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, `phrase` TEXT NOT NULL, `status` TEXT NOT NULL, `groupName` TEXT)"
                )
            }
        }

        fun getInstance(context: Context): AppDatabase {
            return INSTANCE ?: synchronized(this) {
                INSTANCE ?: Room.databaseBuilder(
                    context.applicationContext,
                    AppDatabase::class.java,
                    "sitewatch.db"
                )
                    .addMigrations(MIGRATION_5_6, MIGRATION_6_7, MIGRATION_7_8, MIGRATION_8_9)
                    // Only wipes on a genuine downgrade (e.g. an older APK reinstalled
                    // over a newer DB) — upgrades always go through a real migration above.
                    .fallbackToDestructiveMigrationOnDowngrade()
                    .build().also { INSTANCE = it }
            }
        }

        /**
         * Closes the live connection and drops the cached singleton so the
         * underlying .db file can be safely overwritten (BackupManager.restore)
         * — the next getInstance() call opens a fresh connection against
         * whatever file is on disk at that point.
         */
        fun closeAndReset() {
            synchronized(this) {
                INSTANCE?.close()
                INSTANCE = null
            }
        }
    }
}
