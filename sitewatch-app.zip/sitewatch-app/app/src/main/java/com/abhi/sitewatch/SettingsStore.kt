package com.abhi.sitewatch

import android.content.Context
import android.content.SharedPreferences

/**
 * Plain SharedPreferences for now. If you want this hardened later, switch to
 * EncryptedSharedPreferences (androidx.security:security-crypto) since this
 * file holds your OpenRouter API key and Telegram bot token in cleartext.
 *
 * Site tracking itself lives in the Room `sites` table (see SiteDao), not
 * here — this class only holds bootstrap credentials and schedule config.
 */
class SettingsStore(context: Context) {

    private val prefs: SharedPreferences =
        context.getSharedPreferences("sitewatch_settings", Context.MODE_PRIVATE)

    var openRouterApiKey: String
        get() = prefs.getString("openrouter_api_key", "") ?: ""
        set(value) = prefs.edit().putString("openrouter_api_key", value).apply()

    var telegramBotToken: String
        get() = prefs.getString("telegram_bot_token", "") ?: ""
        set(value) = prefs.edit().putString("telegram_bot_token", value).apply()

    var telegramChatId: String
        get() = prefs.getString("telegram_chat_id", "") ?: ""
        set(value) = prefs.edit().putString("telegram_chat_id", value).apply()

    var reportIntervalHours: Int
        get() = prefs.getInt("report_interval_hours", 6)
        set(value) = prefs.edit().putInt("report_interval_hours", value).apply()

    // Quiet hours: skip auto-sending a report while the current local hour
    // falls in [quietHoursStart, quietHoursEnd). 24h clock, 0-23. Equal
    // start/end (the default) means quiet hours are disabled.
    var quietHoursStart: Int
        get() = prefs.getInt("quiet_hours_start", 0)
        set(value) = prefs.edit().putInt("quiet_hours_start", value).apply()

    var quietHoursEnd: Int
        get() = prefs.getInt("quiet_hours_end", 0)
        set(value) = prefs.edit().putInt("quiet_hours_end", value).apply()

    val quietHoursEnabled: Boolean
        get() = quietHoursStart != quietHoursEnd

    // Alert thresholds — all chat-configurable via set_alert_settings.
    var tphDropAlertPercent: Double
        get() = prefs.getFloat("tph_drop_alert_percent", 20.0f).toDouble()
        set(value) = prefs.edit().putFloat("tph_drop_alert_percent", value.toFloat()).apply()

    var quietSiteThresholdHours: Int
        get() = prefs.getInt("quiet_site_threshold_hours", 48)
        set(value) = prefs.edit().putInt("quiet_site_threshold_hours", value).apply()

    var idleAlertMinHours: Int
        get() = prefs.getInt("idle_alert_min_hours", 4)
        set(value) = prefs.edit().putInt("idle_alert_min_hours", value).apply()

    var idleAlertMaxHours: Int
        get() = prefs.getInt("idle_alert_max_hours", 12)
        set(value) = prefs.edit().putInt("idle_alert_max_hours", value).apply()

    // Fast keyword-based breakdown alert — chat-configurable via
    // set_fast_alert_keywords / set_fast_alert_debounce_minutes.
    var fastAlertKeywords: String
        get() = prefs.getString("fast_alert_keywords", DEFAULT_FAST_ALERT_KEYWORDS) ?: DEFAULT_FAST_ALERT_KEYWORDS
        set(value) = prefs.edit().putString("fast_alert_keywords", value).apply()

    fun fastAlertKeywordList(): List<String> =
        fastAlertKeywords.split(",").map { it.trim().lowercase() }.filter { it.isNotEmpty() }

    var fastAlertDebounceMinutes: Int
        get() = prefs.getInt("fast_alert_debounce_minutes", 30)
        set(value) = prefs.edit().putInt("fast_alert_debounce_minutes", value).apply()

    // OpenRouter model used for both chat and report extraction —
    // chat-configurable via set_model. The default, "openrouter/free", is
    // OpenRouter's router that auto-selects a free model with tool-calling
    // and structured-output support, so no hardcoded model ID can rotate out
    // from under us.
    var modelId: String
        get() {
            val stored = prefs.getString("model_id", DEFAULT_MODEL) ?: DEFAULT_MODEL
            // A bare "claude-*" ID persisted by the pre-OpenRouter build
            // isn't valid on OpenRouter — reset it to the default.
            return if (stored.startsWith("claude-")) DEFAULT_MODEL else stored
        }
        set(value) = prefs.edit().putString("model_id", value).apply()

    // Extra fields to extract per report beyond the built-in tph/issues/pending
    // (e.g. "fuel_factor,diesel_usage") — chat-configurable via
    // add_report_field / remove_report_field.
    var additionalReportFields: String
        get() = prefs.getString("additional_report_fields", "") ?: ""
        set(value) = prefs.edit().putString("additional_report_fields", value).apply()

    fun additionalReportFieldList(): List<String> =
        additionalReportFields.split(",").map { it.trim() }.filter { it.isNotEmpty() }

    fun isConfigured(): Boolean =
        openRouterApiKey.isNotBlank()

    fun isTelegramConfigured(): Boolean =
        telegramBotToken.isNotBlank() && telegramChatId.isNotBlank()

    companion object {
        const val DEFAULT_MODEL = "openrouter/free"
        const val DEFAULT_FAST_ALERT_KEYWORDS =
            "breakdown,break down,not working,stopped working,band ho,bandh,kharab,kharaab,jam ho,belt jam,chalu nahi,band hai"
    }
}
