package com.abhi.sitewatch.worker

/**
 * Pulls the first plausible number out of a TPH string like "185 TPH",
 * "approx 150-160", or "not mentioned" (-> null). Deliberately simple:
 * for ranges, takes the first number rather than averaging, since that's
 * closer to what a human skimming the group would report as "roughly X".
 */
object TphParser {
    private val NUMBER_REGEX = Regex("\\d+(\\.\\d+)?")

    fun parse(tphRaw: String): Double? {
        val match = NUMBER_REGEX.find(tphRaw) ?: return null
        return match.value.toDoubleOrNull()
    }
}
