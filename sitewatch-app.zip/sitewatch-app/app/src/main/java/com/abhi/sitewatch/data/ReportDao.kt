package com.abhi.sitewatch.data

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.Query

@Dao
interface ReportDao {

    @Insert
    suspend fun insert(report: ReportEntity): Long

    @Query(
        "SELECT * FROM reports WHERE groupName = :groupName " +
        "ORDER BY timestamp DESC LIMIT :limit"
    )
    suspend fun recentForSite(groupName: String, limit: Int): List<ReportEntity>

    @Query("SELECT * FROM reports WHERE groupName = :groupName ORDER BY timestamp DESC LIMIT 1")
    suspend fun latestForSite(groupName: String): ReportEntity?

    @Query("DELETE FROM reports WHERE groupName = :groupName")
    suspend fun deleteAllForGroup(groupName: String)

    @Query("UPDATE reports SET groupName = :newName WHERE groupName = :oldName")
    suspend fun reassignGroup(oldName: String, newName: String)
}
