package com.abhi.sitewatch.sitemanager

import android.os.Bundle
import android.view.View
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.Toolbar
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.abhi.sitewatch.R
import com.abhi.sitewatch.data.AppDatabase
import com.abhi.sitewatch.data.SiteDao
import kotlinx.coroutines.launch

/**
 * A deterministic, native alternative to asking chat to track/rename a
 * site: every detected WhatsApp group in one list, tracking toggled with a
 * switch, display name edited inline. Chat's `upsert_site` tool writes to
 * the exact same table — this exists so a simple, common action doesn't
 * depend on the chat model correctly interpreting a request (or on its
 * formatting quality, which varies a lot more now that report/chat calls
 * route through rotating free-tier models instead of one fixed provider).
 */
class SiteManagerActivity : AppCompatActivity() {

    private lateinit var adapter: SiteManagerAdapter
    private lateinit var siteDao: SiteDao

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_site_manager)
        setSupportActionBar(findViewById<Toolbar>(R.id.toolbar))

        siteDao = AppDatabase.getInstance(this).siteDao()

        adapter = SiteManagerAdapter(
            onTrackedChanged = { site, tracked ->
                lifecycleScope.launch { siteDao.updateTracked(site.groupName, tracked) }
            },
            onDisplayNameChanged = { site, newName ->
                lifecycleScope.launch { siteDao.updateDisplayName(site.groupName, newName) }
            }
        )

        findViewById<RecyclerView>(R.id.siteRecyclerView).apply {
            layoutManager = LinearLayoutManager(this@SiteManagerActivity)
            adapter = this@SiteManagerActivity.adapter
        }
        // No refresh() call here — onResume() always runs right after onCreate()
        // on initial launch too, so it alone covers both cases without a double load.
    }

    override fun onResume() {
        super.onResume()
        refresh()
    }

    private fun refresh() {
        lifecycleScope.launch {
            val sites = siteDao.getAll()
            adapter.submitList(sites)
            findViewById<TextView>(R.id.emptyText).visibility = if (sites.isEmpty()) View.VISIBLE else View.GONE
        }
    }
}
