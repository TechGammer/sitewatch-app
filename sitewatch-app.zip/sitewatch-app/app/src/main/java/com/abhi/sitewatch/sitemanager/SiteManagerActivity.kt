package com.abhi.sitewatch.sitemanager

import android.app.AlertDialog
import android.os.Bundle
import android.view.Menu
import android.view.MenuItem
import android.view.View
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.Toolbar
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.abhi.sitewatch.R
import com.abhi.sitewatch.data.AppDatabase
import com.abhi.sitewatch.data.SiteDao
import com.abhi.sitewatch.data.SiteEntity
import com.abhi.sitewatch.data.SiteMaintenance
import kotlinx.coroutines.launch

/**
 * A deterministic, native alternative to asking chat to track/rename/remove
 * a site: every detected WhatsApp group in one list, tracking toggled with a
 * switch, display name edited inline, delete per row, and a "Merge
 * duplicates" action for cleaning up any leftover count-suffix duplicates.
 * Chat's tools write to the exact same tables — this exists so common
 * actions don't depend on the chat model correctly interpreting a request.
 */
class SiteManagerActivity : AppCompatActivity() {

    private lateinit var adapter: SiteManagerAdapter
    private lateinit var db: AppDatabase
    private lateinit var siteDao: SiteDao

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_site_manager)
        setSupportActionBar(findViewById<Toolbar>(R.id.toolbar))

        db = AppDatabase.getInstance(this)
        siteDao = db.siteDao()

        adapter = SiteManagerAdapter(
            onTrackedChanged = { site, tracked ->
                lifecycleScope.launch { siteDao.updateTracked(site.groupName, tracked) }
            },
            onDisplayNameChanged = { site, newName ->
                lifecycleScope.launch { siteDao.updateDisplayName(site.groupName, newName) }
            },
            onDelete = { site -> confirmDelete(site) }
        )

        findViewById<RecyclerView>(R.id.siteRecyclerView).apply {
            layoutManager = LinearLayoutManager(this@SiteManagerActivity)
            adapter = this@SiteManagerActivity.adapter
        }
    }

    override fun onCreateOptionsMenu(menu: Menu): Boolean {
        menuInflater.inflate(R.menu.menu_site_manager, menu)
        return true
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        return when (item.itemId) {
            R.id.action_merge_duplicates -> {
                mergeDuplicates()
                true
            }
            else -> super.onOptionsItemSelected(item)
        }
    }

    override fun onResume() {
        super.onResume()
        refresh()
    }

    private fun refresh() {
        lifecycleScope.launch {
            val sites = siteDao.getAll()
            adapter.submitList(sites)
            findViewById<TextView>(R.id.emptyText).visibility = if (sites.isEmpty()) View.VISIBLE else View.GONE
        }
    }

    private fun confirmDelete(site: SiteEntity) {
        AlertDialog.Builder(this)
            .setTitle("Delete ${site.displayName}?")
            .setMessage("This permanently removes the site and all its stored messages, reports, and status history. This can't be undone.")
            .setPositiveButton("Delete") { _, _ ->
                lifecycleScope.launch {
                    db.messageDao().deleteAllForGroup(site.groupName)
                    db.reportDao().deleteAllForGroup(site.groupName)
                    db.statusEventDao().deleteAllForGroup(site.groupName)
                    db.machineProfileDao().deleteForSite(site.groupName)
                    siteDao.delete(site.groupName)
                    refresh()
                    Toast.makeText(this@SiteManagerActivity, "Deleted", Toast.LENGTH_SHORT).show()
                }
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun mergeDuplicates() {
        lifecycleScope.launch {
            val merged = try {
                SiteMaintenance.dedupeAndNormalize(applicationContext)
            } catch (e: Exception) {
                Toast.makeText(this@SiteManagerActivity, "Merge failed: ${e.message}", Toast.LENGTH_LONG).show()
                return@launch
            }
            refresh()
            val msg = if (merged == 0) "No duplicates found — all clean." else "Merged $merged duplicate site(s)."
            Toast.makeText(this@SiteManagerActivity, msg, Toast.LENGTH_LONG).show()
        }
    }
}
