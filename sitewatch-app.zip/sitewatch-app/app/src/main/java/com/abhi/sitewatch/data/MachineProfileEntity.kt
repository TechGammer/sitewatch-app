package com.abhi.sitewatch.data

import androidx.room.Entity
import androidx.room.PrimaryKey

/**
 * Structured facts about the actual machine/crusher at a site — set via
 * chat's `set_machine_profile` tool. This is what lets the assistant
 * compare real output against spec ("running 140 against a 200 TPH rated
 * capacity") instead of only ever describing things in relative terms.
 * Dates are stored as free text (whatever the user actually said, e.g.
 * "March 2023") rather than parsed — this app has no need to compute date
 * arithmetic on them, only to display them back.
 */
@Entity(tableName = "machine_profiles")
data class MachineProfileEntity(
    @PrimaryKey val groupName: String,
    val machineType: String? = null,
    val makeModel: String? = null,
    val ratedCapacityTph: Double? = null,
    val installDateText: String? = null,
    val lastServiceDateText: String? = null,
    val notes: String? = null
)
