package com.abhi.sitewatch.dashboard

import android.content.Intent
import android.os.Bundle
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.Toolbar
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.abhi.sitewatch.R
import com.abhi.sitewatch.chat.ChatActivity
import com.abhi.sitewatch.livestatus.LiveStatusActivity
import com.abhi.sitewatch.sitemanager.SiteManagerActivity
import com.abhi.sitewatch.worker.ReportGenerator
import kotlinx.coroutines.launch

/**
 * Read-only overview of tracked sites — the concrete answer to "there's no
 * dashboard". Everything here is derived from the same tables chat's tools
 * read/write; this screen never mutates anything, so there's no risk of it
 * drifting out of sync with what chat reports.
 */
class DashboardActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_dashboard)

        setSupportActionBar(findViewById<Toolbar>(R.id.toolbar))

        val recyclerView = findViewById<RecyclerView>(R.id.siteRecyclerView)

        val adapter = DashboardAdapter { site ->
            val intent = Intent(this, ChatActivity::class.java)
            intent.putExtra(ChatActivity.EXTRA_PREFILL, "What's the latest at ${site.displayName}?")
            startActivity(intent)
        }
        recyclerView.layoutManager = LinearLayoutManager(this)
        recyclerView.adapter = adapter

        findViewById<android.widget.Button>(R.id.openChatButton).setOnClickListener {
            startActivity(Intent(this, ChatActivity::class.java))
        }

        findViewById<android.widget.Button>(R.id.manageSitesButton).setOnClickListener {
            startActivity(Intent(this, SiteManagerActivity::class.java))
        }

        findViewById<android.widget.Button>(R.id.liveStatusButton).setOnClickListener {
            startActivity(Intent(this, LiveStatusActivity::class.java))
        }
        // No refresh() call here — onResume() always runs right after onCreate()
        // on initial launch too, so it alone covers both cases without a double load.
    }

    override fun onResume() {
        super.onResume()
        // Cheap enough to just recompute — keeps this in sync if the user
        // tracked/untracked sites or generated a report from chat and came back.
        refresh(
            findViewById<RecyclerView>(R.id.siteRecyclerView).adapter as? DashboardAdapter ?: return,
            findViewById(R.id.emptyText),
            findViewById(R.id.alertsText)
        )
    }

    private fun refresh(adapter: DashboardAdapter, emptyText: TextView, alertsText: TextView) {
        lifecycleScope.launch {
            val summaries = SiteSummary.computeAll(applicationContext)
            adapter.submitList(summaries)
            emptyText.visibility = if (summaries.isEmpty()) android.view.View.VISIBLE else android.view.View.GONE

            val alerts = ReportGenerator.currentAlerts(applicationContext)
            if (alerts.isEmpty()) {
                alertsText.visibility = android.view.View.GONE
            } else {
                alertsText.visibility = android.view.View.VISIBLE
                alertsText.text = "⚠️ " + alerts.joinToString("\n⚠️ ")
            }
        }
    }
}
