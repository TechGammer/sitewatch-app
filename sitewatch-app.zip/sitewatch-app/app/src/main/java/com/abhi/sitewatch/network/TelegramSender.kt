package com.abhi.sitewatch.network

import okhttp3.Call
import okhttp3.Callback
import okhttp3.FormBody
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.Response
import java.io.IOException
import kotlin.coroutines.resume
import kotlin.coroutines.resumeWithException
import kotlin.coroutines.suspendCoroutine

object TelegramSender {

    private val client = OkHttpClient()
    private const val TELEGRAM_MESSAGE_LIMIT = 4000 // Telegram's real cap is 4096; leave margin

    suspend fun send(botToken: String, chatId: String, text: String) {
        for (chunk in chunk(text)) {
            sendOne(botToken, chatId, chunk)
        }
    }

    private fun chunk(text: String): List<String> {
        if (text.length <= TELEGRAM_MESSAGE_LIMIT) return listOf(text)
        return text.chunked(TELEGRAM_MESSAGE_LIMIT)
    }

    private suspend fun sendOne(botToken: String, chatId: String, text: String) {
        val url = "https://api.telegram.org/bot$botToken/sendMessage"
        val formBody = FormBody.Builder()
            .add("chat_id", chatId)
            .add("text", text)
            .add("parse_mode", "Markdown")
            .build()

        val request = Request.Builder().url(url).post(formBody).build()

        suspendCoroutine<Unit> { cont ->
            client.newCall(request).enqueue(object : Callback {
                override fun onFailure(call: Call, e: IOException) {
                    cont.resumeWithException(e)
                }

                override fun onResponse(call: Call, response: Response) {
                    response.use {
                        if (!it.isSuccessful) {
                            cont.resumeWithException(IOException("Telegram API error ${it.code}: ${it.body?.string()}"))
                        } else {
                            cont.resume(Unit)
                        }
                    }
                }
            })
        }
    }
}
