package com.abhi.sitewatch.dashboard

import android.content.Context
import com.abhi.sitewatch.data.AppDatabase
import com.abhi.sitewatch.worker.RunningHoursCalculator
import org.json.JSONArray
import java.util.concurrent.TimeUnit

data class SiteSummary(
    val displayName: String,
    val groupName: String,
    val lastTphRaw: String?,
    val trendArrow: String,     // "▲", "▼", "–", or "" if no history yet
    val lastReportAgo: String?, // null if never reported
    val pendingCount: Int,
    val isQuiet: Boolean,       // tracked but no messages in a while
    val currentStatus: String?, // "RUNNING" | "IDLE" | "BREAKDOWN" | "STOPPED" | null if unknown
    val statusAgeHours: Double?,
    val runningHoursToday: Double
) {
    companion object {
        private const val QUIET_THRESHOLD_HOURS = 48

        suspend fun computeAll(context: Context): List<SiteSummary> {
            val db = AppDatabase.getInstance(context)
            val sites = db.siteDao().getTracked()
            val reportDao = db.reportDao()
            val statusEventDao = db.statusEventDao()
            val now = System.currentTimeMillis()
            val startOfToday = RunningHoursCalculator.startOfToday()

            return sites.map { site ->
                val recent = reportDao.recentForSite(site.groupName, 2)
                val latest = recent.getOrNull(0)
                val prev = recent.getOrNull(1)

                val latestTph = latest?.tphNumeric
                val prevTph = prev?.tphNumeric
                val trend = if (latestTph != null && prevTph != null) {
                    when {
                        latestTph > prevTph -> "▲"
                        latestTph < prevTph -> "▼"
                        else -> "–"
                    }
                } else ""

                val pendingCount = try {
                    latest?.let { JSONArray(it.pendingJson).length() } ?: 0
                } catch (e: Exception) { 0 }

                val hoursSinceSeen = TimeUnit.MILLISECONDS.toHours(now - site.lastSeen)

                val allEvents = statusEventDao.recentForSite(site.groupName, 500).sortedBy { it.timestamp }
                val todayTotals = RunningHoursCalculator.compute(allEvents, startOfToday, now)
                val statusAge = todayTotals.currentStatusSince?.let { (now - it) / 3_600_000.0 }

                SiteSummary(
                    displayName = site.displayName,
                    groupName = site.groupName,
                    lastTphRaw = latest?.tphRaw,
                    trendArrow = trend,
                    lastReportAgo = latest?.let { formatAgo(now - it.timestamp) },
                    pendingCount = pendingCount,
                    isQuiet = hoursSinceSeen >= QUIET_THRESHOLD_HOURS,
                    currentStatus = todayTotals.currentStatus,
                    statusAgeHours = statusAge,
                    runningHoursToday = todayTotals.hoursByStatus["RUNNING"] ?: 0.0
                )
            }
        }

        private fun formatAgo(millis: Long): String {
            val hours = TimeUnit.MILLISECONDS.toHours(millis)
            return if (hours < 1) "just now" else if (hours < 24) "${hours}h ago" else "${hours / 24}d ago"
        }
    }
}
