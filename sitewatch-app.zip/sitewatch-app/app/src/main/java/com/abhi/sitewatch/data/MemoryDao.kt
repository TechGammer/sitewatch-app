package com.abhi.sitewatch.data

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.Query

@Dao
interface MemoryDao {

    @Insert
    suspend fun insert(memory: MemoryEntity): Long

    @Query("SELECT * FROM memories ORDER BY id ASC")
    suspend fun getAll(): List<MemoryEntity>

    @Query("DELETE FROM memories WHERE content LIKE '%' || :searchText || '%'")
    suspend fun deleteMatching(searchText: String)

    // These are meant to stay a short list of durable facts, not a
    // transcript — if it ever grows past this the oldest are dropped.
    @Query("DELETE FROM memories WHERE id NOT IN (SELECT id FROM memories ORDER BY id DESC LIMIT :keepCount)")
    suspend fun trimToLast(keepCount: Int)
}
