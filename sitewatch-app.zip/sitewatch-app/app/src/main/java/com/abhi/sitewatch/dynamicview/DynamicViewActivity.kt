package com.abhi.sitewatch.dynamicview

import android.annotation.SuppressLint
import android.content.Intent
import android.os.Bundle
import android.webkit.JavascriptInterface
import android.webkit.WebView
import android.widget.Button
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import com.abhi.sitewatch.R
import com.abhi.sitewatch.chat.ChatActivity

/**
 * This is the real, honest answer to "let chat create screens": the model
 * can't generate new native Android Activities without a full rebuild —
 * that's not something a compiled app can do at runtime. What it CAN do
 * is generate self-contained HTML/CSS/JS on the fly and have this single
 * generic screen render it immediately. It's a web view being handed
 * content, not a new native screen — but it gets you the actual outcome
 * (a custom visual for whatever you asked for) without waiting on a
 * rebuild+reinstall cycle.
 *
 * Content is local only — blockNetworkLoads is on, so generated HTML
 * can't fetch anything external (no tracking pixels, no surprise
 * requests). A tiny JS bridge lets generated buttons hand text back to
 * chat (e.g. "Track this site") by calling Android.sendToChat(text).
 */
class DynamicViewActivity : AppCompatActivity() {

    companion object {
        const val EXTRA_TITLE = "extra_title"
        const val EXTRA_HTML = "extra_html"
    }

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_dynamic_view)

        findViewById<TextView>(R.id.dynamicViewTitle).text = intent.getStringExtra(EXTRA_TITLE) ?: "Site Watch"
        findViewById<Button>(R.id.closeButton).setOnClickListener { finish() }

        val webView = findViewById<WebView>(R.id.dynamicWebView)
        webView.settings.javaScriptEnabled = true
        webView.settings.blockNetworkLoads = true
        webView.addJavascriptInterface(JsBridge(), "Android")

        val bodyHtml = intent.getStringExtra(EXTRA_HTML) ?: "<p>Nothing to show.</p>"
        webView.loadDataWithBaseURL(null, wrapHtml(bodyHtml), "text/html", "UTF-8", null)
    }

    private fun wrapHtml(body: String): String = """
        <!DOCTYPE html>
        <html>
        <head>
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <style>
          body { font-family: -apple-system, Roboto, sans-serif; padding: 16px; color: #1A1A1A; }
          table { width: 100%; border-collapse: collapse; margin: 8px 0; }
          th, td { text-align: left; padding: 8px; border-bottom: 1px solid #E9E9EE; }
          button { background: #2F6FED; color: white; border: none; border-radius: 8px; padding: 10px 16px; font-size: 15px; }
          .card { background: #F5F5F7; border-radius: 12px; padding: 12px; margin: 8px 0; }
        </style>
        </head>
        <body>
        $body
        </body>
        </html>
    """.trimIndent()

    inner class JsBridge {
        @JavascriptInterface
        fun sendToChat(text: String) {
            runOnUiThread {
                val intent = Intent(this@DynamicViewActivity, ChatActivity::class.java)
                intent.putExtra(ChatActivity.EXTRA_PREFILL, text)
                startActivity(intent)
                finish()
            }
        }
    }
}
