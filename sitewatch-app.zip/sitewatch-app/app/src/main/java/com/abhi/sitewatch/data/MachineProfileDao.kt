package com.abhi.sitewatch.data

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query

@Dao
interface MachineProfileDao {

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(profile: MachineProfileEntity)

    @Query("SELECT * FROM machine_profiles WHERE groupName = :groupName LIMIT 1")
    suspend fun getForSite(groupName: String): MachineProfileEntity?

    @Query("DELETE FROM machine_profiles WHERE groupName = :groupName")
    suspend fun deleteForSite(groupName: String)
}
