package com.abhi.sitewatch.data

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query

@Dao
interface MachineProfileDao {

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(profile: MachineProfileEntity)

    @Query("SELECT * FROM machine_profiles WHERE groupName = :groupName LIMIT 1")
    suspend fun getForSite(groupName: String): MachineProfileEntity?

    @Query("DELETE FROM machine_profiles WHERE groupName = :groupName")
    suspend fun deleteForSite(groupName: String)

    // OR IGNORE: if the canonical site already has a profile, keep it and
    // leave the duplicate's row to be deleted by the caller rather than
    // hitting a primary-key conflict.
    @Query("UPDATE OR IGNORE machine_profiles SET groupName = :newName WHERE groupName = :oldName")
    suspend fun reassignGroup(oldName: String, newName: String)
}
