package com.abhi.sitewatch.data

import androidx.room.Entity
import androidx.room.PrimaryKey

/**
 * A short, durable fact the assistant chose to remember across chat
 * sessions — a stated preference, a recurring operational detail, a
 * correction — as opposed to the routine back-and-forth of a single
 * conversation. This is NOT model training or fine-tuning (this app does
 * neither): every remembered fact is re-injected into the system prompt on
 * every future chat call (see ChatTools.systemPrompt), which is what
 * actually gives the assistant continuity across sessions.
 */
@Entity(tableName = "memories")
data class MemoryEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val content: String,
    val createdAt: Long = System.currentTimeMillis()
)
