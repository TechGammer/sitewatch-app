package com.abhi.sitewatch.data

import androidx.room.Entity
import androidx.room.PrimaryKey

/**
 * A user-taught phrase → status mapping, set via chat's `add_status_keyword`
 * tool. PlantStatusDetector's built-in English/Hindi/Hinglish/Marathi list
 * is generic; this is how the assistant's understanding of THIS business's
 * specific phrasing gets customized — e.g. a site that always writes "plant
 * dead" instead of "breakdown". Checked before the built-in list, so a
 * taught phrase can override the generic reading.
 */
@Entity(tableName = "status_keywords")
data class StatusKeywordEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val phrase: String,
    val status: String, // RUNNING | IDLE | BREAKDOWN | STOPPED
    val groupName: String? = null // null = applies to all sites
)
