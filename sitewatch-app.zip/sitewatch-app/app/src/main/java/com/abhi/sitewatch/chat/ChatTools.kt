package com.abhi.sitewatch.chat

import android.content.Context
import android.content.Intent
import com.abhi.sitewatch.SettingsStore
import com.abhi.sitewatch.data.AppDatabase
import com.abhi.sitewatch.data.MachineProfileEntity
import com.abhi.sitewatch.data.MemoryEntity
import com.abhi.sitewatch.data.SiteEntity
import com.abhi.sitewatch.dynamicview.DynamicViewActivity
import com.abhi.sitewatch.network.OpenRouterChatClient
import com.abhi.sitewatch.worker.MachineMetrics
import com.abhi.sitewatch.worker.PlantStatusDetector
import com.abhi.sitewatch.worker.ReportGenerator
import com.abhi.sitewatch.worker.RunningHoursCalculator
import com.abhi.sitewatch.worker.ScheduleManager
import com.abhi.sitewatch.worker.SitePatternAnalyzer
import org.json.JSONArray
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * Everything the assistant can do in this app, expressed as OpenAI-format
 * tool schemas plus the code that actually runs each one. This is the entire
 * "whole control through chat" surface: site management, schedule, and
 * on-demand reports all go through here rather than separate settings
 * screens.
 */
object ChatTools {

    private val BASE_SYSTEM_PROMPT = """
        You are the in-app assistant for Site Watch, an Android app that
        watches WhatsApp groups for a crusher operations business (one
        group per site) and reports on TPH, issues, and pending items.

        You control the app entirely through the tools below — there is no
        separate settings screen for sites, schedule, or reports, so use
        tools rather than just describing what the user should do.

        Guidelines:
        - Site names: `list_sites` returns both the raw WhatsApp group name
          (`group_name`, exact match, needed for other tool calls) and a
          cleaned `display_name` you can rename via `upsert_site`. When a
          user refers to a site by a rough or partial name, match it against
          the list rather than asking them to spell it exactly.
        - New groups show up untracked by default (privacy: nothing is
          stored until the user opts a group in). If the user says
          something like "start tracking Site B" or "add the Site C
          group", call `upsert_site` with tracked=true.
        - ALWAYS call `list_sites` before telling the user a site doesn't
          exist or that nothing is tracked — never assert either from memory
          or assumption. Trust the tool result: if `list_sites` returns
          sites, they exist. Site names are stored clean (no "(N messages)"
          suffixes), so match the user's wording against `display_name` or
          `group_name` generously rather than requiring an exact string.
        - "Stop tracking" / "remove" a site: ask the user once whether they
          also want its stored messages deleted (`delete_site`) or just
          paused (`upsert_site` tracked=false) — these are different and
          one is irreversible for that site's history.
        - For "generate a report" / "what's happening at Site A" style
          requests, prefer `generate_report`. Only pass send_to_telegram=
          true if the user actually asked for it to be sent/pushed; default
          to just showing it in chat.
        - For quick, casual questions about one site ("what's new at Site
          A today") without wanting a full structured report, you can use
          `get_recent_messages` and summarize yourself instead of calling
          `generate_report`.
        - Reports are trend-aware: each new report is generated with the
          previous report as context, so summaries already note changes
          (TPH up/down, issues recurring, pending items resolved) rather
          than being isolated snapshots. Use `get_site_history` when the
          user asks about trends over a longer stretch than the last report
          alone — e.g. "how has Site A's TPH been this week".
        - `get_alerts` surfaces anything computed as noteworthy right now
          (TPH dropped significantly since the last report, a tracked site
          gone quiet, an active breakdown, or prolonged idle time) without
          generating a fresh report — good for "anything I should worry
          about?" style questions.
        - `get_current_status` / `get_running_hours` answer "is Site A
          running right now?" / "how many hours did Site A run today?"
          style questions directly from extracted status history — you
          don't need to call generate_report for these. Be upfront that
          this is only as accurate as what people post in the group, not
          live telemetry — if status_events history is sparse for a site,
          say so rather than presenting a stale reading as current fact.
        - Nearly everything about how this app behaves is tunable through
          you: alert thresholds (`set_alert_settings`), the fast-alert
          keyword list (`set_fast_alert_settings`), which model runs chat
          and extraction (`set_model`), and which extra fields get pulled
          out of every report (`add_report_field`/`remove_report_field`,
          e.g. "fuel_factor"). Use these when the user asks to change how
          the app behaves rather than telling them to go find a setting.
        - Formatting: the chat renders Markdown, so USE it to make replies
          clean and scannable. Use **bold** for site names and labels,
          numbered lists (1. 2. 3.) when listing multiple sites, "- " bullets
          for sub-points, and status emoji as visual cues: 🟢 running,
          🟡 idle, 🔴 breakdown, ⚪ stopped, ❔ unknown. Do NOT use Markdown
          tables (| like | this |) — those don't render well on a narrow
          phone screen; use a numbered list instead, or `show_custom_view`
          (a real HTML table) for a genuine side-by-side comparison across
          many sites.
        - `show_custom_view` renders a real on-screen visual (HTML table,
          summary cards, bar-style comparisons). Reach for it only when a
          true grid/visual genuinely beats a numbered list — e.g. "compare
          TPH across all my sites side by side". For a normal status list, a
          numbered Markdown list in the chat is better.
        - When you call `generate_report`, present the returned report text
          to the user as-is — it's already formatted with numbers and emoji.
          Don't rewrite, re-summarize, or restructure it.
        - Language: messages from the groups are frequently in Hindi,
          Hinglish (Hindi written in English letters), or Marathi, mixed
          with English — e.g. "chalu" = running/started, "band"/"bandh" =
          stopped, "kharaab" = broken down, "chaalu hai" = it's running,
          "band pada hai" = it's shut down, "TPH kam hai" = TPH is low. Read
          for meaning, not just English keywords, and answer in English.
        - Recency: `get_recent_messages` and `get_all_sites_status` include
          a [timestamp] on each message and how long ago it was. Always use
          those to judge what's actually current — the newest message wins.
          Say how fresh the information is ("as of 2h ago") rather than
          implying it's live.
        - For "status of all sites" / "list all plant status" requests, call
          `get_all_sites_status` ONCE — it returns EVERY enabled site with a
          `status` already determined from that site's own messages, plus
          `status_as_of` (the timestamp of the message that determined it)
          and `status_from_message`. Don't loop `get_current_status` per site.
          Report it as a numbered list, one line per site, in this exact
          shape, with the status emoji and the time:
            1. 🟢 **SKY Jamnagar** — RUNNING as per last update 13:00
            2. 🔴 **GRIL Mudgal** — BREAKDOWN as per last update 09:15
          Never omit a site. If a site's status is "no status stated in
          recent messages", say so plainly for that site (⚪ no status
          update, last message <time>) instead of dropping it or inventing
          one.
        - Never claim a site has no data without checking. If `status` is
          absent but `last_message` exists, read that message (it may be
          Hindi/Hinglish) and give a best-effort read, clearly marked as
          inferred from the latest message rather than a confirmed status.
        - Be concise but well-structured. This is a phone chat, not a
          document — but a tidy numbered list beats a wall of text.
        - You have persistent memory across chat sessions via
          `remember_fact`: use it whenever you notice something durable
          worth carrying into future conversations — a stated preference
          ("always report TPH in tons, not a range"), a recurring
          operational detail ("Site A runs two shifts, 6am-2pm and
          2pm-10pm"), a correction to something you got wrong, or context
          that saves the user repeating themselves next time. Don't
          remember one-off trivia or routine query answers — only things
          genuinely worth having on hand later. This is real persisted
          state, not model training — nothing here changes how you think,
          it just gets read back to you as context on every future call, so
          write facts as short, self-contained statements that make sense
          out of context. Use `forget_fact` when something becomes outdated
          or the user asks you to forget it, and `list_memories` if asked
          what you remember.
        - For reliability/performance questions ("how reliable is Site A",
          "what's our uptime", "how often does it break down"), use
          `get_machine_metrics` rather than estimating from raw messages —
          it's computed directly from status history: availability %,
          MTBF (mean time between breakdowns), MTTR (mean repair time),
          breakdown count, and performance/OEE-lite % if a rated capacity
          is set. Never compute or guess these numbers yourself.
        - For "what's normal for this site" / "what keeps going wrong"
          style questions, use `get_site_insights` — real computed
          statistics (TPH range, most frequent recurring issues) mined from
          that site's own report history, not a guess from skimming recent
          messages.
        - `set_machine_profile` / `get_machine_profile` hold structured
          facts about a site's actual equipment (model, rated TPH capacity,
          service dates). Set this when the user tells you these details —
          it's what lets you say "running 140 against your 200 TPH rated
          capacity" instead of only ever describing things in relative
          terms.
    """.trimIndent()

    /**
     * The base prompt plus whatever's currently in persistent memory
     * (remember_fact/forget_fact) — called fresh before every message so
     * memory saved seconds ago is already visible on the very next turn,
     * not just in future sessions.
     */
    fun systemPrompt(memories: List<String>): String {
        if (memories.isEmpty()) return BASE_SYSTEM_PROMPT
        val memoryBlock = memories.joinToString("\n") { "- $it" }
        return BASE_SYSTEM_PROMPT + "\n\nWhat you currently remember about this user and their operation:\n$memoryBlock"
    }

    fun toolSchemas(): JSONArray {
        fun tool(name: String, description: String, properties: JSONObject, required: List<String> = emptyList()): JSONObject {
            return JSONObject().apply {
                put("type", "function")
                put("function", JSONObject().apply {
                    put("name", name)
                    put("description", description)
                    put("parameters", JSONObject().apply {
                        put("type", "object")
                        put("properties", properties)
                        if (required.isNotEmpty()) put("required", JSONArray(required))
                    })
                })
            }
        }

        val tools = JSONArray()

        tools.put(tool(
            "list_sites",
            "List every WhatsApp group detected so far, with tracked status, display name, and message counts.",
            JSONObject()
        ))

        tools.put(tool(
            "upsert_site",
            "Create or update a site: rename its display name and/or change whether it's tracked (tracked=true starts storing/reporting its messages).",
            JSONObject().apply {
                put("group_name", JSONObject().apply {
                    put("type", "string"); put("description", "Exact raw WhatsApp group name, from list_sites")
                })
                put("display_name", JSONObject().apply {
                    put("type", "string"); put("description", "Optional new clean display name")
                })
                put("tracked", JSONObject().apply {
                    put("type", "boolean"); put("description", "Optional: whether to track this site")
                })
            },
            listOf("group_name")
        ))

        tools.put(tool(
            "delete_site",
            "Permanently forget a site: removes it from the list and deletes all its stored messages. Irreversible.",
            JSONObject().apply {
                put("group_name", JSONObject().apply {
                    put("type", "string"); put("description", "Exact raw WhatsApp group name, from list_sites")
                })
            },
            listOf("group_name")
        ))

        tools.put(tool(
            "get_recent_messages",
            "Get the most recent raw messages captured for one site, for answering ad-hoc questions without generating a full report.",
            JSONObject().apply {
                put("group_name", JSONObject().apply {
                    put("type", "string"); put("description", "Exact raw WhatsApp group name, from list_sites")
                })
                put("limit", JSONObject().apply {
                    put("type", "integer"); put("description", "Max messages to return, default 30")
                })
            },
            listOf("group_name")
        ))

        tools.put(tool(
            "generate_report",
            "Generate a structured TPH/issues/pending report from unreported messages for the given sites (or all tracked sites if omitted).",
            JSONObject().apply {
                put("group_names", JSONObject().apply {
                    put("type", "array")
                    put("items", JSONObject().apply { put("type", "string") })
                    put("description", "Exact raw WhatsApp group names to include; omit for all tracked sites")
                })
                put("send_to_telegram", JSONObject().apply {
                    put("type", "boolean"); put("description", "Push the report to Telegram; default false (chat display only)")
                })
            }
        ))

        tools.put(tool(
            "get_site_history",
            "Get past generated reports for one site (TPH, summary, issues, pending per report) to answer questions about trends over time.",
            JSONObject().apply {
                put("group_name", JSONObject().apply {
                    put("type", "string"); put("description", "Exact raw WhatsApp group name, from list_sites")
                })
                put("limit", JSONObject().apply {
                    put("type", "integer"); put("description", "Max past reports to return, default 10")
                })
            },
            listOf("group_name")
        ))

        tools.put(tool(
            "get_alerts",
            "Get currently-computed alerts across all tracked sites (significant TPH drops since the last report, sites that have gone quiet, active breakdowns, prolonged idle) without generating a new report.",
            JSONObject()
        ))

        tools.put(tool(
            "get_current_status",
            "Get the current plant status (RUNNING/IDLE/BREAKDOWN/STOPPED) for one site and how long it's held, based on status changes extracted from chat.",
            JSONObject().apply {
                put("group_name", JSONObject().apply {
                    put("type", "string"); put("description", "Exact raw WhatsApp group name, from list_sites")
                })
            },
            listOf("group_name")
        ))

        tools.put(tool(
            "get_all_sites_status",
            "One-shot status overview of ALL tracked sites in a single call: for each site, its latest extracted plant status (if any), how long ago its last message was, and a snippet of that last message. Use this for 'status of all sites' / 'list all plant status' requests instead of calling get_current_status many times.",
            JSONObject()
        ))

        tools.put(tool(
            "get_running_hours",
            "Get hours-by-status (running/idle/breakdown/stopped) for one site over a period, computed from extracted status changes. Accuracy depends entirely on status updates actually being posted in the group.",
            JSONObject().apply {
                put("group_name", JSONObject().apply {
                    put("type", "string"); put("description", "Exact raw WhatsApp group name, from list_sites")
                })
                put("period", JSONObject().apply {
                    put("type", "string")
                    put("enum", JSONArray(listOf("today", "7_days", "30_days", "all_time")))
                    put("description", "Time window, default today")
                })
            },
            listOf("group_name")
        ))

        tools.put(tool(
            "get_schedule",
            "Get the current automatic report interval and quiet hours.",
            JSONObject()
        ))

        tools.put(tool(
            "set_schedule",
            "Change the automatic report interval and/or quiet hours (during which auto-reports are skipped).",
            JSONObject().apply {
                put("interval_hours", JSONObject().apply {
                    put("type", "integer"); put("description", "Hours between automatic reports, 1-168")
                })
                put("quiet_hours_start", JSONObject().apply {
                    put("type", "integer"); put("description", "0-23, local time hour auto-reports stop")
                })
                put("quiet_hours_end", JSONObject().apply {
                    put("type", "integer"); put("description", "0-23, local time hour auto-reports resume. Equal to start disables quiet hours.")
                })
            }
        ))

        tools.put(tool(
            "get_telegram_config",
            "Check whether Telegram delivery is configured (returns masked values, not the real token).",
            JSONObject()
        ))

        tools.put(tool(
            "set_telegram_config",
            "Update the Telegram bot token and/or chat ID used for report delivery.",
            JSONObject().apply {
                put("bot_token", JSONObject().apply { put("type", "string") })
                put("chat_id", JSONObject().apply { put("type", "string") })
            }
        ))

        tools.put(tool(
            "get_alert_settings",
            "Get current alert thresholds: TPH drop %, quiet-site hours, idle-alert hour window.",
            JSONObject()
        ))

        tools.put(tool(
            "set_alert_settings",
            "Change alert thresholds. Omit any field to leave it unchanged.",
            JSONObject().apply {
                put("tph_drop_percent", JSONObject().apply {
                    put("type", "number"); put("description", "Alert when TPH drops at least this % vs previous report, default 20")
                })
                put("quiet_site_hours", JSONObject().apply {
                    put("type", "integer"); put("description", "Alert if a tracked site has posted nothing for this many hours, default 48")
                })
                put("idle_alert_min_hours", JSONObject().apply {
                    put("type", "integer"); put("description", "Start flagging idle status after this many hours, default 4")
                })
                put("idle_alert_max_hours", JSONObject().apply {
                    put("type", "integer"); put("description", "Stop flagging idle status after this many hours (avoids repeating forever), default 12")
                })
            }
        ))

        tools.put(tool(
            "get_fast_alert_settings",
            "Get the keyword list and debounce window used for the instant (pre-report) breakdown ping.",
            JSONObject()
        ))

        tools.put(tool(
            "set_fast_alert_settings",
            "Change the keyword list and/or debounce window for the instant breakdown ping. Keywords are substring-matched, case-insensitive.",
            JSONObject().apply {
                put("keywords_csv", JSONObject().apply {
                    put("type", "string"); put("description", "Comma-separated keywords/phrases, replaces the current list entirely")
                })
                put("debounce_minutes", JSONObject().apply {
                    put("type", "integer"); put("description", "Minimum minutes between fast alerts for the same site, default 30")
                })
            }
        ))

        tools.put(tool(
            "get_model",
            "Get which OpenRouter model is currently used for chat and report extraction.",
            JSONObject()
        ))

        tools.put(tool(
            "set_model",
            "Switch the OpenRouter model used for chat and report extraction. Whatever model is chosen must support tool calling or chat control breaks — the 'free' and 'auto' routers guarantee that.",
            JSONObject().apply {
                put("model", JSONObject().apply {
                    put("type", "string")
                    put("description", "An OpenRouter model ID, e.g. 'anthropic/claude-sonnet-4.5' or 'google/gemini-2.5-flash'. Shortcuts: 'free' = openrouter/free (auto-picks a capable free model, the default), 'auto' = openrouter/auto (auto-picks the best model regardless of price).")
                })
            },
            listOf("model")
        ))

        tools.put(tool(
            "get_report_fields",
            "Get the list of extra fields (beyond the built-in TPH/issues/pending/status) currently being extracted per report.",
            JSONObject()
        ))

        tools.put(tool(
            "add_report_field",
            "Start extracting an additional named field per site in every future report (e.g. \"fuel_factor\", \"diesel_usage\"). Existing past reports won't have it retroactively.",
            JSONObject().apply {
                put("field_name", JSONObject().apply {
                    put("type", "string"); put("description", "Short snake_case field name")
                })
            },
            listOf("field_name")
        ))

        tools.put(tool(
            "remove_report_field",
            "Stop extracting a previously-added extra report field.",
            JSONObject().apply {
                put("field_name", JSONObject().apply { put("type", "string") })
            },
            listOf("field_name")
        ))

        tools.put(tool(
            "show_custom_view",
            "Display a custom visual screen in the app right now — a table, chart-like bars, a form, a summary card, anything HTML/CSS can express. Use this when a plain chat answer isn't the best way to show something (e.g. a comparison table across sites, a bar-style TPH trend). Provide a self-contained HTML body (no external resources — they're blocked); basic styling for body/table/th/td/button/.card is already provided. Buttons can call Android.sendToChat('some text') in an onclick to hand text back to this chat as the next message.",
            JSONObject().apply {
                put("title", JSONObject().apply { put("type", "string") })
                put("html_body", JSONObject().apply {
                    put("type", "string")
                    put("description", "HTML for the <body> only, self-contained, no <script src> or external <img>")
                })
            },
            listOf("title", "html_body")
        ))

        tools.put(tool(
            "remember_fact",
            "Save a short, durable fact to remember across all future chat sessions — a stated preference, a recurring operational detail, or a correction. Not for one-off trivia or routine query answers.",
            JSONObject().apply {
                put("fact", JSONObject().apply {
                    put("type", "string")
                    put("description", "A short, self-contained statement that makes sense read on its own later, e.g. 'Site A runs two shifts: 6am-2pm and 2pm-10pm'")
                })
            },
            listOf("fact")
        ))

        tools.put(tool(
            "forget_fact",
            "Remove previously remembered fact(s) — e.g. because one is outdated or the user asked you to forget it.",
            JSONObject().apply {
                put("search_text", JSONObject().apply {
                    put("type", "string"); put("description", "Text to match against remembered facts; all matching facts are deleted")
                })
            },
            listOf("search_text")
        ))

        tools.put(tool(
            "list_memories",
            "List everything currently remembered across chat sessions — for when the user asks what you remember about them or their operation.",
            JSONObject()
        ))

        tools.put(tool(
            "set_machine_profile",
            "Set or update structured details about the machine/crusher at a site — type, model, rated capacity, install/service dates, notes. Omit any field to leave it unchanged.",
            JSONObject().apply {
                put("group_name", JSONObject().apply { put("type", "string"); put("description", "Exact raw WhatsApp group name, from list_sites") })
                put("machine_type", JSONObject().apply { put("type", "string"); put("description", "e.g. 'Jaw Crusher', 'Cone Crusher'") })
                put("make_model", JSONObject().apply { put("type", "string"); put("description", "e.g. 'Metso C106'") })
                put("rated_capacity_tph", JSONObject().apply { put("type", "number"); put("description", "Manufacturer-rated capacity in TPH, for comparing actual output against spec") })
                put("install_date", JSONObject().apply { put("type", "string") })
                put("last_service_date", JSONObject().apply { put("type", "string") })
                put("notes", JSONObject().apply { put("type", "string") })
            },
            listOf("group_name")
        ))

        tools.put(tool(
            "get_machine_profile",
            "Get structured machine details previously set for a site (model, rated capacity, service history, notes).",
            JSONObject().apply {
                put("group_name", JSONObject().apply { put("type", "string"); put("description", "Exact raw WhatsApp group name, from list_sites") })
            },
            listOf("group_name")
        ))

        tools.put(tool(
            "get_machine_metrics",
            "Get calculated reliability/performance metrics for a site over a period: availability %, MTBF, MTTR, breakdown count, and performance/OEE-lite % if a rated capacity is set. Computed directly from status history, not estimated.",
            JSONObject().apply {
                put("group_name", JSONObject().apply { put("type", "string"); put("description", "Exact raw WhatsApp group name, from list_sites") })
                put("period", JSONObject().apply {
                    put("type", "string")
                    put("enum", JSONArray(listOf("today", "7_days", "30_days", "all_time")))
                    put("description", "Time window, default 30_days")
                })
            },
            listOf("group_name")
        ))

        tools.put(tool(
            "get_site_insights",
            "Get computed statistical patterns from a site's own report history: TPH range (min/median/max) and most frequently recurring issues, over its recent reports. Real computed statistics, not a guess from skimming raw messages.",
            JSONObject().apply {
                put("group_name", JSONObject().apply { put("type", "string"); put("description", "Exact raw WhatsApp group name, from list_sites") })
                put("limit", JSONObject().apply { put("type", "integer"); put("description", "Max recent reports to analyze, default 30") })
            },
            listOf("group_name")
        ))

        return tools
    }

    fun executor(context: Context): OpenRouterChatClient.ToolExecutor = OpenRouterChatClient.ToolExecutor { name, input ->
        val db = AppDatabase.getInstance(context)
        val siteDao = db.siteDao()
        val settings = SettingsStore(context)

        when (name) {
            "list_sites" -> {
                val sites = siteDao.getAll()
                JSONArray(sites.map { it.toJson() }).toString()
            }

            "upsert_site" -> {
                val groupName = input.getString("group_name")
                val existing = siteDao.getByGroupName(groupName)
                if (existing == null) {
                    siteDao.insertIfNew(
                        SiteEntity(
                            groupName = groupName,
                            displayName = input.optString("display_name", groupName),
                            tracked = input.optBoolean("tracked", false)
                        )
                    )
                } else {
                    if (input.has("display_name")) {
                        siteDao.updateDisplayName(groupName, input.getString("display_name"))
                    }
                    if (input.has("tracked")) {
                        siteDao.updateTracked(groupName, input.getBoolean("tracked"))
                    }
                }
                "OK: ${siteDao.getByGroupName(groupName)?.toJson()}"
            }

            "delete_site" -> {
                val groupName = input.getString("group_name")
                db.messageDao().deleteAllForGroup(groupName)
                db.reportDao().deleteAllForGroup(groupName)
                db.statusEventDao().deleteAllForGroup(groupName)
                db.machineProfileDao().deleteForSite(groupName)
                siteDao.delete(groupName)
                "Deleted site '$groupName' and its stored messages, reports, and status history."
            }

            "get_site_history" -> {
                val groupName = input.getString("group_name")
                val limit = if (input.has("limit")) input.getInt("limit") else 10
                val reports = db.reportDao().recentForSite(groupName, limit)
                if (reports.isEmpty()) {
                    "No report history for '$groupName' yet."
                } else {
                    JSONArray(reports.map { r ->
                        JSONObject().apply {
                            put("timestamp_ms", r.timestamp)
                            put("tph", r.tphRaw)
                            put("tph_numeric", r.tphNumeric ?: JSONObject.NULL)
                            put("summary", r.summary)
                            put("issues", JSONArray(r.issuesJson))
                            put("pending", JSONArray(r.pendingJson))
                        }
                    }).toString()
                }
            }

            "get_alerts" -> {
                val alerts = ReportGenerator.currentAlerts(context)
                if (alerts.isEmpty()) "No alerts right now." else alerts.joinToString("\n")
            }

            "get_current_status" -> {
                val groupName = input.getString("group_name")
                val totals = ReportGenerator.currentStatus(context, groupName)
                if (totals.currentStatus == null) {
                    "No status updates recorded yet for '$groupName'."
                } else {
                    val ageHours = (System.currentTimeMillis() - (totals.currentStatusSince ?: 0L)) / 3_600_000.0
                    JSONObject().apply {
                        put("status", totals.currentStatus)
                        put("since_hours_ago", "%.1f".format(ageHours))
                    }.toString()
                }
            }

            "get_all_sites_status" -> {
                val tracked = siteDao.getTracked()
                if (tracked.isEmpty()) {
                    "No sites are enabled yet — the user should turn sites on in Manage Sites."
                } else {
                    val fmt = SimpleDateFormat("dd MMM HH:mm", Locale.getDefault())
                    JSONArray(tracked.map { site ->
                        // Scan the site's actual messages for the newest one that
                        // states a status, so a site reports a real status even if
                        // no report has ever been generated for it.
                        val recent = db.messageDao().recentForGroup(site.groupName, 40)
                        val hit = PlantStatusDetector.detectLatest(recent)
                        val lastMsg = recent.firstOrNull()
                        JSONObject().apply {
                            put("site", site.displayName)
                            if (hit != null) {
                                put("status", hit.status)
                                put("status_as_of", fmt.format(Date(hit.timestamp)))
                                put("status_from_message", "${hit.sender}: ${hit.text.take(200)}")
                            } else {
                                put("status", "no status stated in recent messages")
                            }
                            db.statusEventDao().latestForSite(site.groupName)?.let {
                                put("last_extracted_status", it.status)
                                put("last_extracted_at", fmt.format(Date(it.timestamp)))
                            }
                            if (lastMsg != null) {
                                put("last_message_at", fmt.format(Date(lastMsg.timestamp)))
                                put("last_message", "${lastMsg.sender}: ${lastMsg.text.take(200)}")
                            } else {
                                put("last_message", "no messages captured yet")
                            }
                        }
                    }).toString()
                }
            }

            "get_running_hours" -> {
                val groupName = input.getString("group_name")
                val period = input.optString("period", "today")
                val since = when (period) {
                    "7_days" -> System.currentTimeMillis() - 7L * 24 * 3_600_000
                    "30_days" -> System.currentTimeMillis() - 30L * 24 * 3_600_000
                    "all_time" -> 0L
                    else -> RunningHoursCalculator.startOfToday()
                }
                val totals = ReportGenerator.runningHours(context, groupName, since)
                if (totals.hoursByStatus.isEmpty()) {
                    "No status history for '$groupName' in that period."
                } else {
                    JSONObject().apply {
                        totals.hoursByStatus.forEach { (status, hours) -> put(status, "%.1f".format(hours)) }
                    }.toString()
                }
            }

            "get_recent_messages" -> {
                val groupName = input.getString("group_name")
                val limit = if (input.has("limit")) input.getInt("limit") else 30
                val messages = ReportGenerator.recentRawMessages(context, groupName, limit)
                if (messages.isEmpty()) {
                    "No stored messages for '$groupName'. It may not be tracked yet — check list_sites."
                } else {
                    // Oldest-first with a [timestamp] on each line so the model can
                    // judge recency (which message is the latest) and read the
                    // Hindi/Hinglish/Marathi content in chronological context.
                    val fmt = SimpleDateFormat("dd MMM HH:mm", Locale.getDefault())
                    messages.reversed().joinToString("\n") {
                        "[${fmt.format(Date(it.timestamp))}] ${it.sender}: ${it.text}"
                    }
                }
            }

            "generate_report" -> {
                val groupNames = input.optJSONArray("group_names")?.let { arr ->
                    (0 until arr.length()).map { arr.getString(it) }
                }
                val sendToTelegram = input.optBoolean("send_to_telegram", false)
                val result = ReportGenerator.generate(
                    context = context,
                    groupNames = groupNames,
                    sendToTelegram = sendToTelegram,
                    markReported = true
                )
                buildString {
                    append(result.formattedReport)
                    if (sendToTelegram) {
                        append(if (result.sentToTelegram) "\n\n[Sent to Telegram]" else "\n\n[NOT sent — Telegram isn't configured]")
                    }
                }
            }

            "get_schedule" -> {
                JSONObject().apply {
                    put("interval_hours", settings.reportIntervalHours)
                    put("quiet_hours_enabled", settings.quietHoursEnabled)
                    put("quiet_hours_start", settings.quietHoursStart)
                    put("quiet_hours_end", settings.quietHoursEnd)
                }.toString()
            }

            "set_schedule" -> {
                if (input.has("interval_hours")) {
                    ScheduleManager.schedule(context, input.getInt("interval_hours"))
                }
                if (input.has("quiet_hours_start")) settings.quietHoursStart = input.getInt("quiet_hours_start")
                if (input.has("quiet_hours_end")) settings.quietHoursEnd = input.getInt("quiet_hours_end")
                "OK: interval=${settings.reportIntervalHours}h, quiet=${settings.quietHoursStart}-${settings.quietHoursEnd}"
            }

            "get_telegram_config" -> {
                JSONObject().apply {
                    put("configured", settings.isTelegramConfigured())
                    put("chat_id", settings.telegramChatId.ifBlank { "(not set)" })
                    put("bot_token_set", settings.telegramBotToken.isNotBlank())
                }.toString()
            }

            "set_telegram_config" -> {
                if (input.has("bot_token")) settings.telegramBotToken = input.getString("bot_token")
                if (input.has("chat_id")) settings.telegramChatId = input.getString("chat_id")
                "OK: telegram configured=${settings.isTelegramConfigured()}"
            }

            "get_alert_settings" -> {
                JSONObject().apply {
                    put("tph_drop_percent", settings.tphDropAlertPercent)
                    put("quiet_site_hours", settings.quietSiteThresholdHours)
                    put("idle_alert_min_hours", settings.idleAlertMinHours)
                    put("idle_alert_max_hours", settings.idleAlertMaxHours)
                }.toString()
            }

            "set_alert_settings" -> {
                if (input.has("tph_drop_percent")) settings.tphDropAlertPercent = input.getDouble("tph_drop_percent")
                if (input.has("quiet_site_hours")) settings.quietSiteThresholdHours = input.getInt("quiet_site_hours")
                if (input.has("idle_alert_min_hours")) settings.idleAlertMinHours = input.getInt("idle_alert_min_hours")
                if (input.has("idle_alert_max_hours")) settings.idleAlertMaxHours = input.getInt("idle_alert_max_hours")
                "OK: tph_drop=${settings.tphDropAlertPercent}%, quiet=${settings.quietSiteThresholdHours}h, " +
                    "idle=${settings.idleAlertMinHours}-${settings.idleAlertMaxHours}h"
            }

            "get_fast_alert_settings" -> {
                JSONObject().apply {
                    put("keywords_csv", settings.fastAlertKeywords)
                    put("debounce_minutes", settings.fastAlertDebounceMinutes)
                }.toString()
            }

            "set_fast_alert_settings" -> {
                if (input.has("keywords_csv")) settings.fastAlertKeywords = input.getString("keywords_csv")
                if (input.has("debounce_minutes")) settings.fastAlertDebounceMinutes = input.getInt("debounce_minutes")
                "OK: ${settings.fastAlertKeywordList().size} keywords, debounce=${settings.fastAlertDebounceMinutes}min"
            }

            "get_model" -> {
                "Current model: ${settings.modelId}"
            }

            "set_model" -> {
                val choice = input.getString("model").trim()
                settings.modelId = when (choice.lowercase()) {
                    "free", "default" -> "openrouter/free"
                    "auto" -> "openrouter/auto"
                    else -> choice
                }
                "OK: model set to ${settings.modelId}"
            }

            "get_report_fields" -> {
                val fields = settings.additionalReportFieldList()
                if (fields.isEmpty()) "No extra fields configured (just the built-in TPH/issues/pending/status)."
                else fields.joinToString(", ")
            }

            "add_report_field" -> {
                val fieldName = input.getString("field_name").trim()
                val current = settings.additionalReportFieldList().toMutableList()
                if (fieldName.isNotEmpty() && fieldName !in current) current.add(fieldName)
                settings.additionalReportFields = current.joinToString(",")
                "OK: extra fields now [${settings.additionalReportFields}]"
            }

            "remove_report_field" -> {
                val fieldName = input.getString("field_name").trim()
                val current = settings.additionalReportFieldList().filter { it != fieldName }
                settings.additionalReportFields = current.joinToString(",")
                "OK: extra fields now [${settings.additionalReportFields}]"
            }

            "show_custom_view" -> {
                val title = input.getString("title")
                val htmlBody = input.getString("html_body")
                val viewIntent = Intent(context, DynamicViewActivity::class.java).apply {
                    putExtra(DynamicViewActivity.EXTRA_TITLE, title)
                    putExtra(DynamicViewActivity.EXTRA_HTML, htmlBody)
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                }
                context.startActivity(viewIntent)
                "Opened a custom view titled '$title' for the user."
            }

            "remember_fact" -> {
                val fact = input.getString("fact").trim()
                if (fact.isNotEmpty()) {
                    db.memoryDao().insert(MemoryEntity(content = fact))
                    db.memoryDao().trimToLast(200)
                }
                "OK: remembered."
            }

            "forget_fact" -> {
                val searchText = input.getString("search_text").trim()
                db.memoryDao().deleteMatching(searchText)
                "OK: removed matching memories."
            }

            "list_memories" -> {
                val memories = db.memoryDao().getAll()
                if (memories.isEmpty()) "Nothing remembered yet."
                else memories.joinToString("\n") { "- ${it.content}" }
            }

            "set_machine_profile" -> {
                val groupName = input.getString("group_name")
                val existing = db.machineProfileDao().getForSite(groupName)
                db.machineProfileDao().upsert(
                    MachineProfileEntity(
                        groupName = groupName,
                        machineType = if (input.has("machine_type")) input.getString("machine_type") else existing?.machineType,
                        makeModel = if (input.has("make_model")) input.getString("make_model") else existing?.makeModel,
                        ratedCapacityTph = if (input.has("rated_capacity_tph")) input.getDouble("rated_capacity_tph") else existing?.ratedCapacityTph,
                        installDateText = if (input.has("install_date")) input.getString("install_date") else existing?.installDateText,
                        lastServiceDateText = if (input.has("last_service_date")) input.getString("last_service_date") else existing?.lastServiceDateText,
                        notes = if (input.has("notes")) input.getString("notes") else existing?.notes
                    )
                )
                "OK: machine profile updated for '$groupName'"
            }

            "get_machine_profile" -> {
                val groupName = input.getString("group_name")
                val profile = db.machineProfileDao().getForSite(groupName)
                if (profile == null) {
                    "No machine profile set yet for '$groupName'."
                } else {
                    JSONObject().apply {
                        put("machine_type", profile.machineType ?: JSONObject.NULL)
                        put("make_model", profile.makeModel ?: JSONObject.NULL)
                        put("rated_capacity_tph", profile.ratedCapacityTph ?: JSONObject.NULL)
                        put("install_date", profile.installDateText ?: JSONObject.NULL)
                        put("last_service_date", profile.lastServiceDateText ?: JSONObject.NULL)
                        put("notes", profile.notes ?: JSONObject.NULL)
                    }.toString()
                }
            }

            "get_machine_metrics" -> {
                val groupName = input.getString("group_name")
                val period = input.optString("period", "30_days")
                val since = when (period) {
                    "today" -> RunningHoursCalculator.startOfToday()
                    "7_days" -> System.currentTimeMillis() - 7L * 24 * 3_600_000
                    "all_time" -> 0L
                    else -> System.currentTimeMillis() - 30L * 24 * 3_600_000
                }
                val now = System.currentTimeMillis()
                val events = db.statusEventDao().recentForSite(groupName, 2000).sortedBy { it.timestamp }
                val totals = RunningHoursCalculator.compute(events, since, now)
                val effectiveSince = if (since == 0L) events.firstOrNull()?.timestamp ?: now else since
                val periodHours = (now - effectiveSince) / 3_600_000.0
                val breakdownCount = events.count { it.timestamp in effectiveSince..now && it.status == "BREAKDOWN" }

                val reports = db.reportDao().recentForSite(groupName, 500).filter { it.timestamp >= effectiveSince }
                val avgTph = reports.mapNotNull { it.tphNumeric }.let { if (it.isEmpty()) null else it.average() }

                val profile = db.machineProfileDao().getForSite(groupName)
                val metrics = MachineMetrics.compute(
                    hoursByStatus = totals.hoursByStatus,
                    periodHours = periodHours,
                    breakdownEventCount = breakdownCount,
                    avgTph = avgTph,
                    ratedCapacityTph = profile?.ratedCapacityTph
                )

                JSONObject().apply {
                    put("period_hours", "%.1f".format(periodHours))
                    put("availability_percent", metrics.availabilityPercent?.let { "%.1f".format(it) } ?: JSONObject.NULL)
                    put("mtbf_hours", metrics.mtbfHours?.let { "%.1f".format(it) } ?: JSONObject.NULL)
                    put("mttr_hours", metrics.mttrHours?.let { "%.1f".format(it) } ?: JSONObject.NULL)
                    put("breakdown_count", metrics.breakdownCount)
                    put("avg_tph", avgTph?.let { "%.1f".format(it) } ?: JSONObject.NULL)
                    put("rated_capacity_tph", profile?.ratedCapacityTph ?: JSONObject.NULL)
                    put("performance_percent", metrics.performancePercent?.let { "%.1f".format(it) } ?: JSONObject.NULL)
                    put("oee_lite_percent", metrics.oeeLitePercent?.let { "%.1f".format(it) } ?: JSONObject.NULL)
                }.toString()
            }

            "get_site_insights" -> {
                val groupName = input.getString("group_name")
                val limit = if (input.has("limit")) input.getInt("limit") else 30
                val reports = db.reportDao().recentForSite(groupName, limit)
                if (reports.isEmpty()) {
                    "No report history yet for '$groupName' to analyze."
                } else {
                    val insights = SitePatternAnalyzer.analyze(reports)
                    JSONObject().apply {
                        put("reports_analyzed", insights.reportCount)
                        put("tph_min", insights.tphMin ?: JSONObject.NULL)
                        put("tph_median", insights.tphMedian ?: JSONObject.NULL)
                        put("tph_max", insights.tphMax ?: JSONObject.NULL)
                        put("top_recurring_issues", JSONArray(insights.topIssues.map { "${it.first} (${it.second}x)" }))
                    }.toString()
                }
            }

            else -> "Unknown tool: $name"
        }
    }

    private fun SiteEntity.toJson(): JSONObject = JSONObject().apply {
        put("group_name", groupName)
        put("display_name", displayName)
        put("tracked", tracked)
        put("message_count", messageCount)
        put("last_seen_ms", lastSeen)
    }
}
