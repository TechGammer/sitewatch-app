package com.abhi.sitewatch.chat

import com.abhi.sitewatch.data.ChatDao
import com.abhi.sitewatch.data.ChatTurnEntity
import org.json.JSONObject

data class DisplayMessage(val role: String, val text: String)

/**
 * Loads/saves the raw API-format conversation (complete OpenAI-style
 * chat-completions message objects, including assistant tool_calls and
 * role:"tool" results) so chat context survives an app restart, and
 * separately tracks the human-readable subset for the RecyclerView.
 */
class ChatHistoryStore(private val chatDao: ChatDao) {

    companion object {
        // Cap what's sent to the API so cost/context doesn't grow
        // unbounded over months of use. The full history still lives in
        // Room and is shown in the UI — only the API-bound copy is capped.
        private const val MAX_API_TURNS = 40
    }

    suspend fun loadApiHistory(): MutableList<JSONObject> {
        val all = chatDao.getAll().mapNotNull { parseMessage(it.contentJson) }
        val trimmed = if (all.size <= MAX_API_TURNS) all else {
            // Cut to the most recent MAX_API_TURNS messages, then walk
            // forward to the first genuine user message — otherwise we'd
            // start with a role:"tool" result (or an assistant message whose
            // tool_calls answers are missing) and the API would reject the
            // orphaned message.
            val candidate = all.takeLast(MAX_API_TURNS)
            val safeStart = candidate.indexOfFirst { it.optString("role") == "user" }
            if (safeStart >= 0) candidate.subList(safeStart, candidate.size) else candidate
        }
        return trimmed.toMutableList()
    }

    /**
     * New rows store one complete chat-completions message object. Rows
     * written by the old Anthropic-backend build stored a content-block
     * *array* instead — those can't be replayed against OpenRouter, so
     * they're dropped from the API context (they still render in the UI,
     * which reads the separate displayText column).
     */
    private fun parseMessage(contentJson: String): JSONObject? {
        return try {
            if (contentJson.trimStart().startsWith("{")) JSONObject(contentJson) else null
        } catch (e: Exception) {
            null
        }
    }

    suspend fun loadDisplayMessages(): List<DisplayMessage> {
        return chatDao.getDisplayable().map { DisplayMessage(it.role, it.displayText) }
    }

    suspend fun persistTurn(message: JSONObject) {
        chatDao.insert(
            ChatTurnEntity(
                role = message.optString("role"),
                contentJson = message.toString(),
                displayText = extractDisplayText(message)
            )
        )
    }

    suspend fun clear() = chatDao.clear()

    /** Only user/assistant text is shown as bubbles; tool_calls-only and role:"tool" messages render nothing. */
    private fun extractDisplayText(message: JSONObject): String {
        val role = message.optString("role")
        if (role != "user" && role != "assistant") return ""
        if (message.isNull("content")) return ""
        return message.optString("content", "").trim()
    }
}
