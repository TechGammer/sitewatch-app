package com.abhi.sitewatch.chat

import com.abhi.sitewatch.data.ChatDao
import com.abhi.sitewatch.data.ChatTurnEntity
import org.json.JSONArray
import org.json.JSONObject

data class DisplayMessage(val role: String, val text: String)

/**
 * Loads/saves the raw API-format conversation (including tool_use/
 * tool_result blocks) so chat context survives an app restart, and
 * separately tracks the human-readable subset for the RecyclerView.
 */
class ChatHistoryStore(private val chatDao: ChatDao) {

    companion object {
        // Cap what's sent to the API so cost/context doesn't grow
        // unbounded over months of use. The full history still lives in
        // Room and is shown in the UI — only the API-bound copy is capped.
        private const val MAX_API_TURNS = 40
    }

    suspend fun loadApiHistory(): MutableList<JSONObject> {
        val all = chatDao.getAll()
        val trimmed = if (all.size <= MAX_API_TURNS) all else {
            // Cut to the most recent MAX_API_TURNS turns, then walk forward
            // to the first turn that's a genuine new user message (a "user"
            // role turn whose first block is "text", not a tool_result) —
            // otherwise we'd start mid tool-call and the API would reject
            // an orphaned tool_result with no matching tool_use.
            val candidate = all.takeLast(MAX_API_TURNS)
            val safeStart = candidate.indexOfFirst { turn ->
                turn.role == "user" && isPlainUserText(turn.contentJson)
            }
            if (safeStart >= 0) candidate.subList(safeStart, candidate.size) else candidate
        }

        return trimmed
            .map { turn ->
                JSONObject().apply {
                    put("role", turn.role)
                    put("content", JSONArray(turn.contentJson))
                }
            }
            .toMutableList()
    }

    private fun isPlainUserText(contentJson: String): Boolean {
        return try {
            val arr = JSONArray(contentJson)
            arr.length() > 0 && arr.getJSONObject(0).optString("type") == "text"
        } catch (e: Exception) {
            false
        }
    }

    suspend fun loadDisplayMessages(): List<DisplayMessage> {
        return chatDao.getDisplayable().map { DisplayMessage(it.role, it.displayText) }
    }

    suspend fun persistTurn(role: String, content: JSONArray) {
        val displayText = extractDisplayText(role, content)
        chatDao.insert(
            ChatTurnEntity(
                role = role,
                contentJson = content.toString(),
                displayText = displayText
            )
        )
    }

    suspend fun clear() = chatDao.clear()

    /** Only plain text blocks are shown as bubbles; tool_use/tool_result turns render nothing. */
    private fun extractDisplayText(role: String, content: JSONArray): String {
        val texts = mutableListOf<String>()
        for (i in 0 until content.length()) {
            val block = content.optJSONObject(i) ?: continue
            if (block.optString("type") == "text") {
                val t = block.optString("text", "")
                if (t.isNotBlank()) texts.add(t)
            }
        }
        return texts.joinToString("\n\n")
    }
}
