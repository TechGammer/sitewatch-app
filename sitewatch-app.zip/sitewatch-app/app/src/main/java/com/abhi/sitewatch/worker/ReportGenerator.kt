package com.abhi.sitewatch.worker

import android.content.Context
import com.abhi.sitewatch.SettingsStore
import com.abhi.sitewatch.data.AppDatabase
import com.abhi.sitewatch.data.ReportDao
import com.abhi.sitewatch.data.ReportEntity
import com.abhi.sitewatch.data.SiteEntity
import com.abhi.sitewatch.data.SiteMessage
import com.abhi.sitewatch.data.StatusEventDao
import com.abhi.sitewatch.data.StatusEventEntity
import com.abhi.sitewatch.network.OpenRouterExtractor
import com.abhi.sitewatch.network.TelegramSender
import org.json.JSONArray
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.TimeUnit

/**
 * One place that turns "unreported messages for these sites" into a
 * formatted, trend-aware, status-aware report and optionally pushes it to
 * Telegram. Used by ReportWorker (scheduled, always sends) and by the
 * `generate_report` chat tool (on-demand, sends only if the user asked).
 *
 * Every generated report is persisted per site (ReportDao), and every
 * plant status change extracted (RUNNING/IDLE/BREAKDOWN/STOPPED) is
 * persisted per site (StatusEventDao) — that history is what powers
 * trend-aware summaries, running-hours math, current status, and alerts.
 */
object ReportGenerator {

    data class Result(val formattedReport: String, val sentToTelegram: Boolean, val siteCount: Int)

    private val VALID_STATUSES = setOf("RUNNING", "IDLE", "BREAKDOWN", "STOPPED")

    // Raw messages older than this that have already been folded into a
    // report are pruned opportunistically (see generate() below) — keeps
    // site_messages bounded over months of use instead of growing forever.
    private val MESSAGE_RETENTION_MS = TimeUnit.DAYS.toMillis(60)

    /**
     * @param groupNames restrict to these tracked group names; null = all tracked sites
     * @param sendToTelegram if true, pushes the formatted report to the configured Telegram chat
     * @param markReported if true, marks the included messages as reported so they aren't
     *        included again in the next scheduled run (set false for casual chat queries)
     */
    suspend fun generate(
        context: Context,
        groupNames: List<String>? = null,
        sendToTelegram: Boolean,
        markReported: Boolean = true
    ): Result {
        val settings = SettingsStore(context)
        val db = AppDatabase.getInstance(context)
        val messageDao = db.messageDao()
        val siteDao = db.siteDao()
        val reportDao = db.reportDao()
        val statusEventDao = db.statusEventDao()

        val trackedSites = siteDao.getTracked()
        val trackedNames = trackedSites.map { it.groupName }.toSet()
        val targetNames = groupNames?.filter { it in trackedNames }?.toSet() ?: trackedNames

        val displayNameFor = trackedSites.associate { it.groupName to it.displayName }
        val nameToGroup = trackedSites.associate { it.displayName to it.groupName }

        val targetSites = trackedSites.filter { it.groupName in targetNames }
        val unreported = messageDao.getUnreported().filter { it.groupName in targetNames }

        // Each message line carries its own timestamp so the model can order
        // events, judge what's most recent, and fill time_hint from a real
        // clock time instead of guessing from list position.
        val msgFmt = SimpleDateFormat("dd MMM HH:mm", Locale.getDefault())
        val grouped: Map<String, List<String>> = unreported
            .groupBy { displayNameFor[it.groupName] ?: it.groupName }
            .mapValues { (_, msgs) ->
                msgs.map { "[${msgFmt.format(Date(it.timestamp))}] ${it.sender}: ${it.text}" }
            }

        // Every enabled site appears in the report, not just the ones with new
        // messages — a quiet site is itself information, and silently dropping
        // it made reports look like sites had vanished.
        val customKeywords = db.statusKeywordDao().getAll()
        val quietEntries = targetSites
            .filter { !grouped.containsKey(it.displayName) }
            .map { site ->
                val lastMsg = messageDao.recentForGroup(site.groupName, 1).firstOrNull()
                val detected = lastMsg?.let {
                    PlantStatusDetector.detectLatest(messageDao.recentForGroup(site.groupName, 40), site.groupName, customKeywords)
                }
                val detail = buildString {
                    if (detected != null) {
                        append("last known ${detected.status} as of ${msgFmt.format(Date(detected.timestamp))}")
                    } else if (lastMsg != null) {
                        append("last message ${msgFmt.format(Date(lastMsg.timestamp))}, no status stated")
                    } else {
                        append("no messages captured yet")
                    }
                }
                "${site.displayName} — no new updates ($detail)"
            }

        val alerts = computeAlerts(targetSites, reportDao, statusEventDao, settings)

        // Nothing new anywhere: still produce a proper report covering every
        // enabled site rather than a bare "no new messages" line, and skip the
        // API call entirely since there's nothing to extract.
        if (unreported.isEmpty()) {
            return Result(formatReport(null, alerts, quietEntries), false, 0)
        }

        // Pull the last report for each included site so the extraction can
        // reason about what changed, not just what's new.
        val previousContext = mutableMapOf<String, String>()
        for (displayName in grouped.keys) {
            val groupName = nameToGroup[displayName] ?: continue
            val prev = reportDao.latestForSite(groupName) ?: continue
            previousContext[displayName] = summarizeForPrompt(prev)
        }

        val rawJson = OpenRouterExtractor.extractStructuredReport(
            apiKey = settings.openRouterApiKey,
            model = settings.modelId,
            groupedMessages = grouped,
            previousContext = previousContext,
            extraFields = settings.additionalReportFieldList()
        )

        persistReports(reportDao, nameToGroup, rawJson)
        persistStatusEvents(statusEventDao, nameToGroup, rawJson, unreported)

        val formatted = formatReport(rawJson, alerts, quietEntries)

        var sent = false
        if (sendToTelegram && settings.isTelegramConfigured()) {
            TelegramSender.send(settings.telegramBotToken, settings.telegramChatId, formatted)
            sent = true
        }

        if (markReported) {
            messageDao.markReported(unreported.map { it.id })
            messageDao.pruneOldReported(System.currentTimeMillis() - MESSAGE_RETENTION_MS)
        }

        return Result(formatted, sent, grouped.size)
    }

    /** Alerts computed from existing history, without generating a new report — for the get_alerts chat tool. */
    suspend fun currentAlerts(context: Context): List<String> {
        val db = AppDatabase.getInstance(context)
        val trackedSites = db.siteDao().getTracked()
        return computeAlerts(trackedSites, db.reportDao(), db.statusEventDao(), SettingsStore(context))
    }

    /** Current status + how long it's been that way, for one site. Null status means never reported. */
    suspend fun currentStatus(context: Context, groupName: String): RunningHoursCalculator.Totals {
        val db = AppDatabase.getInstance(context)
        val events = db.statusEventDao().recentForSite(groupName, 200).sortedBy { it.timestamp }
        return RunningHoursCalculator.compute(events, events.firstOrNull()?.timestamp ?: 0L, System.currentTimeMillis())
    }

    /** Running-hours breakdown for one site over [sinceMs, now). */
    suspend fun runningHours(context: Context, groupName: String, sinceMs: Long): RunningHoursCalculator.Totals {
        val db = AppDatabase.getInstance(context)
        // Capped rather than unbounded — plenty for realistic status-update volume,
        // and still gives an accurate carry-in status for the requested window.
        val events = db.statusEventDao().recentForSite(groupName, 2000).sortedBy { it.timestamp }
        return RunningHoursCalculator.compute(events, sinceMs, System.currentTimeMillis())
    }

    private fun summarizeForPrompt(report: ReportEntity): String {
        val ago = formatAgo(System.currentTimeMillis() - report.timestamp)
        val pending = try {
            val arr = JSONArray(report.pendingJson)
            (0 until arr.length()).map { arr.getString(it) }
        } catch (e: Exception) { emptyList() }
        val pendingText = if (pending.isEmpty()) "none" else pending.joinToString("; ")
        return "$ago ago — TPH: ${report.tphRaw}, summary: ${report.summary}, open pending: $pendingText"
    }

    private suspend fun persistReports(reportDao: ReportDao, nameToGroup: Map<String, String>, rawJson: String) {
        try {
            val json = JSONObject(rawJson)
            val sites = json.getJSONArray("sites")
            for (i in 0 until sites.length()) {
                val s = sites.getJSONObject(i)
                val displayName = s.getString("site")
                val groupName = nameToGroup[displayName] ?: continue
                val tphRaw = s.optString("tph", "not mentioned")
                reportDao.insert(
                    ReportEntity(
                        groupName = groupName,
                        tphRaw = tphRaw,
                        tphNumeric = TphParser.parse(tphRaw),
                        summary = s.optString("summary", ""),
                        issuesJson = s.optJSONArray("issues")?.toString() ?: "[]",
                        pendingJson = s.optJSONArray("pending")?.toString() ?: "[]",
                        extraFieldsJson = s.optJSONObject("extra")?.toString() ?: "{}"
                    )
                )
            }
        } catch (e: Exception) {
            // If parsing failed here, formatReport() will also fail gracefully
            // and show the raw text — nothing further to persist.
        }
    }

    /**
     * Status events don't come with per-event timestamps from the model (it
     * only sees a batch of messages, not individual message times), so we
     * spread them proportionally across the actual timestamps of this
     * site's unreported messages — approximate, but preserves ordering,
     * which is what the running-hours math actually depends on.
     */
    private suspend fun persistStatusEvents(
        statusEventDao: StatusEventDao,
        nameToGroup: Map<String, String>,
        rawJson: String,
        unreported: List<SiteMessage>
    ) {
        try {
            val json = JSONObject(rawJson)
            val sites = json.getJSONArray("sites")
            for (i in 0 until sites.length()) {
                val s = sites.getJSONObject(i)
                val displayName = s.getString("site")
                val groupName = nameToGroup[displayName] ?: continue
                val events = s.optJSONArray("status_events") ?: continue
                if (events.length() == 0) continue

                val siteTimestamps = unreported.filter { it.groupName == groupName }.map { it.timestamp }.sorted()
                if (siteTimestamps.isEmpty()) continue
                val minTs = siteTimestamps.first()
                val maxTs = siteTimestamps.last()

                for (j in 0 until events.length()) {
                    val e = events.getJSONObject(j)
                    val status = e.optString("status", "").uppercase(Locale.ROOT)
                    if (status !in VALID_STATUSES) continue
                    val reason = if (e.isNull("reason")) null else e.optString("reason").takeIf { it.isNotBlank() }
                    val timeHint = if (e.isNull("time_hint")) "" else e.optString("time_hint")
                    val fraction = if (events.length() == 1) 1.0 else j.toDouble() / (events.length() - 1)
                    val ts = (minTs + (maxTs - minTs) * fraction).toLong()

                    statusEventDao.insert(
                        StatusEventEntity(
                            groupName = groupName,
                            timestamp = ts,
                            status = status,
                            reason = reason,
                            rawText = timeHint
                        )
                    )
                }
            }
        } catch (e: Exception) {
            // Best-effort — the rest of the report is unaffected.
        }
    }

    private suspend fun computeAlerts(
        sites: List<SiteEntity>,
        reportDao: ReportDao,
        statusEventDao: StatusEventDao,
        settings: SettingsStore
    ): List<String> {
        val alerts = mutableListOf<String>()
        val now = System.currentTimeMillis()

        for (site in sites) {
            val recentReports = reportDao.recentForSite(site.groupName, 2)
            if (recentReports.size >= 2) {
                val latest = recentReports[0]
                val prev = recentReports[1]
                val latestTph = latest.tphNumeric
                val prevTph = prev.tphNumeric
                if (latestTph != null && prevTph != null && prevTph > 0) {
                    val pctChange = (latestTph - prevTph) / prevTph * 100.0
                    if (pctChange <= -settings.tphDropAlertPercent) {
                        alerts.add(
                            "${site.displayName}: TPH down ${"%.0f".format(-pctChange)}% vs previous report (${prev.tphRaw} -> ${latest.tphRaw})"
                        )
                    }
                }
            }

            val hoursSinceLastSeen = TimeUnit.MILLISECONDS.toHours(now - site.lastSeen)
            if (hoursSinceLastSeen >= settings.quietSiteThresholdHours) {
                alerts.add("${site.displayName}: no messages seen in ${hoursSinceLastSeen}h — worth checking the group is still active")
            }

            val latestStatus = statusEventDao.latestForSite(site.groupName)
            if (latestStatus != null) {
                val statusAgeHours = TimeUnit.MILLISECONDS.toHours(now - latestStatus.timestamp)
                if (latestStatus.status == "BREAKDOWN") {
                    val reasonText = latestStatus.reason?.let { " ($it)" } ?: ""
                    alerts.add("${site.displayName}: BREAKDOWN reported$reasonText, ~${statusAgeHours}h ago")
                } else if (latestStatus.status == "IDLE" &&
                    statusAgeHours in settings.idleAlertMinHours.toLong()..settings.idleAlertMaxHours.toLong()
                ) {
                    val reasonText = latestStatus.reason?.let { " ($it)" } ?: ""
                    alerts.add("${site.displayName}: idle$reasonText for ~${statusAgeHours}h")
                }
            }
        }
        return alerts
    }

    private fun formatAgo(millis: Long): String {
        val hours = TimeUnit.MILLISECONDS.toHours(millis)
        return if (hours < 24) "${hours}h" else "${hours / 24}d"
    }

    private fun statusEmoji(status: String?): String = when (status?.uppercase(Locale.ROOT)) {
        "RUNNING" -> "🟢"
        "IDLE" -> "🟡"
        "BREAKDOWN" -> "🔴"
        "STOPPED" -> "⚪"
        else -> ""
    }

    /**
     * Numbered, emoji-labelled plain text — no Markdown asterisks. Reads
     * cleanly both in the chat bubble (the app renders Markdown, but this
     * needs none) and in Telegram (which would otherwise mis-handle stray
     * markup from raw message content). Matches the "clear numbered list
     * with symbols" the report is meant to be.
     */
    private fun formatReport(rawJson: String?, alerts: List<String>, quietEntries: List<String>): String {
        val timestamp = SimpleDateFormat("dd MMM, HH:mm", Locale.getDefault()).format(Date())
        val sb = StringBuilder("📋 Site Watch Report — $timestamp\n\n")

        if (alerts.isNotEmpty()) {
            sb.append("⚠️ Alerts\n")
            alerts.forEach { sb.append("• $it\n") }
            sb.append("\n")
        }

        // Single running counter across extracted and quiet sites so the
        // report reads as one continuous numbered list of every enabled site.
        var n = 0

        if (!rawJson.isNullOrBlank()) {
            try {
                val sites = JSONObject(rawJson).getJSONArray("sites")
                for (i in 0 until sites.length()) {
                    val s = sites.getJSONObject(i)
                    val firstStatus = s.optJSONArray("status_events")?.optJSONObject(0)?.optString("status")
                    val emoji = statusEmoji(firstStatus)
                    val emojiPrefix = if (emoji.isNotEmpty()) "$emoji " else ""
                    n++
                    sb.append("$n. $emojiPrefix${s.getString("site")}\n")
                    sb.append("   📊 TPH: ${s.optString("tph", "not mentioned")}\n")
                    sb.append("   📝 ${s.optString("summary", "-")}\n")

                    val issues = s.optJSONArray("issues")
                    if (issues != null && issues.length() > 0) {
                        sb.append("   ⚠️ Issues:\n")
                        for (j in 0 until issues.length()) sb.append("      - ${issues.getString(j)}\n")
                    }
                    val pending = s.optJSONArray("pending")
                    if (pending != null && pending.length() > 0) {
                        sb.append("   ⏳ Pending:\n")
                        for (j in 0 until pending.length()) sb.append("      - ${pending.getString(j)}\n")
                    }
                    val extra = s.optJSONObject("extra")
                    if (extra != null && extra.length() > 0) {
                        extra.keys().forEach { key -> sb.append("   ${key}: ${extra.optString(key)}\n") }
                    }
                    sb.append("\n")
                }
            } catch (e: Exception) {
                return "📋 Site Watch Report — $timestamp (raw, structured parse failed)\n\n$rawJson"
            }
        }

        for (entry in quietEntries) {
            n++
            sb.append("$n. ⚪ $entry\n\n")
        }

        if (n == 0) {
            sb.append("No sites are enabled yet — turn sites on in Manage Sites.\n")
        }
        return sb.toString()
    }

    /** Recent raw messages for a single group, newest last — for chat's get_recent_messages tool. */
    suspend fun recentRawMessages(context: Context, groupName: String, limit: Int): List<SiteMessage> {
        val db = AppDatabase.getInstance(context)
        return db.messageDao().recentForGroup(groupName, limit)
    }
}
