package com.abhi.sitewatch.data

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.Query

@Dao
interface ChatDao {

    @Insert
    suspend fun insert(turn: ChatTurnEntity): Long

    @Query("SELECT * FROM chat_turns ORDER BY id ASC")
    suspend fun getAll(): List<ChatTurnEntity>

    @Query("SELECT * FROM chat_turns WHERE displayText != '' ORDER BY id ASC")
    suspend fun getDisplayable(): List<ChatTurnEntity>

    @Query("DELETE FROM chat_turns")
    suspend fun clear()
}
