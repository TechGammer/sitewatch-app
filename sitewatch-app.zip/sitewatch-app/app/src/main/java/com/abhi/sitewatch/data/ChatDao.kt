package com.abhi.sitewatch.data

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.Query

@Dao
interface ChatDao {

    @Insert
    suspend fun insert(turn: ChatTurnEntity): Long

    @Query("SELECT * FROM chat_turns ORDER BY id ASC")
    suspend fun getAll(): List<ChatTurnEntity>

    @Query("SELECT * FROM chat_turns WHERE displayText != '' ORDER BY id ASC")
    suspend fun getDisplayable(): List<ChatTurnEntity>

    @Query("DELETE FROM chat_turns")
    suspend fun clear()

    // Keeps the table (and therefore every full-table load in ChatHistoryStore)
    // bounded regardless of how long the app has been in use. Cheap in steady
    // state — once at the cap, this deletes 0 rows on every subsequent call.
    @Query("DELETE FROM chat_turns WHERE id NOT IN (SELECT id FROM chat_turns ORDER BY id DESC LIMIT :keepCount)")
    suspend fun trimToLast(keepCount: Int)
}
