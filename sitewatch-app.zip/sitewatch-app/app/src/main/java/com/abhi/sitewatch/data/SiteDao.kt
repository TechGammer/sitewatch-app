package com.abhi.sitewatch.data

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query

@Dao
interface SiteDao {

    @Insert(onConflict = OnConflictStrategy.IGNORE)
    suspend fun insertIfNew(site: SiteEntity): Long

    // Used when writing the single merged row during dedupe, after the
    // duplicate rows have been deleted.
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(site: SiteEntity)

    @Query("SELECT * FROM sites ORDER BY tracked DESC, lastSeen DESC")
    suspend fun getAll(): List<SiteEntity>

    @Query("SELECT * FROM sites WHERE tracked = 1 ORDER BY displayName ASC")
    suspend fun getTracked(): List<SiteEntity>

    @Query("SELECT * FROM sites WHERE groupName = :groupName LIMIT 1")
    suspend fun getByGroupName(groupName: String): SiteEntity?

    @Query(
        "UPDATE sites SET lastSeen = :timestamp, messageCount = messageCount + 1 " +
        "WHERE groupName = :groupName"
    )
    suspend fun recordMessageSeen(groupName: String, timestamp: Long)

    @Query("UPDATE sites SET displayName = :displayName WHERE groupName = :groupName")
    suspend fun updateDisplayName(groupName: String, displayName: String)

    @Query("UPDATE sites SET tracked = :tracked WHERE groupName = :groupName")
    suspend fun updateTracked(groupName: String, tracked: Boolean)

    @Query("UPDATE sites SET lastFastAlertAt = :timestamp WHERE groupName = :groupName")
    suspend fun updateLastFastAlertAt(groupName: String, timestamp: Long)

    @Query("DELETE FROM sites WHERE groupName = :groupName")
    suspend fun delete(groupName: String)
}
