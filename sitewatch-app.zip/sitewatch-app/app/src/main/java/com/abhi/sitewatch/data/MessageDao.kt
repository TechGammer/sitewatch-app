package com.abhi.sitewatch.data

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.Query

@Dao
interface MessageDao {

    @Insert
    suspend fun insert(message: SiteMessage): Long

    @Query("SELECT * FROM site_messages WHERE reported = 0 ORDER BY groupName, timestamp ASC")
    suspend fun getUnreported(): List<SiteMessage>

    @Query("UPDATE site_messages SET reported = 1 WHERE id IN (:ids)")
    suspend fun markReported(ids: List<Long>)

    // Cheap de-dupe guard: WhatsApp sometimes re-posts a notification for the
    // same message (e.g. after a grouped-notification update).
    @Query(
        "SELECT COUNT(*) FROM site_messages " +
        "WHERE groupName = :groupName AND text = :text AND timestamp = :timestamp"
    )
    suspend fun countDuplicate(groupName: String, text: String, timestamp: Long): Int

    @Query(
        "SELECT * FROM site_messages WHERE groupName = :groupName " +
        "ORDER BY timestamp DESC LIMIT :limit"
    )
    suspend fun recentForGroup(groupName: String, limit: Int): List<SiteMessage>

    @Query("DELETE FROM site_messages WHERE groupName = :groupName")
    suspend fun deleteAllForGroup(groupName: String)
}
