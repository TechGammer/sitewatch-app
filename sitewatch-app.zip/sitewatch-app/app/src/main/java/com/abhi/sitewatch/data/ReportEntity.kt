package com.abhi.sitewatch.data

import androidx.room.Entity
import androidx.room.PrimaryKey

/**
 * One row per site per report generation (scheduled or on-demand via chat).
 * This is what makes the app "remember" — without it, every report was a
 * disconnected snapshot with nothing to compare against.
 *
 * tphNumeric is a best-effort parse of tphRaw (e.g. "185 TPH" -> 185.0),
 * null if nothing parseable was mentioned. Used for trend/delta math;
 * tphRaw is what's actually shown to the user since the numeric parse can
 * be wrong or lossy for ranges like "150-160".
 */
@Entity(tableName = "reports")
data class ReportEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val groupName: String,
    val timestamp: Long = System.currentTimeMillis(),
    val tphRaw: String,
    val tphNumeric: Double?,
    val summary: String,
    val issuesJson: String,      // serialized JSON array of strings
    val pendingJson: String,     // serialized JSON array of strings
    val extraFieldsJson: String = "{}" // serialized JSON object for user-configured extra fields (e.g. fuel_factor)
)
