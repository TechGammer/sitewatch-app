package com.abhi.sitewatch.data

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "site_messages")
data class SiteMessage(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val groupName: String,   // must match the WhatsApp group/conversation title exactly
    val sender: String,
    val text: String,
    val timestamp: Long,
    val reported: Boolean = false
)
