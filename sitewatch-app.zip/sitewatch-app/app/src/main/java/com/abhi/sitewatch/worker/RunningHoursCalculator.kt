package com.abhi.sitewatch.worker

import com.abhi.sitewatch.data.StatusEventEntity
import java.util.Calendar

/**
 * Turns a sorted sequence of status events into hours-per-status totals
 * over a time window. This is a best-effort approximation from chat
 * messages, not machine telemetry: each event is treated as "this status
 * held from here until the next event (or now)". Gaps where nobody
 * posted an update are attributed to whatever the last known status was
 * — which is reasonable for "plant kept running, nobody said otherwise"
 * but will be wrong if a status change simply wasn't reported.
 */
object RunningHoursCalculator {

    data class Totals(val hoursByStatus: Map<String, Double>, val currentStatus: String?, val currentStatusSince: Long?)

    /**
     * @param events ascending by timestamp, all for one site
     * @param rangeStart inclusive
     * @param rangeEnd exclusive (usually "now")
     */
    fun compute(events: List<StatusEventEntity>, rangeStart: Long, rangeEnd: Long): Totals {
        if (events.isEmpty()) return Totals(emptyMap(), null, null)

        val totals = mutableMapOf<String, Double>()
        // Find the status in effect at rangeStart: the last event at or before it,
        // or the first event if everything is after rangeStart.
        var carryStatus: String? = null
        var cursor = rangeStart

        val relevant = events.filter { it.timestamp < rangeEnd }
        val beforeRange = relevant.lastOrNull { it.timestamp <= rangeStart }
        if (beforeRange != null) carryStatus = beforeRange.status

        val inRange = relevant.filter { it.timestamp > rangeStart }

        for (event in inRange) {
            if (carryStatus != null) {
                val hours = (event.timestamp - cursor).coerceAtLeast(0) / 3_600_000.0
                totals[carryStatus] = (totals[carryStatus] ?: 0.0) + hours
            }
            cursor = event.timestamp
            carryStatus = event.status
        }
        if (carryStatus != null) {
            val hours = (rangeEnd - cursor).coerceAtLeast(0) / 3_600_000.0
            totals[carryStatus] = (totals[carryStatus] ?: 0.0) + hours
        }

        val latest = events.maxByOrNull { it.timestamp }
        return Totals(totals, latest?.status, latest?.timestamp)
    }

    fun startOfToday(): Long {
        val cal = Calendar.getInstance()
        cal.set(Calendar.HOUR_OF_DAY, 0)
        cal.set(Calendar.MINUTE, 0)
        cal.set(Calendar.SECOND, 0)
        cal.set(Calendar.MILLISECOND, 0)
        return cal.timeInMillis
    }
}
