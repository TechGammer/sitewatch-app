package com.abhi.sitewatch.data

import androidx.room.Entity
import androidx.room.PrimaryKey

/**
 * One row per message in the OpenRouter (OpenAI chat-completions format)
 * conversation. `contentJson` is the complete serialized message object
 * ({role, content, tool_calls?} / {role:"tool", tool_call_id, content})
 * exactly as sent to or received from the API, so the full conversation —
 * including tool calls — can be reconstructed after the app restarts.
 * `displayText` is the human-readable text shown in the chat UI (empty for
 * tool-result messages, which aren't rendered as bubbles).
 */
@Entity(tableName = "chat_turns")
data class ChatTurnEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val role: String,          // "user", "assistant", or "tool"
    val contentJson: String,   // serialized chat-completions message object
    val displayText: String,   // "" if nothing user-visible in this turn
    val timestamp: Long = System.currentTimeMillis()
)
