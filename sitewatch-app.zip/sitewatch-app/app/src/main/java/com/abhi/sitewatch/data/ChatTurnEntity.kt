package com.abhi.sitewatch.data

import androidx.room.Entity
import androidx.room.PrimaryKey

/**
 * One row per turn in the Anthropic Messages API conversation.
 * `contentJson` is the raw serialized content array (text / tool_use /
 * tool_result blocks) exactly as sent to or received from the API, so the
 * full conversation — including tool calls — can be reconstructed after the
 * app restarts. `displayText` is the human-readable text shown in the chat
 * UI (empty for pure tool_result turns, which aren't rendered as bubbles).
 */
@Entity(tableName = "chat_turns")
data class ChatTurnEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val role: String,          // "user" or "assistant"
    val contentJson: String,   // serialized JSON array of content blocks
    val displayText: String,   // "" if nothing user-visible in this turn
    val timestamp: Long = System.currentTimeMillis()
)
