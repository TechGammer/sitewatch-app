package com.abhi.sitewatch

import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.abhi.sitewatch.chat.ChatActivity
import com.abhi.sitewatch.worker.ScheduleManager

/**
 * Setup screen: only the credentials chat can't bootstrap itself (the
 * Anthropic API key) plus a couple of one-time system permissions. Once
 * these are filled in, everything else — sites, schedule, reports,
 * Telegram config — is controlled from ChatActivity via tool calls.
 */
class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val settings = SettingsStore(this)

        val apiKeyField = findViewById<EditText>(R.id.apiKeyField)
        val botTokenField = findViewById<EditText>(R.id.botTokenField)
        val chatIdField = findViewById<EditText>(R.id.chatIdField)

        apiKeyField.setText(settings.anthropicApiKey)
        botTokenField.setText(settings.telegramBotToken)
        chatIdField.setText(settings.telegramChatId)

        findViewById<Button>(R.id.notifAccessButton).setOnClickListener {
            startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS))
        }

        findViewById<Button>(R.id.saveButton).setOnClickListener {
            settings.anthropicApiKey = apiKeyField.text.toString().trim()
            settings.telegramBotToken = botTokenField.text.toString().trim()
            settings.telegramChatId = chatIdField.text.toString().trim()

            // Bootstrap a default schedule the first time; chat's
            // set_schedule tool can change it anytime after.
            ScheduleManager.applyCurrentSchedule(this)

            if (!settings.isConfigured()) {
                Toast.makeText(this, "Add your Anthropic API key to continue", Toast.LENGTH_LONG).show()
                return@setOnClickListener
            }

            Toast.makeText(this, "Saved", Toast.LENGTH_SHORT).show()
            startActivity(Intent(this, ChatActivity::class.java))
        }

        findViewById<Button>(R.id.openChatButton).setOnClickListener {
            if (!settings.isConfigured()) {
                Toast.makeText(this, "Add your Anthropic API key first", Toast.LENGTH_LONG).show()
            } else {
                startActivity(Intent(this, ChatActivity::class.java))
            }
        }
    }
}
