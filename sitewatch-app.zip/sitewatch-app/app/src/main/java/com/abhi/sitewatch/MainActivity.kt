package com.abhi.sitewatch

import android.app.AlertDialog
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.abhi.sitewatch.chat.ChatActivity
import com.abhi.sitewatch.network.TelegramSender
import com.abhi.sitewatch.worker.ScheduleManager
import kotlinx.coroutines.launch
import java.io.File

/**
 * Setup screen: only the credentials chat can't bootstrap itself (the
 * OpenRouter API key) plus a couple of one-time system permissions. Once
 * these are filled in, everything else — sites, schedule, reports,
 * Telegram config — is controlled from ChatActivity via tool calls.
 */
class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val settings = SettingsStore(this)

        val apiKeyField = findViewById<EditText>(R.id.apiKeyField)
        val botTokenField = findViewById<EditText>(R.id.botTokenField)
        val chatIdField = findViewById<EditText>(R.id.chatIdField)

        apiKeyField.setText(settings.openRouterApiKey)
        botTokenField.setText(settings.telegramBotToken)
        chatIdField.setText(settings.telegramChatId)

        findViewById<Button>(R.id.notifAccessButton).setOnClickListener {
            startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS))
        }

        findViewById<Button>(R.id.saveButton).setOnClickListener {
            settings.openRouterApiKey = apiKeyField.text.toString().trim()
            settings.telegramBotToken = botTokenField.text.toString().trim()
            settings.telegramChatId = chatIdField.text.toString().trim()

            // Bootstrap a default schedule the first time; chat's
            // set_schedule tool can change it anytime after.
            ScheduleManager.applyCurrentSchedule(this)

            if (!settings.isConfigured()) {
                Toast.makeText(this, "Add your OpenRouter API key to continue", Toast.LENGTH_LONG).show()
                return@setOnClickListener
            }

            Toast.makeText(this, "Saved", Toast.LENGTH_SHORT).show()
            startActivity(Intent(this, ChatActivity::class.java))
        }

        findViewById<Button>(R.id.openChatButton).setOnClickListener {
            if (!settings.isConfigured()) {
                Toast.makeText(this, "Add your OpenRouter API key first", Toast.LENGTH_LONG).show()
            } else {
                startActivity(Intent(this, ChatActivity::class.java))
            }
        }

        showLastCrashIfAny(settings)
    }

    /**
     * There's no attached debugger or device log access in most support
     * scenarios for this app, so a crash caught by SiteWatchApplication's
     * handler is surfaced right here on the next launch — readable/copyable
     * on-screen, and auto-forwarded to Telegram if configured, so the actual
     * stack trace makes it back without needing adb.
     */
    private fun showLastCrashIfAny(settings: SettingsStore) {
        val crashFile = File(filesDir, SiteWatchApplication.CRASH_LOG_FILENAME)
        if (!crashFile.exists()) return
        val crashText = crashFile.readText()
        crashFile.delete()

        AlertDialog.Builder(this)
            .setTitle("Site Watch crashed last time")
            .setMessage(crashText.take(4000))
            .setPositiveButton("Copy") { _, _ ->
                val clipboard = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                clipboard.setPrimaryClip(ClipData.newPlainText("Site Watch crash log", crashText))
                Toast.makeText(this, "Copied", Toast.LENGTH_SHORT).show()
            }
            .setNegativeButton("Dismiss", null)
            .show()

        if (settings.isTelegramConfigured()) {
            lifecycleScope.launch {
                try {
                    TelegramSender.send(
                        settings.telegramBotToken,
                        settings.telegramChatId,
                        "⚠️ Site Watch crashed:\n```\n${crashText.take(3500)}\n```"
                    )
                } catch (e: Exception) {
                    // Best-effort — the on-screen dialog above is the fallback.
                }
            }
        }
    }
}
