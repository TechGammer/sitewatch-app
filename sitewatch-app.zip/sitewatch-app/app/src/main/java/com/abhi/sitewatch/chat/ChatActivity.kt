package com.abhi.sitewatch.chat

import android.content.Intent
import android.os.Bundle
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.Toolbar
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.abhi.sitewatch.MainActivity
import com.abhi.sitewatch.R
import com.abhi.sitewatch.SettingsStore
import com.abhi.sitewatch.SiteWatchApplication
import com.abhi.sitewatch.dashboard.DashboardActivity
import com.abhi.sitewatch.data.AppDatabase
import com.abhi.sitewatch.data.SiteMaintenance
import com.abhi.sitewatch.livestatus.LiveStatusActivity
import com.abhi.sitewatch.sitemanager.SiteManagerActivity
import com.abhi.sitewatch.network.OpenRouterChatClient
import kotlinx.coroutines.launch
import org.json.JSONObject
import java.io.File

class ChatActivity : AppCompatActivity() {

    companion object {
        const val EXTRA_PREFILL = "extra_prefill"
    }

    private lateinit var settings: SettingsStore
    private lateinit var historyStore: ChatHistoryStore
    private lateinit var adapter: ChatAdapter
    private lateinit var recyclerView: RecyclerView
    private lateinit var statusText: TextView
    private lateinit var messageInput: EditText

    private var apiHistory: MutableList<JSONObject> = mutableListOf()
    private var sending = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_chat)

        settings = SettingsStore(this)
        historyStore = ChatHistoryStore(AppDatabase.getInstance(this).chatDao())

        setSupportActionBar(findViewById<Toolbar>(R.id.toolbar))

        recyclerView = findViewById(R.id.chatRecyclerView)
        adapter = ChatAdapter()
        recyclerView.layoutManager = LinearLayoutManager(this)
        recyclerView.adapter = adapter

        statusText = findViewById(R.id.statusText)
        messageInput = findViewById(R.id.messageInput)

        findViewById<android.widget.Button>(R.id.sendButton).setOnClickListener {
            val text = messageInput.text.toString().trim()
            if (text.isNotEmpty() && !sending) {
                messageInput.setText("")
                send(text)
            }
        }

        findViewById<TextView>(R.id.dashboardLink).setOnClickListener {
            startActivity(Intent(this, DashboardActivity::class.java))
        }

        findViewById<TextView>(R.id.manageSitesLink).setOnClickListener {
            startActivity(Intent(this, SiteManagerActivity::class.java))
        }

        findViewById<TextView>(R.id.liveStatusLink).setOnClickListener {
            startActivity(Intent(this, LiveStatusActivity::class.java))
        }

        if (!settings.isConfigured()) {
            Toast.makeText(this, "Add your OpenRouter API key in Setup first", Toast.LENGTH_LONG).show()
            startActivity(Intent(this, MainActivity::class.java))
            finish()
            return
        }

        lifecycleScope.launch {
            try {
                // One-time cleanup of duplicate sites created by WhatsApp's
                // "(N messages)" count-suffix leaking into the group key (see
                // SiteMaintenance). Guarded so it only does real work once;
                // failures are swallowed so a cleanup hiccup never blocks the app.
                if (!settings.dedupeV1Done) {
                    try {
                        SiteMaintenance.dedupeAndNormalize(applicationContext)
                        settings.dedupeV1Done = true
                    } catch (e: Exception) {
                        // Leave the flag unset so it retries next launch.
                    }
                }
                apiHistory = historyStore.loadApiHistory()
                adapter.submitList(historyStore.loadDisplayMessages())
                if (apiHistory.isEmpty()) {
                    appendAssistantBubbleOnly(
                        "Hi! I'm watching for WhatsApp groups in the background. Tell me things like " +
                            "\"what groups have you seen\", \"track the Site A group\", or \"generate a report\"."
                    )
                }
                recyclerView.scrollToPosition(maxOf(0, adapter.itemCount - 1))

                val prefill = intent.getStringExtra(EXTRA_PREFILL)
                if (!prefill.isNullOrBlank()) {
                    send(prefill)
                }
            } catch (e: Exception) {
                // Loading past history failed (e.g. a local DB error) — don't let
                // that hard-crash the whole screen. Log it the same way an
                // uncaught crash would (MainActivity surfaces it next launch) and
                // let the user keep using chat with a fresh, empty history.
                try {
                    File(filesDir, SiteWatchApplication.CRASH_LOG_FILENAME).writeText(
                        "ChatActivity failed to load history at ${System.currentTimeMillis()}\n${e.stackTraceToString()}"
                    )
                } catch (ignored: Exception) { }
                appendAssistantBubbleOnly(
                    "Something went wrong loading your chat history (${e.message}). " +
                        "Starting fresh — you can still send messages below."
                )
            }
        }
    }

    private fun send(userText: String) {
        adapter.appendMessage(DisplayMessage("user", userText))
        recyclerView.scrollToPosition(adapter.itemCount - 1)

        sending = true
        statusText.visibility = android.view.View.VISIBLE
        statusText.text = "Thinking…"

        lifecycleScope.launch {
            try {
                // Loaded fresh on every send so a fact remembered seconds ago
                // (this session or a past one) is already visible to the very
                // next message, not just future sessions.
                val memories = AppDatabase.getInstance(applicationContext).memoryDao().getAll().map { it.content }
                OpenRouterChatClient.sendMessage(
                    apiKey = settings.openRouterApiKey,
                    model = settings.modelId,
                    history = apiHistory,
                    userText = userText,
                    tools = ChatTools.toolSchemas(),
                    systemPrompt = ChatTools.systemPrompt(memories),
                    toolExecutor = ChatTools.executor(applicationContext),
                    turnListener = OpenRouterChatClient.TurnListener { message ->
                        historyStore.persistTurn(message)
                        if (message.optString("role") == "assistant" && message.has("tool_calls")) {
                            statusText.text = "Using tools…"
                        }
                    },
                    onAssistantText = { text ->
                        adapter.appendMessage(DisplayMessage("assistant", text))
                        recyclerView.scrollToPosition(adapter.itemCount - 1)
                    }
                )
            } catch (e: Exception) {
                adapter.appendMessage(DisplayMessage("assistant", "Something went wrong: ${e.message}"))
                recyclerView.scrollToPosition(adapter.itemCount - 1)
            } finally {
                sending = false
                statusText.visibility = android.view.View.GONE
            }
        }
    }

    private fun appendAssistantBubbleOnly(text: String) {
        adapter.appendMessage(DisplayMessage("assistant", text))
    }
}
