package com.abhi.sitewatch.chat

import android.content.Intent
import android.os.Bundle
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.Toolbar
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.abhi.sitewatch.MainActivity
import com.abhi.sitewatch.R
import com.abhi.sitewatch.SettingsStore
import com.abhi.sitewatch.dashboard.DashboardActivity
import com.abhi.sitewatch.data.AppDatabase
import com.abhi.sitewatch.network.OpenRouterChatClient
import kotlinx.coroutines.launch
import org.json.JSONObject

class ChatActivity : AppCompatActivity() {

    companion object {
        const val EXTRA_PREFILL = "extra_prefill"
    }

    private lateinit var settings: SettingsStore
    private lateinit var historyStore: ChatHistoryStore
    private lateinit var adapter: ChatAdapter
    private lateinit var recyclerView: RecyclerView
    private lateinit var statusText: TextView
    private lateinit var messageInput: EditText

    private var apiHistory: MutableList<JSONObject> = mutableListOf()
    private var sending = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_chat)

        settings = SettingsStore(this)
        historyStore = ChatHistoryStore(AppDatabase.getInstance(this).chatDao())

        setSupportActionBar(findViewById<Toolbar>(R.id.toolbar))

        recyclerView = findViewById(R.id.chatRecyclerView)
        adapter = ChatAdapter()
        recyclerView.layoutManager = LinearLayoutManager(this)
        recyclerView.adapter = adapter

        statusText = findViewById(R.id.statusText)
        messageInput = findViewById(R.id.messageInput)

        findViewById<android.widget.Button>(R.id.sendButton).setOnClickListener {
            val text = messageInput.text.toString().trim()
            if (text.isNotEmpty() && !sending) {
                messageInput.setText("")
                send(text)
            }
        }

        findViewById<TextView>(R.id.dashboardLink).setOnClickListener {
            startActivity(Intent(this, DashboardActivity::class.java))
        }

        if (!settings.isConfigured()) {
            Toast.makeText(this, "Add your OpenRouter API key in Setup first", Toast.LENGTH_LONG).show()
            startActivity(Intent(this, MainActivity::class.java))
            finish()
            return
        }

        lifecycleScope.launch {
            apiHistory = historyStore.loadApiHistory()
            adapter.submitList(historyStore.loadDisplayMessages())
            if (apiHistory.isEmpty()) {
                appendAssistantBubbleOnly(
                    "Hi! I'm watching for WhatsApp groups in the background. Tell me things like " +
                        "\"what groups have you seen\", \"track the Site A group\", or \"generate a report\"."
                )
            }
            recyclerView.scrollToPosition(maxOf(0, adapter.itemCount - 1))

            val prefill = intent.getStringExtra(EXTRA_PREFILL)
            if (!prefill.isNullOrBlank()) {
                send(prefill)
            }
        }
    }

    private fun send(userText: String) {
        adapter.appendMessage(DisplayMessage("user", userText))
        recyclerView.scrollToPosition(adapter.itemCount - 1)

        sending = true
        statusText.visibility = android.view.View.VISIBLE
        statusText.text = "Thinking…"

        lifecycleScope.launch {
            try {
                OpenRouterChatClient.sendMessage(
                    apiKey = settings.openRouterApiKey,
                    model = settings.modelId,
                    history = apiHistory,
                    userText = userText,
                    tools = ChatTools.toolSchemas(),
                    systemPrompt = ChatTools.SYSTEM_PROMPT,
                    toolExecutor = ChatTools.executor(applicationContext),
                    turnListener = OpenRouterChatClient.TurnListener { message ->
                        historyStore.persistTurn(message)
                        if (message.optString("role") == "assistant" && message.has("tool_calls")) {
                            statusText.text = "Using tools…"
                        }
                    },
                    onAssistantText = { text ->
                        adapter.appendMessage(DisplayMessage("assistant", text))
                        recyclerView.scrollToPosition(adapter.itemCount - 1)
                    }
                )
            } catch (e: Exception) {
                adapter.appendMessage(DisplayMessage("assistant", "Something went wrong: ${e.message}"))
                recyclerView.scrollToPosition(adapter.itemCount - 1)
            } finally {
                sending = false
                statusText.visibility = android.view.View.GONE
            }
        }
    }

    private fun appendAssistantBubbleOnly(text: String) {
        adapter.appendMessage(DisplayMessage("assistant", text))
    }
}
